// Per-target install roots + output path/naming helpers. Pure: (scope|context) -> path string.
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { fail } from "./util.mjs";

export function installRootUserOrProject(scope) {
  return scope === "user" ? os.homedir() : process.cwd();
}

// Several hosts have no project-scope layout of their own: installing them means writing into the
// home directory (or one directory under it), and a project install only makes sense via --dest.
// `homeOnly` lets `--target all` skip these at project scope without calling the root, which exits.
function homeOnlyInstallRoot(message, subdirectory = null) {
  const root = (scope) => {
    if (scope !== "user") fail(message);
    return subdirectory === null ? os.homedir() : path.join(os.homedir(), subdirectory);
  };
  root.homeOnly = true;
  return root;
}

export const installRootHomeOnly = homeOnlyInstallRoot("this target supports --scope user only unless --dest is supplied");
export const installRootCodex = homeOnlyInstallRoot("codex install supports --scope user only unless --dest is supplied");

export function installRootKimiCode(scope) {
  if (scope === "project") return process.cwd();
  return path.resolve(process.env.KIMI_CODE_HOME ?? path.join(os.homedir(), ".kimi-code"));
}

export const installRootAntigravity = homeOnlyInstallRoot("antigravity install supports --scope user only unless --dest is supplied", ".gemini");
export const installRootAntigravityCli = homeOnlyInstallRoot("antigravity-cli install supports --scope user only unless --dest is supplied", ".gemini");
// Where install stages the plugin (under the install root), and where `agy plugin install` imports
// it for Antigravity to run (under the home directory).
export const antigravityCliStagedPlugin = path.join("antigravity-cli", "plugins", "agent-surface");
export const antigravityCliImportedPlugin = path.join(".gemini", "config", "plugins", "agent-surface");
export const installRootVsCode = homeOnlyInstallRoot("vscode install supports --scope user only unless --dest is supplied");

// Codex reads CODEX_HOME/AGENTS.md and a project's AGENTS.md files from the repository root down,
// never a project's .codex/AGENTS.md.
export function codexInstructionPath(context) {
  return context.scope === "user" ? path.join(".codex", "AGENTS.md") : "AGENTS.md";
}

export function droidInstructionPath(context) {
  return context.scope === "user" ? path.join(".factory", "AGENTS.md") : "AGENTS.md";
}

export function droidConfigRoot(_context) {
  return ".factory";
}

export function flatMarkdownCommandOutputName(source) {
  return `${source.name}.md`;
}

export function gooseRecipeOutputName(source) {
  return `${source.name}.yaml`;
}

export function codexSkillOutputName(source) {
  return path.join(source.name, "SKILL.md");
}

// Claude Code reads this through an @import in .claude/CLAUDE.md (see claudeCodeStaticOutputs).
export const claudeRulesDocument = path.join(".claude", "agent-surface", "rules.md");

export function claudeMcpPath(context) {
  return context.scope === "user" ? ".claude.json" : ".mcp.json";
}

export function clineWorkflowRoot(context) {
  return context.scope === "user" ? path.join("Documents", "Cline", "Workflows") : path.join(".clinerules", "workflows");
}

export function clineSkillRoot(_context) {
  return path.join(".cline", "skills");
}

export function clineAgentRoot(_context) {
  return path.join(".cline", "agents");
}

export function deepagentsSkillRoot(context) {
  return context.scope === "user"
    ? path.join(".deepagents", context.agentName ?? "agent", "skills")
    : path.join(".deepagents", "skills");
}

export function deepagentsInstructionPath(context) {
  return context.scope === "user"
    ? path.join(".deepagents", context.agentName ?? "agent", "AGENTS.md")
    : path.join(".deepagents", "AGENTS.md");
}

export function deepagentsAgentRoot(context) {
  return context.scope === "user"
    ? path.join(".deepagents", context.agentName ?? "agent", "agents")
    : path.join(".deepagents", "agents");
}

export function deepagentsConfigRoot(context) {
  return context.scope === "user" ? path.join(".deepagents", context.agentName ?? "agent") : ".deepagents";
}

export function deepagentsSubagentOutputName(source) {
  return path.join(source.metadata.name, "AGENTS.md");
}

export function deepagentsMcpPath() {
  return path.join(".deepagents", ".mcp.json");
}

export function grokBuildSkillRoot() {
  return path.join(".grok", "skills");
}

export function grokBuildAgentRoot() {
  return path.join(".grok", "agents");
}

// Grok reads ~/.grok/AGENTS.md as global instructions, outside project trust, and a project's AGENTS.md
// files from the session directory up to the repository root.
export function grokBuildInstructionPath(context) {
  return context.scope === "user" ? path.join(".grok", "AGENTS.md") : "AGENTS.md";
}

export function dshSkillRoot() {
  return path.join(".dsh", "skills");
}

export function qoderConfigRoot() {
  return ".qoder";
}

export function qoderSkillRoot() {
  return path.join(qoderConfigRoot(), "skills");
}

export function qoderCommandRoot() {
  return path.join(qoderConfigRoot(), "commands");
}

export function qoderAgentRoot() {
  return path.join(qoderConfigRoot(), "agents");
}

export function qoderInstructionPath(context) {
  return context.scope === "user" ? path.join(qoderConfigRoot(), "AGENTS.md") : "AGENTS.md";
}

export function qoderSettingsPath() {
  return path.join(qoderConfigRoot(), "settings.json");
}

export function qwenCodeConfigRoot() {
  return ".qwen";
}

export function qwenCodeSkillRoot() {
  return path.join(qwenCodeConfigRoot(), "skills");
}

export function qwenCodeCommandRoot() {
  return path.join(qwenCodeConfigRoot(), "commands");
}

export function qwenCodeAgentRoot() {
  return path.join(qwenCodeConfigRoot(), "agents");
}

// Qwen Code loads both QWEN.md and AGENTS.md, from ~/.qwen and from every directory between the working
// directory and the project root, so a project's shared AGENTS.md already reaches it. A root QWEN.md
// beside it loaded the same rules twice.
export function qwenCodeInstructionPath(context) {
  return context.scope === "user" ? path.join(qwenCodeConfigRoot(), "QWEN.md") : "AGENTS.md";
}

export function qwenCodeSettingsPath() {
  return path.join(qwenCodeConfigRoot(), "settings.json");
}

export function kiroConfigRoot() {
  return ".kiro";
}

export function kiroSkillRoot() {
  return path.join(kiroConfigRoot(), "skills");
}

export function kiroSteeringRoot() {
  return path.join(kiroConfigRoot(), "steering");
}

export function kiroAgentRoot() {
  return path.join(kiroConfigRoot(), "agents");
}

export function kiroMcpPath() {
  return path.join(kiroConfigRoot(), "settings", "mcp.json");
}

export function kiroPermissionsPath() {
  return path.join(kiroConfigRoot(), "settings", "permissions.yaml");
}

export function piSkillRoot(context) {
  return context.scope === "user" ? path.join(".pi", "agent", "skills") : path.join(".pi", "skills");
}

export function piInstructionPath(context) {
  return context.scope === "user" ? path.join(".pi", "agent", "AGENTS.md") : "AGENTS.md";
}

export function piConfigRoot(context) {
  return context.scope === "user" ? path.join(".pi", "agent") : ".pi";
}

// Pi reads a project's .pi/mcp.json only after the project is trusted.
export function piMcpPath(context) {
  return path.join(piConfigRoot(context), "mcp.json");
}

export function poolSkillRoot(context) {
  return context.scope === "user" ? path.join(".config", "poolside", "skills") : path.join(".poolside", "skills");
}

// Poolside documents personal instructions at the default config home's AGENTS.md. Poolside honors
// XDG_CONFIG_HOME, but agent-surface does not follow it: the client's environment is not known at
// install time.
export function poolInstructionPath(context) {
  return context.scope === "user" ? path.join(".config", "poolside", "AGENTS.md") : "AGENTS.md";
}

export function poolConfigRoot(context) {
  return context.scope === "user" ? path.join(".config", "poolside") : ".poolside";
}

export function clineRuleRoot(context) {
  return context.scope === "user" ? path.join("Documents", "Cline", "Rules") : ".clinerules";
}

export function clineMcpPath(_context) {
  return path.join(".cline", "data", "settings", "cline_mcp_settings.json");
}

// The Cline extension keeps one settings file per host IDE, under that IDE's user-data root.
function clineExtensionMcpPath(product) {
  return (context) => path.join(ideUserDataRoot(product, context), "User", "globalStorage", "saoudrizwan.claude-dev", "settings", "cline_mcp_settings.json");
}

export const clineVsCodeExtensionMcpPath = clineExtensionMcpPath("Code");
export const clineCursorExtensionMcpPath = clineExtensionMcpPath("Cursor");
export const clineWindsurfExtensionMcpPath = clineExtensionMcpPath("Windsurf");
// Devin Desktop, the renamed Windsurf, keeps its own user data under Devin/ and extensions under ~/.devin.
export const clineDevinExtensionMcpPath = clineExtensionMcpPath("Devin");

export function ideUserDataRoot(product, context = {}) {
  const platform = context.platform ?? process.platform;
  if (platform === "darwin") return path.join("Library", "Application Support", product);
  if (platform === "win32") {
    const appData = context.appData ?? process.env.APPDATA;
    if (!context.relocateExternalRoutes && appData) return path.win32.join(appData, product);
    return windowsRoamingPath(product);
  }
  return path.join(".config", product);
}

// The roaming AppData directory resolved from the profile home, as the VS Code root is: a
// redirected %APPDATA% is not followed.
function windowsRoamingPath(...segments) {
  return path.win32.join("AppData", "Roaming", ...segments);
}

// Goose keeps config.yaml in the config home on macOS and Linux and in the roaming AppData
// directory on Windows. Goose resolves that config home from XDG_CONFIG_HOME when it is set, which
// agent-surface does not follow: the client's environment is not known at install time. A plan whose
// written route such a Goose would not read carries the GOOSE_XDG_CONFIG_HOME_SET notice.
export function gooseMcpPath(context) {
  return (context.platform ?? process.platform) === "win32"
    ? windowsRoamingPath("Block", "goose", "config", "config.yaml")
    : path.join(".config", "goose", "config.yaml");
}

export function kiloWorkflowRoot(context) {
  return context.scope === "user" ? path.join(".config", "kilo", "commands") : path.join(".kilo", "commands");
}

export function kiloSkillRoot() {
  return path.join(".kilo", "skills");
}

export function kiloConfigPath(scope) {
  return scope === "user" ? path.join(".config", "kilo", "kilo.jsonc") : "kilo.jsonc";
}

export function kiloRuleRoot(context) {
  return context.scope === "user" ? path.join(".config", "kilo", "rules") : path.join(".kilo", "rules");
}

export function kiloRuleReferenceRoot(context) {
  return context.scope === "user"
    ? path.join(".config", "kilo", "references", "rules")
    : path.join(".kilo", "references", "rules");
}

export function kiloAgentRoot(context) {
  return context.scope === "user" ? path.join(".config", "kilo", "agents") : path.join(".kilo", "agents");
}

export function kimiCodeConfigRoot(context) {
  return context.scope === "user" ? "" : ".kimi-code";
}

export function kimiCodeSkillRoot(context) {
  return path.join(kimiCodeConfigRoot(context), "skills");
}

export function kimiCodeAgentRoot(context) {
  return path.join(kimiCodeConfigRoot(context), "agents");
}

// Kimi Code loads <KIMI_CODE_HOME>/AGENTS.md, then .kimi-code/AGENTS.md and AGENTS.md in each directory
// from the git root down, so a project install shares the root AGENTS.md; a .kimi-code/AGENTS.md
// beside it loaded the same rules twice.
export function kimiCodeInstructionPath() {
  return "AGENTS.md";
}

export function kimiCodeConfigPath(context) {
  return path.join(kimiCodeConfigRoot(context), "config.toml");
}

export function kimiCodeMcpPath(context) {
  return path.join(kimiCodeConfigRoot(context), "mcp.json");
}

export function kimiCodeVsCodeSettingsPath(context) {
  return kimiCodeIdeSettingsPath("Code", context);
}

export function kimiCodeCursorSettingsPath(context) {
  return kimiCodeIdeSettingsPath("Cursor", context);
}

function kimiCodeIdeSettingsPath(product, context = {}) {
  const route = path.join(ideUserDataRoot(product, context), "User", "settings.json");
  if (context.relocateExternalRoutes || path.isAbsolute(route)) return route;
  return path.join(os.homedir(), route);
}

export function opencodeCommandRoot(context) {
  return context.scope === "user" ? path.join(".config", "opencode", "commands") : path.join(".opencode", "commands");
}

export function opencodeSkillRoot(context) {
  return context.scope === "user" ? path.join(".config", "opencode", "skills") : path.join(".opencode", "skills");
}

export function opencodeAgentRoot(context) {
  return context.scope === "user" ? path.join(".config", "opencode", "agents") : path.join(".opencode", "agents");
}

export function opencodeInstructionPath(context) {
  return context.scope === "user" ? path.join(".config", "opencode", "AGENTS.md") : "AGENTS.md";
}

// OpenCode reads its user root under XDG_CONFIG_HOME when that is set; an install does not follow the
// installing shell's environment, and a user plan says so instead (notices.mjs).
export function opencodeConfigRoot(context) {
  return context.scope === "user" ? path.join(".config", "opencode") : ".opencode";
}

export function opencodeMcpPath(context) {
  return path.join(opencodeConfigRoot(context), "opencode.json");
}

export const openhandsSkillRoot = sharedAgentSkillRoot;

export function openhandsInstructionPath(context) {
  return context.scope === "user" ? path.join(".openhands", "skills", "agent-surface-rules.md") : "AGENTS.md";
}

export function openhandsConfigRoot() {
  return ".openhands";
}

export function openhandsMcpPath() {
  return path.join(".openhands", "mcp.json");
}

export function windsurfWorkflowRoot(context) {
  return context.scope === "user" ? path.join(".codeium", "windsurf", "global_workflows") : path.join(".windsurf", "workflows");
}

export function windsurfConfigRoot(context) {
  return context.scope === "user" ? path.join(".codeium", "windsurf") : ".windsurf";
}

export function windsurfMcpPath(context) {
  return context.scope === "user"
    ? path.join(".codeium", "windsurf", "mcp_config.json")
    : path.join(".windsurf", "mcp_config.json");
}

export function windsurfRulePath(context) {
  return context.scope === "user"
    ? path.join(".codeium", "windsurf", "memories", "global_rules.md")
    : path.join(".devin", "rules", "agent-surface.md");
}

export function windsurfSkillRoot(context) {
  return context.scope === "user" ? path.join(".codeium", "windsurf", "skills") : path.join(".windsurf", "skills");
}

export const gooseSkillRoot = sharedAgentSkillRoot;

export function antigravitySkillRoot(context) {
  return context.scope === "user" ? path.join("config", "skills") : path.join(".agents", "skills");
}

export function antigravityWorkflowRoot() {
  return path.join("antigravity", "global_workflows");
}

export function cursorSkillRoot() {
  return path.join(".cursor", "skills");
}

// Trae splits by root set: the international IDE and Trae CLI 2.0 read ~/.trae, the CN IDE reads
// ~/.trae-cn, and every edition reads the project's .trae directory.
export function traeSkillRoot() {
  return path.join(".trae", "skills");
}

export function traeCnSkillRoot(context) {
  return context.scope === "user" ? path.join(".trae-cn", "skills") : traeSkillRoot();
}

export function traeAgentRoot() {
  return path.join(".trae", "agents");
}

export function traeCnAgentRoot(context) {
  return context.scope === "user" ? path.join(".trae-cn", "agents") : traeAgentRoot();
}

// Per-rule project rules every edition reads, and the CN IDE's user rules folder.
export function traeRuleRoot(context) {
  return context.scope === "user" ? path.join(".trae-cn", "user_rules") : traeRuleFolder();
}

// The per-rule folder every edition reads in a project; Trae CLI also reads it under the home directory.
export function traeRuleFolder() {
  return path.join(".trae", "rules");
}

// Each IDE edition reads user MCP servers from mcp.json beside its per-OS User settings; a project
// keeps .trae/mcp.json.
export function traeMcpPath(product) {
  return (context) => context.scope === "user"
    ? path.join(ideUserDataRoot(product, context), "User", "mcp.json")
    : path.join(".trae", "mcp.json");
}

export function traeCliConfigPath() {
  return path.join(".trae", "traecli.toml");
}

export function copilotSkillRoot(context) {
  return context.scope === "user" ? path.join(".copilot", "skills") : path.join(".github", "skills");
}

export function copilotAgentRoot(context) {
  return context.scope === "user" ? path.join(".copilot", "agents") : path.join(".github", "agents");
}

export function copilotInstructionPath(context) {
  return context.scope === "user"
    ? path.join(".copilot", "copilot-instructions.md")
    : path.join(".github", "copilot-instructions.md");
}

export function copilotMcpPath(context) {
  return context.scope === "user" ? path.join(".copilot", "mcp-config.json") : ".mcp.json";
}

// The cross-host skill root several hosts read natively; each host that uses it is an alias so the
// target table still names the host it configures.
export function sharedAgentSkillRoot() {
  return path.join(".agents", "skills");
}

export function vsCodeUserRoot(product, context = {}) {
  const platform = context.platform ?? process.platform;
  const pathApi = platform === "win32" ? path.win32 : path;
  return pathApi.join(ideUserDataRoot(product, { ...context, relocateExternalRoutes: true }), "User");
}

export const zedSkillRoot = sharedAgentSkillRoot;

export function zedInstructionPath(context) {
  return context.scope === "user" ? zedConfigPath(context, "AGENTS.md") : "AGENTS.md";
}

// Zed's config directory is ~/.config/zed on macOS and Linux (Linux Zed also honors XDG_CONFIG_HOME,
// which is not followed here) and the roaming AppData directory on Windows.
export function zedConfigRoot(context) {
  if (context.scope !== "user") return ".zed";
  return (context.platform ?? process.platform) === "win32" ? windowsRoamingPath("Zed") : path.join(".config", "zed");
}

export function zedMcpPath(context) {
  return zedConfigPath(context, "settings.json");
}

function zedConfigPath(context, name) {
  const pathApi = (context.platform ?? process.platform) === "win32" ? path.win32 : path;
  return pathApi.join(zedConfigRoot(context), name);
}
