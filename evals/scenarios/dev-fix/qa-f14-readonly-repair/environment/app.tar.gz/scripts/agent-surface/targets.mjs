// The heart of the compiler: the per-target adapter table + the producers that turn source
// (commands/rules/subagents/skills/mcp) into per-target outputs. Imports render/roots/merge/
// postprocess; the install + check layers import targets/targetOutputs/producers from here.
import { closeSync, openSync, readSync, realpathSync } from "node:fs";
import { oneDriveDocumentsDirs, samePath } from "./documents.mjs";
import { foldedBlockScalar } from "./format.mjs";
import { lstat, readFile, readdir, stat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { directDirectories, filesUnder } from "./fs-tree.mjs";
import { MCP_ENV_LAUNCHER, mcpLauncherInvocation, optionalServiceMcpServers, renderMcpConfig } from "./merge.mjs";
import { normalizeExternalSkillFile } from "./postprocess.mjs";
import { assetCategoryAllowed, assetCategoryFor, packageVersion, readAssetCategories, readOptionalServices, relative, root, selectedAssetCategories } from "./registry.mjs";
import { firstHeading, renderAntigravityCliRuleDocument, renderAntigravityWorkflow, renderClineWorkflow, renderCodexSubagent, renderCursorCommand, renderCursorSubagent, renderDroidCommand, renderGooseRecipe, renderInstructionDocument, renderKiloRuleDocument, renderKiloWorkflow, renderKiroManualSteering, renderKiroRuleDocument, renderKiroSubagent, renderManualClaudeSkill, renderManualKimiCodeSkill, renderManualPortableSkill, renderManualSlashSkill, renderMarkdownSubagent, renderNativeMarkdownCommand, renderOpenCodeCommand, renderOpenCodeSubagent, renderQwenCodeCommand, renderScopedRuleReferenceDocument, renderVanillaSkill, renderVsCodeInstructionDocument, renderVsCodeScopedInstructionDocument, renderWindsurfWorkflow } from "./render.mjs";
import { antigravitySkillRoot, antigravityWorkflowRoot, claudeMcpPath, claudeRulesDocument, clineAgentRoot, clineCursorExtensionMcpPath, clineDevinExtensionMcpPath, clineMcpPath, clineRuleRoot, clineSkillRoot, clineVsCodeExtensionMcpPath, clineWindsurfExtensionMcpPath, clineWorkflowRoot, codexInstructionPath, codexSkillOutputName, copilotAgentRoot, copilotInstructionPath, copilotMcpPath, copilotSkillRoot, cursorSkillRoot, deepagentsAgentRoot, deepagentsConfigRoot, deepagentsInstructionPath, deepagentsMcpPath, deepagentsSkillRoot, deepagentsSubagentOutputName, droidConfigRoot, droidInstructionPath, dshSkillRoot, flatMarkdownCommandOutputName, gooseMcpPath, gooseRecipeOutputName, gooseSkillRoot, grokBuildAgentRoot, grokBuildInstructionPath, grokBuildSkillRoot, installRootAntigravity, installRootAntigravityCli, installRootCodex, installRootHomeOnly, installRootKimiCode, installRootUserOrProject, installRootVsCode, kiloAgentRoot, kiloConfigPath, kiloRuleReferenceRoot, kiloRuleRoot, kiloSkillRoot, kiloWorkflowRoot, kimiCodeAgentRoot, kimiCodeConfigPath, kimiCodeConfigRoot, kimiCodeCursorSettingsPath, kimiCodeInstructionPath, kimiCodeMcpPath, kimiCodeSkillRoot, kimiCodeVsCodeSettingsPath, kiroAgentRoot, kiroMcpPath, kiroPermissionsPath, kiroSkillRoot, kiroSteeringRoot, opencodeAgentRoot, opencodeCommandRoot, opencodeConfigRoot, opencodeInstructionPath, opencodeMcpPath, opencodeSkillRoot, openhandsConfigRoot, openhandsInstructionPath, openhandsMcpPath, openhandsSkillRoot, piConfigRoot, piInstructionPath, piMcpPath, piSkillRoot, poolConfigRoot, poolInstructionPath, poolSkillRoot, qoderAgentRoot, qoderCommandRoot, qoderConfigRoot, qoderInstructionPath, qoderSettingsPath, qoderSkillRoot, qwenCodeAgentRoot, qwenCodeCommandRoot, qwenCodeConfigRoot, qwenCodeInstructionPath, qwenCodeSettingsPath, qwenCodeSkillRoot, sharedAgentSkillRoot, traeAgentRoot, traeCliConfigPath, traeCnAgentRoot, traeCnSkillRoot, traeMcpPath, traeRuleFolder, traeRuleRoot, traeSkillRoot, vsCodeUserRoot, windsurfConfigRoot, windsurfMcpPath, windsurfRulePath, windsurfSkillRoot, windsurfWorkflowRoot, zedConfigRoot, zedInstructionPath, zedMcpPath, zedSkillRoot } from "./roots.mjs";
import { readRulesForContext } from "./rules.mjs";
import { SKILL_RESOURCE_EXTENSIONS } from "./skills.mjs";
import { ignoreOutputs, subagentOutputs } from "./source-primitives.mjs";
import { SYNAPSE_ROUTING_ENV } from "./synapse-hook.mjs";
import { exists, fail, isPathInside, isSafeRelativePath } from "./util.mjs";

// The pre-SDK Cline extension that 3.x and most 4.x installs run reads MCP servers from its
// per-editor storage; only the SDK-based extension reads the shared ~/.cline file (and imports a
// per-editor file once). Per-editor routes are written only where the extension is installed.
const CLINE_EXTENSION = { extensionId: "saoudrizwan.claude-dev" };

export const targets = {
  "claude-code": {
    label: "Claude Code skills, rules, and subagents",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "claude-code",
    subagentOutputRoot: ".claude/agents",
    staticRenders: ["rules"],
    staticOutputs: claudeCodeStaticOutputs,
    externalSkillOutputRoot: ".claude/skills",
    skillRenders: ["skills"],
    skillOutputRoot: ".claude/skills",
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: ".claude/skills",
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualClaudeSkill,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    mcpConfig: {
      relativeOutput: claudeMcpPath,
      format: "mcpServers",
      defaultEnabled: true,
    },
  },
  codex: {
    label: "Codex skills, custom agents, and instructions",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "codex",
    subagentOutputRoot: path.join(".codex", "agents"),
    subagentOutputExtension: ".toml",
    externalSkillOutputRoot: path.join(".agents", "skills"),
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: ".agents/skills",
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    additionalSkillOutputs: [codexOpenAiAgentOutput],
    commandOutputRoot: sharedAgentSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    additionalCommandOutputs: [codexManualOpenAiAgentOutput],
    renderSubagent: renderCodexSubagent,
    installRoot: installRootCodex,
    staticOutputs: codexStaticOutputs,
    // Earlier project installs wrote the instructions to .codex/AGENTS.md, which Codex never reads
    // (contract Migration step 4).
    movedRoutes: [{ from: (context) => (context.scope === "project" ? path.join(".codex", "AGENTS.md") : null), to: codexInstructionPath }],
    mcpConfig: {
      relativeOutput: () => path.join(".codex", "config.toml"),
      format: "codex-toml",
      defaultEnabled: true,
      rootProperties: {
        approval_policy: "never",
        sandbox_mode: "danger-full-access",
      },
      // Under approval_policy "never" Codex refuses every MCP tool call that needs approval, Synapse's
      // writes included; approving the server's tools by default lets them run. Codex also starts an MCP
      // server with only an allowlisted environment but a hook with the shell's, so the routing variables
      // pass through and the server opens the store the Synapse hook reads.
      serverProperties: { synapse: { default_tools_approval_mode: "approve", env_vars: SYNAPSE_ROUTING_ENV } },
    },
  },
  deepagents: {
    label: "Deep Agents Code skills, instructions, subagents, and MCP",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "deepagents",
    subagentOutputRoot: deepagentsAgentRoot,
    subagentOutputName: deepagentsSubagentOutputName,
    externalSkillOutputRoot: deepagentsSkillRoot,
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: deepagentsSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: deepagentsSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    staticOutputs: deepagentsStaticOutputs,
    mcpConfig: {
      relativeOutput: deepagentsMcpPath,
      format: "mcpServers",
      defaultEnabled: true,
      // dcode mounts every server through FastMCP's proxy, which advertises MCP roots it cannot serve.
      // It starts trusted project servers in the session directory but user-level ones in its server's
      // work directory, so only a project install can key Synapse by cwd. A project install rooted at
      // the home directory writes the user-level file, so it keeps the fail-closed default.
      serverEnv: (context) => (context.scope === "project" && !isHomeRoot(context.installRoot)
        ? { synapse: { SYNAPSE_ROOTS: "ignore" } }
        : null),
    },
  },
  goose: {
    label: "Goose reusable recipes and MCP",
    commandRenders: ["recipes", "skills"],
    skillRenders: ["skills"],
    skillOutputRoot: gooseSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    // Goose looks up a project recipe by name in the working directory, .agents/recipes and
    // .goose/recipes, never under a bare recipes/ directory.
    commandOutputRoot: (context) => context.scope === "user" ? gooseSkillRoot(context) : path.join(".goose", "recipes"),
    commandOutputName: (source, context) => context.scope === "user" ? codexSkillOutputName(source) : gooseRecipeOutputName(source),
    renderCommand: (source, context) => context.scope === "user" ? renderManualPortableSkill(source, context) : renderGooseRecipe(source),
    installRoot: installRootUserOrProject,
    mcpConfig: {
      // Goose MCP lives in the user-global config.yaml (`extensions:`), so it is user-scope
      // only. Project commands remain recipes; user commands use Agent Skills.
      relativeOutput: gooseMcpPath,
      format: "goose-extensions",
      defaultEnabled: true,
      scopes: ["user"],
    },
    // Windows user installs before the per-OS route merged into ~/.config/goose/config.yaml, which
    // Windows Goose never reads.
    cleanupConfigRoutes: [{
      relativeOutput: (context) => windowsUserRoute(context, path.join(".config", "goose", "config.yaml")),
      format: "goose-extensions",
    }],
  },
  "grok-build": {
    label: "Grok Build skills, agents and instructions",
    commandRenders: ["skills"],
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "grok-build",
    subagentOutputRoot: grokBuildAgentRoot,
    skillOutputRoot: grokBuildSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: grokBuildSkillRoot,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: grokBuildSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    staticOutputs: grokBuildStaticOutputs,
    mcpConfig: {
      relativeOutput: () => path.join(".grok", "config.toml"),
      format: "codex-toml",
      defaultEnabled: true,
      rootProperties: (context) => context.scope === "user"
        ? { ui: { permission_mode: "always-approve" } }
        : {},
    },
    cleanupConfigRoutes: [{
      relativeOutput: () => path.join(".grok", "settings.json"),
      format: "mcpServers",
    }],
  },
  dsh: {
    label: "DSH Agent Skills",
    skillRenders: ["skills"],
    skillOutputRoot: dshSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: dshSkillRoot,
    renderSkill: renderVanillaSkill,
    installRoot: installRootUserOrProject,
  },
  pi: {
    label: "Pi skills and instructions",
    commandRenders: ["skills"],
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: piSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: piSkillRoot,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: piSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    installRoot: installRootUserOrProject,
    staticOutputs: piStaticOutputs,
    mcpConfig: {
      relativeOutput: piMcpPath,
      format: "mcpServers",
      defaultEnabled: true,
    },
  },
  pool: {
    label: "Poolside skills and instructions",
    commandRenders: ["skills"],
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: poolSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: poolSkillRoot,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: poolSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    installRoot: installRootUserOrProject,
    staticOutputs: poolStaticOutputs,
    // Earlier installs wrote the personal instructions to .poolside (contract Migration step 4).
    movedRoutes: [{ from: (context) => (context.scope === "user" ? path.join(".config", "poolside", ".poolside") : null), to: poolInstructionPath }],
    mcpConfig: {
      relativeOutput: (context) => context.scope === "user"
        ? path.join(".config", "poolside", "settings.yaml")
        : path.join(".poolside", "settings.yaml"),
      format: "poolside-mcp",
      defaultEnabled: true,
    },
  },
  cline: {
    label: "Cline workflows, rules, skills, configured agents, and MCP",
    commandRenders: ["commands-as-workflows"],
    subagentRenders: ["subagents"],
    subagentTarget: "cline",
    subagentOutputRoot: clineAgentRoot,
    subagentOutputExtension: ".yaml",
    externalSkillOutputRoot: clineSkillRoot,
    skillRenders: ["skills"],
    skillOutputRoot: clineSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    staticRenders: ["rules"],
    commandOutputRoot: clineWorkflowRoot,
    renderCommand: renderClineWorkflow,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    ignoreFilename: ".clineignore",
    staticOutputs: clineStaticOutputs,
    userDocumentsOutputs: clineDocumentsOutputs,
    relocatedRoutes: clineRelocatedRoutes,
    mcpConfigs: [
      {
        relativeOutput: clineMcpPath,
        format: "mcpServers",
        defaultEnabled: true,
        scopes: ["user"],
      },
      {
        relativeOutput: clineVsCodeExtensionMcpPath,
        format: "mcpServers",
        defaultEnabled: true,
        scopes: ["user"],
        emitOutput: false,
        allowAbsoluteOutput: true,
        editorExtension: { ...CLINE_EXTENSION, extensionsDir: ".vscode" },
      },
      {
        relativeOutput: clineCursorExtensionMcpPath,
        format: "mcpServers",
        defaultEnabled: true,
        scopes: ["user"],
        emitOutput: false,
        allowAbsoluteOutput: true,
        editorExtension: { ...CLINE_EXTENSION, extensionsDir: ".cursor" },
      },
      {
        relativeOutput: clineWindsurfExtensionMcpPath,
        format: "mcpServers",
        defaultEnabled: true,
        scopes: ["user"],
        emitOutput: false,
        allowAbsoluteOutput: true,
        editorExtension: { ...CLINE_EXTENSION, extensionsDir: ".windsurf" },
      },
      // Devin creates ~/.devin/extensions on its first run, so this guard does not write Devin's user
      // data ahead of Devin's migration from Windsurf, which an existing Devin data folder would skip.
      {
        relativeOutput: clineDevinExtensionMcpPath,
        format: "mcpServers",
        defaultEnabled: true,
        scopes: ["user"],
        emitOutput: false,
        allowAbsoluteOutput: true,
        editorExtension: { ...CLINE_EXTENSION, extensionsDir: ".devin" },
      },
    ],
    cleanupConfigRoutes: [{
      relativeOutput: () => path.join(".cline", "mcp.json"),
      format: "mcpServers",
    }],
  },
  kilo: {
    label: "Kilo workflows, instructions, and subagents",
    commandRenders: ["commands-as-workflows"],
    subagentRenders: ["subagents"],
    subagentTarget: "kilo",
    subagentOutputRoot: kiloAgentRoot,
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: kiloSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: kiloWorkflowRoot,
    renderCommand: renderKiloWorkflow,
    renderSubagent: renderOpenCodeSubagent,
    installRoot: installRootUserOrProject,
    ignoreFilename: ".kilocodeignore",
    staticOutputs: kiloStaticOutputs,
    mcpConfig: {
      relativeOutput: kiloConfigPath,
      format: "local-command-map",
      defaultEnabled: true,
      emitOutput: false,
      rootProperties: {
        permission: { "*": "allow" },
        share: "disabled",
      },
    },
  },
  "kimi-code": {
    label: "Kimi Code skills, instructions, custom agents, and MCP",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "kimi-code",
    subagentOutputRoot: kimiCodeAgentRoot,
    externalSkillOutputRoot: kimiCodeSkillRoot,
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: kimiCodeSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: kimiCodeSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualKimiCodeSkill,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootKimiCode,
    staticOutputs: kimiCodeStaticOutputs,
    // Earlier project installs wrote .kimi-code/AGENTS.md beside the root AGENTS.md Kimi Code also reads.
    movedRoutes: [{ from: (context) => (context.scope === "project" ? path.join(".kimi-code", "AGENTS.md") : null), to: kimiCodeInstructionPath }],
    mcpConfigs: [
      {
        relativeOutput: kimiCodeConfigPath,
        format: "codex-toml",
        defaultEnabled: false,
        includeServices: false,
        // Kimi Code 2.1.1 reads config.toml only from KIMI_CODE_HOME; a project copy is never loaded.
        scopes: ["user"],
        rootProperties: {
          default_permission_mode: "auto",
          merge_all_available_skills: true,
        },
      },
      {
        relativeOutput: kimiCodeMcpPath,
        format: "kimi-mcp",
        defaultEnabled: true,
      },
      {
        relativeOutput: kimiCodeVsCodeSettingsPath,
        format: "json-settings",
        defaultEnabled: false,
        includeServices: false,
        emitOutput: false,
        allowAbsoluteOutput: true,
        scopes: ["user"],
        rootProperties: {
          "kimi.yoloMode": true,
        },
      },
      {
        relativeOutput: kimiCodeCursorSettingsPath,
        format: "json-settings",
        defaultEnabled: false,
        includeServices: false,
        emitOutput: false,
        allowAbsoluteOutput: true,
        scopes: ["user"],
        rootProperties: {
          "kimi.yoloMode": true,
        },
      },
    ],
  },
  qoder: {
    label: "Qoder skills, commands, instructions, subagents, and MCP",
    commandRenders: ["commands"],
    subagentRenders: ["subagents"],
    subagentTarget: "qoder",
    subagentOutputRoot: qoderAgentRoot,
    externalSkillOutputRoot: qoderSkillRoot,
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: qoderSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: qoderCommandRoot,
    commandOutputName: flatMarkdownCommandOutputName,
    renderCommand: renderNativeMarkdownCommand,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    staticOutputs: qoderStaticOutputs,
    mcpConfig: {
      relativeOutput: qoderSettingsPath,
      format: "kimi-mcp",
      defaultEnabled: true,
      rootProperties: {
        general: { defaultPermissionMode: "bypass_permissions" },
        skills: { loadFromAgentsDirectory: false },
      },
    },
  },
  "qwen-code": {
    label: "Qwen Code skills, commands, instructions, subagents, and MCP",
    commandRenders: ["commands"],
    subagentRenders: ["subagents"],
    subagentTarget: "qwen-code",
    subagentOutputRoot: qwenCodeAgentRoot,
    externalSkillOutputRoot: qwenCodeSkillRoot,
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: qwenCodeSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: qwenCodeCommandRoot,
    commandOutputName: flatMarkdownCommandOutputName,
    renderCommand: renderQwenCodeCommand,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    staticOutputs: qwenCodeStaticOutputs,
    // Earlier project installs wrote a root QWEN.md beside the shared AGENTS.md Qwen Code also reads.
    movedRoutes: [{ from: (context) => (context.scope === "project" ? "QWEN.md" : null), to: qwenCodeInstructionPath }],
    mcpConfig: {
      relativeOutput: qwenCodeSettingsPath,
      format: "kimi-mcp",
      defaultEnabled: true,
      rootProperties: {
        tools: { approvalMode: "yolo" },
      },
    },
  },
  kiro: {
    label: "Kiro skills, steering, subagents, permissions, and MCP",
    commandRenders: ["commands-as-workflows"],
    subagentRenders: ["subagents"],
    subagentTarget: "kiro",
    subagentOutputRoot: kiroAgentRoot,
    externalSkillOutputRoot: kiroSkillRoot,
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: kiroSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: kiroSteeringRoot,
    commandOutputName: (source) => `command-${source.name}.md`,
    renderCommand: renderKiroManualSteering,
    renderSubagent: renderKiroSubagent,
    installRoot: installRootUserOrProject,
    staticOutputs: kiroStaticOutputs,
    mcpConfigs: [
      {
        relativeOutput: kiroMcpPath,
        format: "kimi-mcp",
        defaultEnabled: true,
      },
      {
        relativeOutput: kiroPermissionsPath,
        format: "kiro-permissions",
        defaultEnabled: false,
        includeServices: false,
        scopes: ["user"],
        rootProperties: {
          rules: [{ capability: "all", effect: "allow" }],
        },
      },
    ],
  },
  antigravity: {
    label: "Antigravity skills and manual workflows",
    commandRenders: ["commands-as-workflows"],
    skillRenders: ["skills"],
    skillOutputRoot: antigravitySkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: antigravityWorkflowRoot,
    renderCommand: renderAntigravityWorkflow,
    installRoot: installRootAntigravity,
  },
  "antigravity-cli": {
    label: "Antigravity CLI plugin",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "antigravity-cli",
    subagentOutputRoot: path.join("antigravity-cli", "plugins", "agent-surface", "agents"),
    externalSkillOutputRoot: path.join("antigravity-cli", "plugins", "agent-surface", "skills"),
    staticRenders: ["plugins", "rules"],
    skillRenders: ["skills"],
    skillOutputRoot: path.join("antigravity-cli", "plugins", "agent-surface", "skills"),
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: path.join("antigravity-cli", "plugins", "agent-surface", "skills"),
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualSlashSkill,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootAntigravityCli,
    staticOutputs: antigravityCliStaticOutputs,
    mcpConfig: {
      relativeOutput: () => path.join("antigravity-cli", "plugins", "agent-surface", "mcp_config.json"),
      format: "mcpServers",
      defaultEnabled: true,
    },
    // The former direct-import route is trusted only while an old manifest owns it.
    // It is never emitted, so a later runtime-owned import remains untouched.
    cleanupConfigRoutes: [{
      relativeOutput: () => path.join("config", "plugins", "agent-surface", "mcp_config.json"),
      format: "mcpServers",
    }],
  },
  cursor: {
    label: "Cursor global commands, rules, and subagents",
    commandRenders: ["commands"],
    subagentRenders: ["subagents"],
    subagentTarget: "cursor",
    subagentOutputRoot: ".cursor/agents",
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: cursorSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: ".cursor/commands",
    renderCommand: renderCursorCommand,
    renderSubagent: renderCursorSubagent,
    installRoot: installRootHomeOnly,
    ignoreFilename: ".cursorignore",
    staticOutputs: cursorStaticOutputs,
    mcpConfig: {
      relativeOutput: () => path.join(".cursor", "mcp.json"),
      format: "mcpServers",
      defaultEnabled: true,
    },
  },
  droid: {
    label: "Factory Droid commands, instructions, droids, and optional external assets",
    commandRenders: ["commands"],
    subagentRenders: ["subagents"],
    subagentTarget: "droid",
    subagentOutputRoot: path.join(".factory", "droids"),
    // Droid reads `.agents/skills` at the same level as `.factory/skills`, at user and project
    // scope, and ignores one copy of any name found in both, so writing both would load every
    // skill twice whenever another `.agents/skills` host is installed. The shared root is the one
    // copy; commands, droids, rules and MCP stay under `.factory`.
    externalSkillOutputRoot: path.join(".agents", "skills"),
    skillRenders: ["skills"],
    skillOutputRoot: sharedAgentSkillRoot,
    relocatedRoutes: droidRelocatedRoutes,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    staticRenders: ["rules"],
    commandOutputRoot: path.join(".factory", "commands"),
    renderCommand: renderDroidCommand,
    renderSubagent: renderMarkdownSubagent,
    installRoot: installRootUserOrProject,
    staticOutputs: droidStaticOutputs,
    mcpConfig: {
      relativeOutput: () => path.join(".factory", "mcp.json"),
      format: "mcpServers",
      defaultEnabled: true,
    },
  },
  copilot: {
    label: "GitHub Copilot CLI skills, instructions, custom agents, and MCP",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "copilot",
    subagentOutputRoot: copilotAgentRoot,
    subagentOutputName: (source) => `${source.metadata.name}.agent.md`,
    skillRenders: ["skills"],
    skillOutputRoot: copilotSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: copilotSkillRoot,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: copilotSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualSlashSkill,
    renderSubagent: renderMarkdownSubagent,
    staticRenders: ["instructions"],
    installRoot: installRootUserOrProject,
    staticOutputs: copilotStaticOutputs,
    // Earlier user installs wrote the VS Code profile document to Code/User/instructions, which VS
    // Code does not scan, under a Copilot-specific name (contract Migration step 4).
    movedRoutes: [{
      from: (context) => (context.scope === "user"
        ? path.join(vsCodeUserRoot("Code", context), "instructions", "agent-surface-copilot.instructions.md")
        : null),
      to: (context) => path.join(vsCodeUserRoot("Code", context), "prompts", "agent-surface.instructions.md"),
    }],
    mcpConfig: {
      relativeOutput: copilotMcpPath,
      format: "mcpServers",
      defaultEnabled: true,
    },
  },
  vscode: {
    label: "VS Code user skills and instruction files",
    skillRenders: ["skills"],
    skillOutputRoot: sharedAgentSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    // Manual workflows go through Agent Skills, not prompt files. Prompt files were the legacy
    // Local-agent route, and these were additionally emitted as `<name>.md` rather than the
    // `.prompt.md` that route requires, so they were loaded by neither session type. The previous
    // outputs are pruned by the manifest's ownership cleanup like any other renamed managed file.
    //
    // The mapping was read out of the installed VS Code 1.116.0 (stable) build: its built-in
    // user-scope skill locations include `~/.agents/skills`, the root canonical skills already use,
    // and it describes `disable-model-invocation` in-product as preventing automatic loading "for
    // workflows you want to trigger manually". That is evidence about the shipped build, NOT a
    // verified runtime result — discovery and invocation in a live VS Code session remain unproven.
    commandRenders: ["skills"],
    commandOutputRoot: sharedAgentSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    staticRenders: ["instructions"],
    installRoot: installRootVsCode,
    staticOutputs: vscodeStaticOutputs,
    // Earlier installs wrote the profile document to Code/User/instructions, which VS Code does not
    // scan (contract Migration step 4).
    movedRoutes: [{
      from: (context) => (context.scope === "user"
        ? path.join(vsCodeUserRoot("Code", context), "instructions", "agent-surface.instructions.md")
        : null),
      to: (context) => path.join(vsCodeUserRoot("Code", context), "prompts", "agent-surface.instructions.md"),
    }],
    mcpConfig: {
      relativeOutput: (context) => path.join(vsCodeUserRoot("Code", context), "mcp.json"),
      format: "vscode-servers",
      defaultEnabled: true,
    },
  },
  opencode: {
    label: "OpenCode commands, agents, and global instructions",
    commandRenders: ["commands"],
    subagentRenders: ["subagents"],
    subagentTarget: "opencode",
    subagentOutputRoot: opencodeAgentRoot,
    commandOutputRoot: opencodeCommandRoot,
    skillRenders: ["skills"],
    skillOutputRoot: opencodeSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    renderCommand: renderOpenCodeCommand,
    renderSubagent: renderOpenCodeSubagent,
    staticRenders: ["rules"],
    installRoot: installRootUserOrProject,
    staticOutputs: opencodeStaticOutputs,
    mcpConfig: {
      relativeOutput: opencodeMcpPath,
      format: "local-command-map",
      defaultEnabled: true,
      rootProperties: {
        permission: { "*": "allow" },
        share: "disabled",
      },
      replaceRootProperties: ["permission"],
    },
  },
  openhands: {
    label: "OpenHands AgentSkills, instructions, and MCP",
    commandRenders: ["skills"],
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: openhandsSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: openhandsSkillRoot,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: openhandsSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    installRoot: installRootUserOrProject,
    staticOutputs: openhandsStaticOutputs,
    mcpConfig: {
      relativeOutput: openhandsMcpPath,
      format: "mcpServers",
      defaultEnabled: true,
      scopes: ["user"],
      // With two or more servers, OpenHands' FastMCP client proxies them through a client that
      // advertises MCP roots it cannot serve. It starts stdio servers in its launch directory, which
      // is the workspace unless OPENHANDS_WORK_DIR names another one.
      serverEnv: { synapse: { SYNAPSE_ROOTS: "ignore" } },
    },
  },
  // Trae splits by root set (contract Target and Runtime Identity): the international IDE, the CN IDE
  // and Trae CLI 2.0. The international IDE and the CLI co-own the ~/.trae skill and agent roots.
  trae: {
    label: "Trae international IDE skills, rules, subagents, and MCP",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "trae",
    subagentOutputRoot: traeCnAgentRoot,
    skillRenders: ["skills"],
    skillOutputRoot: traeSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: traeSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    renderSubagent: renderMarkdownSubagent,
    staticRenders: ["rules"],
    installRoot: installRootHomeOnly,
    staticOutputs: traeStaticOutputs,
    mcpConfigs: [{
      relativeOutput: traeMcpPath("Trae"),
      format: "mcpServers",
      defaultEnabled: true,
      emitOutput: false,
      allowAbsoluteOutput: true,
      ideUserData: true,
    }],
    // Before the split this key merged a user ~/.trae/mcp.json that no Trae build reads.
    cleanupConfigRoutes: [{
      relativeOutput: () => path.join(".trae", "mcp.json"),
      format: "mcpServers",
    }],
    // What this key wrote for the CN IDE and the CLI before the split now belongs to their keys, and
    // stays untouched here until their own manifests claim it (contract Migration step 3). The
    // international IDE keeps writing ~/.trae-cn/agents, which its documentation names.
    successors: [
      { target: "trae-cn", paths: [path.join(".trae-cn", "user_rules")] },
      { target: "trae-cli", configRoutes: [{ relativeOutput: traeCliConfigPath, format: "codex-toml" }] },
    ],
  },
  "trae-cn": {
    label: "Trae CN IDE skills, rules, subagents, and MCP",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "trae",
    subagentOutputRoot: traeCnAgentRoot,
    skillRenders: ["skills"],
    skillOutputRoot: traeCnSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: traeCnSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    renderSubagent: renderMarkdownSubagent,
    staticRenders: ["rules"],
    installRoot: installRootHomeOnly,
    staticOutputs: traeCnStaticOutputs,
    mcpConfigs: [{
      relativeOutput: traeMcpPath("Trae CN"),
      format: "mcpServers",
      defaultEnabled: true,
      emitOutput: false,
      allowAbsoluteOutput: true,
      ideUserData: true,
    }],
  },
  "trae-cli": {
    label: "Trae CLI skills, rules, subagents, and config",
    commandRenders: ["skills"],
    subagentRenders: ["subagents"],
    subagentTarget: "trae",
    subagentOutputRoot: traeAgentRoot,
    skillRenders: ["skills"],
    skillOutputRoot: traeSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: traeSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    renderSubagent: renderMarkdownSubagent,
    staticRenders: ["rules"],
    installRoot: installRootHomeOnly,
    staticOutputs: traeCliStaticOutputs,
    mcpConfigs: [{
      relativeOutput: traeCliConfigPath,
      format: "codex-toml",
      defaultEnabled: true,
      scopes: ["user"],
      rootProperties: {
        approval_policy: "never",
        default_permissions: ":danger-full-access",
      },
    }],
  },
  windsurf: {
    label: "Windsurf workflows, rules, and skills",
    commandRenders: ["commands-as-workflows"],
    staticRenders: ["rules"],
    commandOutputRoot: windsurfWorkflowRoot,
    commandOutputName: flatMarkdownCommandOutputName,
    skillRenders: ["skills"],
    skillOutputRoot: windsurfSkillRoot,
    skillOutputName: codexSkillOutputName,
    renderSkill: renderVanillaSkill,
    externalSkillOutputRoot: windsurfSkillRoot,
    renderCommand: renderWindsurfWorkflow,
    installRoot: installRootUserOrProject,
    staticOutputs: windsurfStaticOutputs,
    mcpConfig: {
      relativeOutput: windsurfMcpPath,
      format: "mcpServers",
      defaultEnabled: true,
    },
  },
  zed: {
    label: "Zed skills and instructions",
    commandRenders: ["skills"],
    staticRenders: ["rules"],
    skillRenders: ["skills"],
    skillOutputRoot: zedSkillRoot,
    skillOutputName: codexSkillOutputName,
    externalSkillOutputRoot: zedSkillRoot,
    renderSkill: renderVanillaSkill,
    commandOutputRoot: zedSkillRoot,
    commandOutputName: codexSkillOutputName,
    renderCommand: renderManualPortableSkill,
    installRoot: installRootUserOrProject,
    staticOutputs: zedStaticOutputs,
    mcpConfig: {
      relativeOutput: zedMcpPath,
      format: "zed-context-servers",
      defaultEnabled: true,
    },
    // Windows user installs before the per-OS route wrote ~/.config/zed, which Windows Zed never reads.
    cleanupConfigRoutes: [{
      relativeOutput: (context) => windowsUserRoute(context, path.join(".config", "zed", "settings.json")),
      format: "zed-context-servers",
    }],
    movedRoutes: [{ from: (context) => windowsUserRoute(context, path.join(".config", "zed", "AGENTS.md")), to: zedInstructionPath }],
  },
  // An EXPORT format, not a host to install into. It renders a portable plugin package plus the
  // local marketplace manifest that the host's own `plugin marketplace add` / `plugin add` consume,
  // so distribution stays the host's job and agent-surface never becomes a plugin manager. Marked
  // buildOnly for that reason: `install` would have to decide where a package "belongs", which is
  // exactly the decision the native manager already owns.
  "codex-plugin": {
    label: "Portable plugin package and local marketplace manifest (export only)",
    buildOnly: true,
    staticRenders: ["plugins", "skills"],
    staticOutputs: codexPluginPackageOutputs,
  },
};

// Full user-scope installs run these cleanup-only adapters before active targets.
// They are not build targets and cannot be selected directly.
export const retiredInstallTargets = {
  "gemini-cli": {
    label: "retired Gemini CLI cleanup",
    installRoot: installRootHomeOnly,
    cleanupConfigRoutes: [{
      relativeOutput: () => path.join(".gemini", "settings.json"),
      format: "mcpServers",
    }],
  },
  vscodium: {
    label: "retired VSCodium cleanup",
    installRoot: installRootHomeOnly,
    mcpConfig: {
      relativeOutput: (context) => path.join(vsCodeUserRoot("VSCodium", context), "mcp.json"),
      format: "vscode-servers",
      defaultEnabled: false,
      scopes: [],
    },
  },
};

export const generatedOutputMinimums = new Map([
  // The export package is a narrow pilot, not a catalog: the plugin manifest, the marketplace
  // manifest, one skill, and the companions that skill ships with. The floor only has to catch an
  // export that silently collapsed.
  ["codex-plugin", 6],
  ["claude-code", 250],
  ["codex", 300],
  ["deepagents", 250],
  ["goose", 50],
  ["grok-build", 250],
  ["dsh", 250],
  ["pi", 250],
  ["pool", 250],
  ["cline", 50],
  ["kilo", 60],
  ["kimi-code", 250],
  ["qoder", 250],
  ["qwen-code", 250],
  ["kiro", 250],
  ["antigravity", 50],
  ["antigravity-cli", 250],
  ["cursor", 60],
  ["droid", 250],
  ["copilot", 250],
  ["vscode", 1],
  ["opencode", 55],
  ["openhands", 250],
  ["trae", 1],
  ["trae-cn", 1],
  ["trae-cli", 1],
  ["windsurf", 250],
  ["zed", 250],
]);

export const MAX_EXTERNAL_TOTAL_BYTES = 200_000_000;

export const MAX_EXTERNAL_FILES = 50_000;

export function targetProducers(adapter) {
  const producers = [];
  if (adapter.renderSkill || (adapter.additionalSkillOutputs?.length ?? 0) > 0) {
    producers.push({ id: "skills", sourceKind: "skills", emits: adapter.skillRenders ?? ["skills"], produce: (catalog, context) => produceSkillOutputs(adapter, catalog.skills, context) });
  }
  if (adapter.renderCommand || (adapter.additionalCommandOutputs?.length ?? 0) > 0) {
    producers.push({ id: "commands", sourceKind: "commands", emits: adapter.commandRenders ?? ["commands"], produce: (catalog, context) => produceCommandOutputs(adapter, catalog.commands, context) });
  }
  if (adapter.staticOutputs) {
    producers.push({ id: "static", sourceKind: "rules", emits: adapter.staticRenders ?? [], produce: (catalog, context) => adapter.staticOutputs(catalog, context) });
  }
  if (adapter.externalSkillOutputRoot || adapter.skillOutputRoot) {
    producers.push({ id: "external-skills", sourceKind: "external", emits: ["external"], produce: (_commands, context) => externalSkillOutputs(adapter, context) });
  }
  if (adapter.subagentOutputRoot && adapter.renderSubagent) {
    producers.push({ id: "subagents", sourceKind: "subagents", emits: adapter.subagentRenders ?? ["subagents"], produce: (commands, context) => subagentOutputs(adapter, context) });
  }
  if (adapter.ignoreFilename) {
    producers.push({ id: "ignores", sourceKind: "ignores", emits: ["ignores"], produce: () => ignoreOutputs(adapter) });
  }
  if (adapterMcpConfigs(adapter).length > 0) {
    producers.push({ id: "mcps", sourceKind: "external", emits: ["mcps"], produce: (_commands, context) => optionalMcpOutputs(adapter, context) });
  }
  return producers;
}
export async function targetOutputs(adapter, catalog, context) {
  const outputs = [];
  const selectedCategories = selectedAssetCategories(context.categoryFilter);
  // The aggregate always-on instruction document is owned by whichever selected asset category
  // actually supplies always-on rules. Resolve it across the WHOLE selection (not just a single
  // category) so a combined install like `--category development,cybersecurity` still emits the
  // always-on rules instead of installing that category's skills without its instruction document.
  const contextRules = await readRulesForContext(context);
  const selectedRuleCategory = [...selectedCategories].find(
    (category) => contextRules.some((rule) => rule.assetCategory === category && rule.alwaysApply !== false),
  ) ?? null;

  for (const producer of targetProducers(adapter)) {
    const produced = await producer.produce(catalog, context);
    outputs.push(...produced.map((output) => {
      const sourceKind = output.sourceKind ?? producer.sourceKind;
      return {
        ...output,
        producerId: producer.id,
        sourceKind,
        renderKind: output.renderKind ?? producerDefaultRenderKind(producer),
        assetCategory: output.assetCategory ?? (sourceKind === "rules" ? selectedRuleCategory : undefined),
      };
    }));
  }

  // Placement that depends on the machine applies to installs only, so builds stay machine-independent.
  const placed = context.mode === "install" && adapter.userDocumentsOutputs ? adapter.userDocumentsOutputs(outputs, context) : outputs;
  const seen = new Map();
  for (const output of placed) {
    if (!isSafeRelativePath(output.relativeOutput)) fail(`unsafe generated output path: ${output.relativeOutput}`);
    const previous = seen.get(output.relativeOutput);
    if (previous) {
      fail(
        `duplicate generated output path: ${output.relativeOutput} (${previous.producerId}:${previous.source} and ${output.producerId}:${output.source})`,
      );
    }
    seen.set(output.relativeOutput, output);
  }

  return placed.sort((left, right) => left.relativeOutput.localeCompare(right.relativeOutput));
}

export function producerEmitsFor(adapter) {
  const emits = new Set();
  for (const producer of targetProducers(adapter)) {
    for (const token of producer.emits ?? []) emits.add(token);
  }
  return emits;
}

export function producerDefaultRenderKind(producer) {
  return producer.emits?.length === 1 ? producer.emits[0] : producer.id;
}

export async function produceCommandOutputs(adapter, commands, context) {
  // Some adapters restrict where their command artifacts may be installed. Build
  // (dist inspection) is never gated; only live install writes are.
  if (adapter.commandInstallScopes && context.mode === "install" && !adapter.commandInstallScopes.includes(context.scope)) {
    return [];
  }
  const outputs = [];
  const categories = await readAssetCategories();
  for (const command of commands) {
    const assetCategory = assetCategoryFor(categories, "commands", command.name);
    if (!assetCategoryAllowed(context, assetCategory)) continue;
    if (adapter.renderCommand) {
      outputs.push({
        source: command.relativePath,
        relativeOutput: commandRelativeOutput(adapter, command, context),
        content: await adapter.renderCommand(command, context),
        assetCategory,
      });
    }

    for (const buildOutput of adapter.additionalCommandOutputs ?? []) {
      outputs.push({ ...await buildOutput(command, context), assetCategory });
    }
  }
  return outputs;
}

// Companion files ride beside their SKILL.md, so a relative reference in the body resolves from the
// INSTALLED location rather than the source checkout. Each is its own managed output, which is what
// makes ownership cleanup remove a deleted one without special handling. Gated on the destination
// actually being a directory-shaped skill surface: an adapter that flattens a skill to a single
// file, or a metadata sidecar such as Codex's agents/openai.yaml, has nowhere to put them, and a
// guessed path would not resolve.
function skillCompanionOutputs(skill, relativeOutput, assetCategory) {
  if (path.basename(relativeOutput) !== "SKILL.md") return [];
  const skillDirectory = path.dirname(relativeOutput);
  return (skill.resources ?? []).map((resource) => ({
    source: resource.relativePath,
    relativeOutput: path.join(skillDirectory, resource.resourcePath),
    content: resource.text,
    mode: resource.executable ? 0o755 : undefined,
    assetCategory,
  }));
}

export async function produceSkillOutputs(adapter, skills, context) {
  const outputs = [];
  const categories = await readAssetCategories();
  for (const skill of skills) {
    const assetCategory = assetCategoryFor(categories, "skills", skill.name);
    if (!assetCategoryAllowed(context, assetCategory)) continue;
    if (adapter.renderSkill) {
      const relativeOutput = skillRelativeOutput(adapter, skill, context);
      outputs.push({
        source: skill.relativePath,
        relativeOutput,
        content: await adapter.renderSkill(skill, context),
        assetCategory,
      });
      outputs.push(...skillCompanionOutputs(skill, relativeOutput, assetCategory));
    }
    // An additional output is metadata beside the skill (Codex's agents/openai.yaml), not a second
    // skill directory, so it carries no companions.
    for (const buildOutput of adapter.additionalSkillOutputs ?? []) {
      outputs.push({ ...await buildOutput(skill, context), assetCategory });
    }
  }
  return outputs;
}

export async function externalSkillOutputs(adapter, context) {
  const externalOutputRoot = adapter.externalSkillOutputRoot ?? adapter.skillOutputRoot;
  if (!externalOutputRoot) return [];
  // Uncategorized required packs are part of the default distribution. Optional general
  // packs and categorized packs require their matching category; build mode keeps the full
  // superset for generated-output validation.
  if (
    context.mode === "install"
    && context.categoryFilter
    && !context.categoryFilter.has("external")
    && selectedAssetCategories(context.categoryFilter).size === 0
  ) return [];
  const outputs = [];
  const includeOptional = context.mode !== "install"
    || Boolean(context.categoryFilter?.has("external"))
    || selectedAssetCategories(context.categoryFilter).size > 0;
  const roots = await externalSkillRoots({ includeOptional, context });
  const outputRoot = outputRootFor(externalOutputRoot, context);

  let totalBytes = 0;
  for (const { root: sourceRoot, serviceName, assetCategory, licenseFile, noticeFiles } of roots) {
    const skillName = path.basename(sourceRoot);
    const skillFiles = (await filesUnder(sourceRoot, SKILL_RESOURCE_EXTENSIONS)).map((file) => [file, path.relative(sourceRoot, file)]);
    // Among license files the allowlist admits a bare LICENSE only; a skill's own COPYING, LICENCE or
    // LICENSE-MIT ships as well, since it outranks the pack's license.
    const rootLicenses = (await readdir(sourceRoot, { withFileTypes: true }))
      .filter((entry) => entry.isFile() && SKILL_LICENSE_RE.test(entry.name)).map((entry) => entry.name).sort();
    for (const name of rootLicenses) {
      if (!skillFiles.some(([, relativeFile]) => relativeFile === name)) skillFiles.push([path.join(sourceRoot, name), name]);
    }
    // Deliver the pack's upstream license as the skill's LICENSE unless the skill already delivers its
    // own, and each further upstream notice under its own name unless the skill ships that file.
    const packFiles = [];
    if (licenseFile && !skillFiles.some(([, relativeFile]) => SKILL_LICENSE_RE.test(relativeFile))) {
      packFiles.push([licenseFile, "LICENSE", "license_file"]);
    }
    for (const noticeFile of noticeFiles) {
      const name = path.basename(noticeFile);
      if (![...skillFiles, ...packFiles].some(([, relativeFile]) => relativeFile === name)) packFiles.push([noticeFile, name, "notice_files"]);
    }
    for (const [file, relativeFile, field] of packFiles) {
      // Like filesUnder, accept only a regular file, so a symlink cannot pull in a host file.
      const info = await lstat(file).catch(() => null);
      if (!info) fail(`pack ${serviceName}: ${field} is missing: ${relative(file)}`);
      else if (!info.isFile()) fail(`pack ${serviceName}: ${field} is not a regular file: ${relative(file)}`);
      skillFiles.push([file, relativeFile]);
    }
    for (const [file, relativeFile] of skillFiles) {
      if (outputs.length >= MAX_EXTERNAL_FILES) {
        const detail = `external skill output cap reached (${MAX_EXTERNAL_FILES} files)`;
        fail(`${detail}; pack ${serviceName} would be truncated`);
      }
      const size = (await stat(file)).size;
      if (totalBytes + size > MAX_EXTERNAL_TOTAL_BYTES) {
        const detail = `external skill total-size cap reached (${MAX_EXTERNAL_TOTAL_BYTES} bytes)`;
        fail(`${detail}; pack ${serviceName} would be truncated`);
      }
      totalBytes += size;
      outputs.push({
        sourceKind: "external",
        renderKind: "external",
        source: relative(file),
        relativeOutput: path.join(outputRoot, skillName, relativeFile),
        content: normalizeExternalSkillFile(relativeFile, await readFile(file, "utf8"), skillName),
        assetCategory,
      });
    }
  }

  return outputs;
}

export async function optionalMcpOutputs(adapter, context) {
  const outputs = [];
  const categories = await readAssetCategories();
  for (const mcpConfig of adapterMcpConfigs(adapter)) {
    if (mcpConfig.emitOutput === false) continue;
    if (context.mode === "install" && mcpConfig.installMode !== "write") continue;
    if (!mcpConfigScopeAllows(mcpConfig, context.scope)) continue;

    const entries = mcpConfig.includeServices === false
      ? []
      : withMcpServerOverrides(await selectedMcpServiceEntries(mcpConfig.defaultEnabled, context), mcpConfig, context);
    const rootProperties = mcpConfigRootProperties(mcpConfig, context);
    if (entries.length === 0 && Object.keys(rootProperties).length === 0) continue;
    const entryCategories = [...new Set(entries.map(([id]) => assetCategoryFor(categories, "services", id)).filter(Boolean))];
    outputs.push({
      sourceKind: "external",
      renderKind: "mcps",
      source: "registry/optional-services.json",
      relativeOutput: outputRootFor(mcpConfig.relativeOutput, context),
      content: renderMcpConfig(mcpConfig.format, entries, rootProperties),
      assetCategory: entryCategories.length === 1 ? entryCategories[0] : null,
    });
  }
  return outputs;
}

// By real path where one resolves, so a symlinked or differently cased --dest naming the home
// directory still counts as home.
function isHomeRoot(root) {
  if (!root) return false;
  const real = (candidate) => {
    try { return realpathSync(candidate); } catch { return path.resolve(candidate); }
  };
  return samePath(real(root), real(os.homedir()));
}

// What a host's MCP config sets on particular servers, keyed by service id: serverEnv (an object or a
// function of the install context) merges over any env the service itself declares, and
// serverProperties adds host-specific keys to the server's entry (TOML configs only).
export function withMcpServerOverrides(entries, mcpConfig, context) {
  const serverEnv = (typeof mcpConfig.serverEnv === "function" ? mcpConfig.serverEnv(context) : mcpConfig.serverEnv) ?? {};
  const serverProperties = mcpConfig.serverProperties ?? {};
  return entries.map(([id, service]) => {
    const server = service.mcp?.server;
    if (!server || (!serverEnv[id] && !serverProperties[id])) return [id, service];
    const overridden = { ...server };
    if (serverEnv[id]) overridden.env = { ...server.env, ...serverEnv[id] };
    if (serverProperties[id]) overridden.properties = serverProperties[id];
    return [id, { ...service, mcp: { ...service.mcp, server: overridden } }];
  });
}

export async function selectedMcpServiceEntries(defaultEnabled, context) {
  const selectedCategories = selectedAssetCategories(context.categoryFilter);
  const explicitMcp = context.categoryFilter?.has("mcps") || context.optionalServices || selectedCategories.size > 0;
  if (!defaultEnabled && !explicitMcp) return [];

  const registry = await readOptionalServices();
  const categories = await readAssetCategories();
  // `--category mcps` selects first-party MCPs only. Non-first-party MCPs require
  // either an explicit service id or membership in an explicitly selected asset category.
  const entries = Object.entries(registry.services)
    .filter(([, service]) => service.kind === "mcp")
    .filter(([id]) => !context.optionalServices || context.optionalServices.has(id))
    .filter(([id, service]) => {
      if (context.optionalServices) return true;
      if (selectedCategories.size > 0) {
        const category = assetCategoryFor(categories, "services", id);
        return category !== null && selectedCategories.has(category);
      }
      return service.first_party === true && assetCategoryFor(categories, "services", id) === null;
    });
  // Validate the requested set against the FULL selection before excluding anything, so a service the
  // user explicitly asked for is never reported "missing" merely because its prerequisites failed.
  if (context.optionalServices) {
    const known = new Set(entries.map(([id]) => id));
    for (const id of context.optionalServices) {
      if (!known.has(id)) fail(`missing optional MCP service: ${id}`);
    }
  }
  // A service whose prerequisites could not be provisioned this run is dropped from every config
  // merge at once (this is the single chokepoint), so it is never wired against a missing binary.
  const included = context.excludeServices
    ? entries.filter(([id]) => !context.excludeServices.has(id))
    : entries;
  const sorted = included.sort(([left], [right]) => left.localeCompare(right));
  // Only servers that declare credentials launch through the shared env-loader wrapper: it loads
  // the resolved credential env-file (ambient env wins) then execs the real command with stdio +
  // working directory preserved. Keyless servers (synapse, grimoire) keep their direct launch path
  // unchanged. The real command moves into args after "--"; a literal "~" there is resolved by the
  // launcher at runtime. At install time the installer-resolved env-file path is baked in as an
  // absolute --as-env-file so the launcher loads exactly the file the installer validated,
  // independent of the launch working directory. Clone so the cached registry object is never
  // mutated.
  // Build/dist keeps the machine-agnostic stub path so generated output never embeds a host's Node
  // (or its platform); only an install resolves the platform's real invocation — on Windows the
  // pinned node.exe plus the launcher module, since there is no shebang there and hosts cannot
  // spawn a .cmd stub.
  const launcher = context.mode === "install"
    ? mcpLauncherInvocation({ platform: context.platform ?? process.platform })
    : { command: MCP_ENV_LAUNCHER, argsPrefix: [] };
  const wrapped = sorted.map(([id, service]) => {
    const server = service.mcp?.server;
    if (!server || typeof server.command !== "string") return [id, service];
    // Wrap when the server carries credentials (env delivery) OR when its resolved launch binary
    // defers to `/usr/bin/env <interp>`: that entire process chain resolves the interpreter through
    // PATH, which a host's minimal PATH breaks (an absolute npx is not enough — npx then spawns the
    // server's own `#!/usr/bin/env node` bin). Servers launching a real binary or an absolute-
    // interpreter script (synapse/grimoire are `#!/bin/sh`) keep their direct launch path.
    if (!serviceHasCredentials(service) && !launchNeedsRuntimePath(id, context)) return [id, service];
    // Only a server that DECLARES credentials is handed the env-file: a server wrapped purely to get
    // the validated Node on PATH must not receive the project's secrets.
    const envArgs = serviceHasCredentials(service) && context.mode === "install" && context.envFilePath
      ? ["--as-env-file", context.envFilePath]
      : [];
    // Launch the real binary by the ABSOLUTE path provisioning resolved (when the registry command is
    // a bare name), so the wrapper never depends on the launch environment's PATH to find a tool
    // installed into a directory the host does not have on PATH.
    const launchCommand = launchCommandFor(id, server.command, context);
    return [id, {
      ...service,
      mcp: { ...service.mcp, server: { ...server, command: launcher.command, args: [...launcher.argsPrefix, ...envArgs, "--", launchCommand, ...(server.args ?? []), ...launchArgsFor(id, context)] } },
    }];
  });
  // Hosts posix_spawn the stdio command directly (no shell), so a literal "~" in the command the
  // host launches is never expanded and fails (ENOENT). At install time resolve a bare command to
  // the provisioning-resolved absolute path, then resolve a leading "~/" to an absolute $HOME path;
  // dist/build keeps "~" so generated output stays machine-agnostic and reproducible. (A wrapped
  // server's command is the launcher — its inner command was already resolved above.)
  if (context.mode !== "install") return wrapped;
  return wrapped.map(([id, service]) => {
    const server = service.mcp?.server;
    if (!server || typeof server.command !== "string") return [id, service];
    // Note the wrapper BEFORE tilde expansion — expanding it to an absolute path would otherwise make
    // the "already wrapped" test below fail and append the launch args a second time.
    const isWrapped = server.command === launcher.command;
    let command = server.command;
    if (!isWrapped) command = launchCommandFor(id, command, context);
    if (command.startsWith("~/")) command = path.join(os.homedir(), command.slice(2));
    // A wrapped server already had its args augmented above; a non-wrapped server appends its
    // provisioning launch args (e.g. --executablePath <browser>) to its own args here.
    const extraArgs = isWrapped ? [] : launchArgsFor(id, context);
    const args = extraArgs.length > 0 ? [...(server.args ?? []), ...extraArgs] : null;
    if (command === server.command && !args) return [id, service];
    return [id, { ...service, mcp: { ...service.mcp, server: { ...server, command, ...(args ? { args } : {}) } } }];
  });
}

// A resolved absolute launch path from provisioning replaces a BARE registry command (no "/" or
// "~") and a HOME-relative one ("~/…"): in both cases the registry names a binary whose real
// location provisioning just determined by detecting it. The HOME-relative case matters because the
// installed FILENAME is not always the registry spelling — the first-party launchers are
// `synapse-bridge` on POSIX and `synapse-bridge.cmd` on Windows — so expanding the registry text
// would point at a file that does not exist there. A command carrying a real path is left untouched.
function launchCommandFor(id, command, context) {
  if (typeof command !== "string") return command;
  const homeRelative = command.startsWith("~/");
  if (!homeRelative && (command.includes("/") || command.includes("\\") || command.startsWith("~"))) return command;
  return context.launchWiring?.[id]?.command ?? command;
}

// Launch args a prerequisite contributed (e.g. --executablePath <resolved browser>), appended to the
// real command's args so the server is told which provisioned binary to drive.
function launchArgsFor(id, context) {
  return context.launchWiring?.[id]?.args ?? [];
}

// True when a file begins with a `#!/usr/bin/env <interp>` shebang — it can only start when <interp>
// is on PATH. Only the first bytes are read, so a real (large) binary is never slurped.
function usesEnvShebang(file) {
  let fd;
  try {
    fd = openSync(file, "r");
    const buffer = Buffer.alloc(128);
    const bytes = readSync(fd, buffer, 0, 128, 0);
    return /^#!\s*\/usr\/bin\/env\s+\S/.test(buffer.subarray(0, bytes).toString("utf8").split("\n", 1)[0]);
  } catch {
    return false;
  } finally {
    if (fd !== undefined) closeSync(fd);
  }
}

// Only meaningful at install time, where provisioning has resolved the launch binary's real path.
// POSIX: a `#!/usr/bin/env <interp>` script (and everything it spawns) needs the interpreter on
// PATH. Windows: npm installs console entry points as `.cmd`/`.bat` shims that fall back to a bare
// `node` whenever node.exe is not adjacent (true for every npx cache dir), and a Node-based host
// cannot spawn a batch file directly at all — both are resolved by going through the wrapper.
function launchNeedsRuntimePath(id, context) {
  if (context.mode !== "install") return false;
  const resolved = context.launchWiring?.[id]?.command;
  if (typeof resolved !== "string") return false;
  const platform = context.platform ?? process.platform;
  const isAbsolute = platform === "win32" ? path.win32.isAbsolute : path.isAbsolute;
  if (!isAbsolute(resolved)) return false;
  return platform === "win32" ? /\.(cmd|bat)$/i.test(resolved) : usesEnvShebang(resolved);
}

// A server needs the env-loader wrapper only if it declares credential keys (required or optional).
function serviceHasCredentials(service) {
  const credentials = service.credentials;
  if (!credentials) return false;
  return (credentials.required?.length ?? 0) + (credentials.optional?.length ?? 0) > 0;
}

export async function externalSkillRoots({ includeOptional = true, context = { mode: "build", categoryFilter: null } } = {}) {
  const registry = await readOptionalServices();
  const categories = await readAssetCategories();
  const candidates = [];
  const declaredPacks = [];

  for (const [serviceName, service] of Object.entries(registry.services)) {
    if (!["skill-pack", "behavior-pack"].includes(service.kind)) continue;
    const assetCategory = assetCategoryFor(categories, "services", serviceName);
    if (!assetCategoryAllowed(context, assetCategory)) continue;
    const required = service.optional === false || service.status === "required";
    if (!required && !includeOptional) continue;
    declaredPacks.push(serviceName);
    const licenseFile = service.license_file === undefined ? null : packFile(serviceName, service, "license_file", service.license_file);
    const noticeFiles = (service.notice_files ?? []).map((file) => packFile(serviceName, service, "notice_files", file));
    for (const item of service.skill_roots ?? []) {
      for (const dir of await expandSkillRoot(item)) {
        candidates.push({ root: dir, serviceName, required, assetCategory, licenseFile, noticeFiles });
      }
    }
  }

  const seen = new Set();
  const existing = [];
  for (const candidate of candidates) {
    const rel = relative(candidate.root);
    if (seen.has(rel)) continue;
    if (await exists(path.join(candidate.root, "SKILL.md"))) {
      seen.add(rel);
      existing.push(candidate);
    }
  }
  for (const serviceName of declaredPacks) {
    if (!existing.some((candidate) => candidate.serviceName === serviceName)) {
      fail(
        `external skill pack ${serviceName} is unavailable; initialize every registered pack with git submodule update --init --recursive`,
      );
    }
  }
  // Required packs first so a total-size cap can never silently drop a required
  // pack in favor of an optional one; ties resolved by path for determinism.
  return existing.sort(
    (left, right) =>
      Number(right.required) - Number(left.required) || relative(left.root).localeCompare(relative(right.root)),
  );
}

const SKILL_LICENSE_RE = /^(?:LICEN[CS]E|COPYING)(?:[.-][A-Za-z0-9.-]+)?$/i;

// Upstream license and notice files usually sit at the repository root, outside every distributed
// skill directory.
function packFile(serviceName, service, field, file) {
  if (typeof file !== "string" || !isSafeRelativePath(file) || !file.startsWith(`${service.path}/`)) {
    fail(`pack ${serviceName}: ${field} must be a safe path inside ${service.path}: ${file}`);
  }
  return path.join(root, file);
}

export async function expandSkillRoot(item) {
  if (typeof item !== "string" || item.length === 0) fail("external skill root must be a non-empty string");
  if (item.includes("*") && !item.endsWith("/*")) fail(`external skill root wildcard must be a trailing /*: ${item}`);
  if (item.endsWith("/*")) {
    const base = safeExternalPath(item.slice(0, -2));
    return directDirectories(base);
  }
  return [safeExternalPath(item)];
}

export function safeExternalPath(item) {
  if (!isSafeRelativePath(item) || !item.startsWith("external/")) fail(`unsafe external skill root: ${item}`);
  return path.join(root, item);
}

export function outputRootFor(value, context) {
  return typeof value === "function" ? value(context) : value;
}

export function outputAppliesToScope(output, scope, sourceKindsConfig) {
  const policy = sourceKindPolicy(sourceKindsConfig, output.sourceKind);
  if (!policy) return false;
  return policy.install_scopes.includes(scope);
}

export function outputAppliesToCategory(output, categoryFilter) {
  if (!categoryFilter) return true;
  const selected = selectedAssetCategories(categoryFilter);
  if (selected.size > 0) {
    return output.requiredForAssetCategories === true
      || (output.assetCategory !== null && selected.has(output.assetCategory));
  }
  return categoryFilter.has(output.renderKind) || categoryFilter.has(output.sourceKind);
}

export async function scopedRuleReferenceOutputs(_context, outputRoot) {
  const rules = (await readRulesForContext(_context)).filter((rule) => rule.alwaysApply === false);
  return rules.map((rule) => ({
    sourceKind: "rules",
    renderKind: "rules",
    source: rule.file,
    relativeOutput: path.join(outputRoot, `${path.basename(rule.file, ".mdc")}.md`),
    content: renderScopedRuleReferenceDocument(rule),
    assetCategory: rule.assetCategory,
  }));
}

// Kilo resolves a relative `instructions` entry against the project directory, even one in the user
// config, so user-scope entries name the rules by home path; Kilo expands a leading `~/`.
export function kiloRuleInstructionRoot(scope) {
  return scope === "user" ? "~/.config/kilo/rules" : ".kilo/rules";
}

export async function kiloRuleInstructionPaths(scope, context = {}) {
  const ruleNames = (await readRulesForContext(context))
    .filter((rule) => rule.alwaysApply !== false)
    .map((rule) => path.basename(rule.file, ".mdc"));
  const prefix = kiloRuleInstructionRoot(scope);
  return ruleNames.map((name) => `${prefix}/${name}.md`);
}

export function commandRelativeOutput(adapter, command, context) {
  return path.join(outputRootFor(adapter.commandOutputRoot, context), adapter.commandOutputName ? adapter.commandOutputName(command, context) : path.basename(command.file));
}

export function skillRelativeOutput(adapter, skill, context) {
  return path.join(outputRootFor(adapter.skillOutputRoot, context), adapter.skillOutputName ? adapter.skillOutputName(skill, context) : path.basename(skill.file));
}

export async function codexOpenAiAgentOutput(source) {
  return codexOpenAiAgentPolicyOutput(source, path.join(".agents", "skills"), true);
}

export async function codexManualOpenAiAgentOutput(source) {
  return codexOpenAiAgentPolicyOutput(source, sharedAgentSkillRoot(), false);
}

export function codexOpenAiAgentPolicyOutput(source, outputRoot, allowImplicitInvocation) {
  const description = foldedBlockScalar(source.metadata.description ?? firstHeading(source.body) ?? `Run ${source.name.replaceAll("-", " ")}.`);
  return {
    source: source.relativePath,
    relativeOutput: path.join(outputRoot, source.name, "agents", "openai.yaml"),
    content: [
      "interface:",
      `  display_name: "${source.name}"`,
      "  short_description: >-",
      `    ${description}`,
      "policy:",
      `  allow_implicit_invocation: ${allowImplicitInvocation}`,
      "",
    ].join("\n"),
  };
}

export function mcpConfigScopeAllows(mcpConfig, scope) {
  return !mcpConfig.scopes || mcpConfig.scopes.includes(scope);
}

export function mcpConfigRootProperties(mcpConfig, context) {
  return (typeof mcpConfig.rootProperties === "function"
    ? mcpConfig.rootProperties(context)
    : mcpConfig.rootProperties) ?? {};
}

export function adapterMcpConfigs(adapter) {
  if (adapter.mcpConfigs) return adapter.mcpConfigs;
  return adapter.mcpConfig ? [adapter.mcpConfig] : [];
}

// The pilot package: one plugin, carrying one canonical skill and the companion files that skill
// already ships with. Deliberately narrow — this exists to prove the packaging path end to end, not
// to become a second distribution channel for the whole catalog.
export const CODEX_PLUGIN_NAME = "agent-surface";
export const CODEX_PLUGIN_SKILLS = ["ops-swarm"];
// Required by the portable manifest schema, whose `$schema` property is a const rather than a hint.
// A manifest without it is invalid, and a host that validates on install rejects the package — the
// reason this identifier is not optional decoration.
export const CODEX_PLUGIN_SCHEMA = "https://agent-plugins.org/schemas/1.0.0/plugin.schema.json";
const CODEX_PLUGIN_ROOT = path.join("plugins", CODEX_PLUGIN_NAME);

export async function codexPluginPackageOutputs(catalog, _context) {
  const version = await packageVersion();
  const outputs = [
    {
      sourceKind: "commands",
      renderKind: "plugins",
      source: "package.json",
      // The portable root manifest, and the only plugin manifest in the package: a valid one is
      // enough. An earlier host-specific copy under `.codex-plugin/` was a misdiagnosis — the
      // install failure it was compensating for came from this manifest omitting `$schema`.
      relativeOutput: path.join(CODEX_PLUGIN_ROOT, "plugin.json"),
      content: `${JSON.stringify({
        $schema: CODEX_PLUGIN_SCHEMA,
        name: CODEX_PLUGIN_NAME,
        version,
        description: "Portable agent-surface skill package generated from Lyther/agent-surface.",
      }, null, 2)}\n`,
    },
    {
      sourceKind: "commands",
      renderKind: "plugins",
      source: "package.json",
      // The local marketplace manifest the host reads. Its location and the way relative plugin
      // sources resolve are both fixed by the host: the manifest lives under `.agents/plugins/`,
      // while `./plugins/<name>` resolves from the marketplace ROOT, not from the manifest's folder.
      relativeOutput: path.join(".agents", "plugins", "marketplace.json"),
      content: `${JSON.stringify({
        name: CODEX_PLUGIN_NAME,
        plugins: [{ name: CODEX_PLUGIN_NAME, source: `./${CODEX_PLUGIN_ROOT.split(path.sep).join("/")}` }],
      }, null, 2)}\n`,
    },
  ];

  for (const name of CODEX_PLUGIN_SKILLS) {
    const skill = catalog.skills.find((item) => item.name === name);
    if (!skill) fail(`codex-plugin package expects canonical skill ${name}`);
    const skillRoot = path.join(CODEX_PLUGIN_ROOT, "skills", skill.name);
    // The canonical source, rendered the same way every other host renders it — not a second copy
    // maintained for packaging.
    outputs.push({
      sourceKind: "skills",
      renderKind: "skills",
      source: skill.relativePath,
      relativeOutput: path.join(skillRoot, "SKILL.md"),
      content: await renderVanillaSkill(skill),
    });
    for (const resource of skill.resources ?? []) {
      outputs.push({
        sourceKind: "skills",
        renderKind: "skills",
        source: resource.relativePath,
        relativeOutput: path.join(skillRoot, resource.resourcePath),
        content: resource.text,
        mode: resource.executable ? 0o755 : undefined,
      });
    }
  }
  return outputs;
}

export async function antigravityCliStaticOutputs(catalog, context) {
  const rules = await readRulesForContext(context);
  const alwaysApplyRules = rules.filter((rule) => rule.alwaysApply !== false);
  return [
    {
      sourceKind: "commands",
      renderKind: "plugins",
      source: "package.json",
      relativeOutput: path.join("antigravity-cli", "plugins", "agent-surface", "plugin.json"),
      requiredForAssetCategories: true,
      content: `${JSON.stringify({
        name: "agent-surface",
        description: "Portable agent-surface command, skill, subagent, and rule pack generated from Lyther/agent-surface.",
      }, null, 2)}\n`,
    },
    {
      sourceKind: "commands",
      renderKind: "plugins",
      source: "README.md",
      relativeOutput: path.join("antigravity-cli", "plugins", "agent-surface", "README.md"),
      content: [
        "# agent-surface Antigravity CLI plugin",
        "",
        "Generated plugin package for Antigravity CLI.",
        "",
        "Validate and register with `agy plugin validate ~/.gemini/antigravity-cli/plugins/agent-surface`, then `agy plugin install ~/.gemini/antigravity-cli/plugins/agent-surface`.",
        "",
        `Packaged skills: ${catalog.skills.length}`,
        "",
      ].join("\n"),
    },
    ...alwaysApplyRules.map((rule) => ({
      sourceKind: "rules",
      renderKind: "rules",
      source: rule.file,
      relativeOutput: path.join("antigravity-cli", "plugins", "agent-surface", "rules", `${path.basename(rule.file, ".mdc")}.md`),
      content: renderAntigravityCliRuleDocument(rule),
      assetCategory: rule.assetCategory,
    })),
    ...await scopedRuleReferenceOutputs(
      context,
      path.join("antigravity-cli", "plugins", "agent-surface", "references", "rules"),
    ),
  ];
}

// Fourteen hosts take the same two things from the rules tree: one always-on instruction document
// and the scoped rule references beside it. Only the document's title and label, its path, and the
// references root differ per host, so each host supplies those and nothing else. Hosts whose rules
// land as one file per rule, or that also write a config document, keep their own producer below.
//
// Several hosts write the workspace AGENTS.md at project scope, where every target shares one install
// root. They all render one target-neutral header there, so co-selected hosts plan identical bytes
// and installing one host never rewrites another's copy just to rename it. A user-scope AGENTS.md at
// a host's own config root (Kimi Code's) is not shared and keeps its host header.
const SHARED_AGENTS_DOCUMENT = { title: "AGENTS.md - agent-surface rules", label: "Project instructions" };

async function rulesDocumentOutputs(context, { title, label, relativeOutput, referencesRoot, renderKind = "rules" }) {
  const shared = context.scope === "project" && relativeOutput === "AGENTS.md";
  const header = shared ? SHARED_AGENTS_DOCUMENT : { title, label };
  const document = { source: "rules/*.mdc", relativeOutput, content: await renderInstructionDocument(header.title, header.label, context) };
  if (renderKind) document.renderKind = renderKind;
  return [document, ...await scopedRuleReferenceOutputs(context, referencesRoot)];
}

export async function clineStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "agent-surface Cline global rules",
    label: "Cline rules",
    relativeOutput: path.join(outputRootFor(clineRuleRoot, context), "agent-surface.md"),
    referencesRoot: path.join(outputRootFor(clineRuleRoot, context), "references", "rules"),
    renderKind: null,
  });
}

// Cline's pre-SDK extension (3.x and most 4.x installs) reads user workflows and rules under the OS
// Documents folder (context.documentsDir), while the CLI and the SDK bundle read ~/Documents/Cline.
// When the OS folder is elsewhere in the home, a user install writes both. The SDK also scans
// ~/Cline/Rules and each OneDrive account's Documents for rules, so rules under one of those go
// there alone rather than load twice; workflows have no such second route.
export function clineDocumentsOutputs(outputs, context) {
  if (context.scope !== "user" || !context.documentsDir) return outputs;
  const relativeDocuments = path.relative(os.homedir(), context.documentsDir);
  const insideHome = relativeDocuments === "" || isSafeRelativePath(relativeDocuments);
  if (!insideHome || samePath(context.documentsDir, path.join(os.homedir(), "Documents"))) return outputs;
  const ruleRoot = outputRootFor(clineRuleRoot, context);
  const roots = [outputRootFor(clineWorkflowRoot, context), ruleRoot];
  const rulesMove = [os.homedir(), ...oneDriveDocumentsDirs()].some((dir) => samePath(dir, context.documentsDir));
  return outputs.flatMap((output) => {
    if (!roots.some((root) => isPathInside(root, output.relativeOutput))) return [output];
    const copy = { ...output, relativeOutput: path.join(relativeDocuments, path.relative("Documents", output.relativeOutput)) };
    return rulesMove && isPathInside(ruleRoot, output.relativeOutput) ? [copy] : [output, copy];
  });
}

// A workflow or rule under <root>/Cline, whichever Documents folder <root> is.
const CLINE_DOCUMENTS_OUTPUT = /^(?:(.+?)[\\/])?Cline[\\/]((?:Workflows|Rules)[\\/].+)$/;

// A workflow or rule an earlier install wrote under another Documents folder, and this plan writes
// elsewhere, moved with that folder (contract Migration step 4): its new place, the relocated copy
// when there is one, keeps the old route's category for the guard, and the old route is retired once
// the new one is written.
export function clineRelocatedRoutes(previousOutputs, plannedOutputs) {
  const place = (output) => {
    const match = CLINE_DOCUMENTS_OUTPUT.exec(output);
    return match ? { root: match[1] ?? "", file: match[2].split(/[\\/]+/).join("/") } : null;
  };
  const planned = new Set(plannedOutputs.map((output) => path.normalize(output)));
  const destinations = new Map();
  for (const output of plannedOutputs) {
    const found = place(output);
    if (!found) continue;
    const current = destinations.get(found.file);
    if (!current || place(current).root === "Documents") destinations.set(found.file, output);
  }
  return previousOutputs.flatMap((output) => {
    const found = place(output);
    const to = found && destinations.get(found.file);
    return to && !planned.has(path.normalize(output)) ? [{ from: output, to }] : [];
  });
}

// A skill an earlier install wrote under `.factory/skills` moves to the same path under the shared
// root: the old route keeps its category for the guard and is retired once its successor is
// written, so Droid never loads both. Only manifest-owned outputs are considered, so a skill the
// user placed under `.factory/skills` is left alone.
export function droidRelocatedRoutes(previousOutputs, plannedOutputs) {
  const oldRoot = path.join(".factory", "skills") + path.sep;
  const planned = new Set(plannedOutputs.map((output) => path.normalize(output)));
  return previousOutputs.flatMap((output) => {
    const from = path.normalize(output);
    if (!from.startsWith(oldRoot)) return [];
    const to = path.join(sharedAgentSkillRoot(), from.slice(oldRoot.length));
    return planned.has(to) ? [{ from: output, to }] : [];
  });
}

export async function codexStaticOutputs(_commands, context) {
  const [document, ...references] = await rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface global Codex rules",
    label: "Codex global instructions",
    relativeOutput: codexInstructionPath(context),
    referencesRoot: path.join(".codex", "references", "rules"),
  });
  // Codex stops reading project AGENTS.md files at project_doc_max_bytes, 32 KiB by default; it read
  // a larger ~/.codex/AGENTS.md whole (codex-cli 0.166.0, `codex debug prompt-input`, 2026-11-03).
  if (context.scope !== "project") return [document, ...references];
  return [{ ...document, byteLimit: 32 * 1024 }, ...references];
}

export async function copilotStaticOutputs(_commands, context) {
  const nativeRoot = context.scope === "user" ? ".copilot" : ".github";
  const outputs = [
    {
      sourceKind: "rules",
      renderKind: "instructions",
      source: "rules/*.mdc",
      relativeOutput: copilotInstructionPath(context),
      content: await renderInstructionDocument("agent-surface GitHub Copilot instructions", "GitHub Copilot CLI instructions", context),
    },
    ...await scopedRuleReferenceOutputs(context, path.join(nativeRoot, "references", "rules")),
  ];
  if (context.scope !== "user") return outputs;
  outputs.push(...await vsCodeProfileInstructionOutputs(context));
  return outputs;
}

// One always-on document that CLAUDE.md imports, plus scoped rules as references. Not ~/.claude/rules:
// VS Code also reads that folder (a rule without `paths` applies to every request), so a co-installed
// vscode target would attach the same rules twice; VS Code reads CLAUDE.md but resolves no @imports.
export async function claudeCodeStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "agent-surface Claude Code rules",
    label: "Claude Code instructions",
    relativeOutput: claudeRulesDocument,
    referencesRoot: path.join(".claude", "agent-surface", "references", "rules"),
  });
}

export async function cursorStaticOutputs(_commands, context) {
  const rules = await readRulesForContext(context);
  return rules.map((rule) => ({
    source: rule.file,
    relativeOutput: path.join(".cursor", "rules", path.basename(rule.file)),
    content: rule.text,
    assetCategory: rule.assetCategory,
  }));
}

export async function deepagentsStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Deep Agents Code rules",
    label: "Deep Agents Code instructions",
    relativeOutput: deepagentsInstructionPath(context),
    referencesRoot: path.join(deepagentsConfigRoot(context), "references", "rules"),
  });
}

export async function droidStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Droid rules",
    label: "Droid instructions",
    relativeOutput: droidInstructionPath(context),
    referencesRoot: path.join(droidConfigRoot(context), "references", "rules"),
  });
}

export async function grokBuildStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Grok Build rules",
    label: "Grok Build instructions",
    relativeOutput: grokBuildInstructionPath(context),
    referencesRoot: path.join(".grok", "references", "rules"),
  });
}

export async function kiloStaticOutputs(_commands, context) {
  const rules = await readRulesForContext(context);
  const alwaysApplyRules = rules.filter((rule) => rule.alwaysApply !== false);
  const scopedRules = rules.filter((rule) => rule.alwaysApply === false);
  const firstPartyMcpEntries = await selectedMcpServiceEntries(true, {
    categoryFilter: null,
    optionalServices: null,
  });
  const outputs = [
    ...alwaysApplyRules.map((rule) => ({
      source: rule.file,
      relativeOutput: path.join(kiloRuleRoot(context), `${path.basename(rule.file, ".mdc")}.md`),
      content: renderKiloRuleDocument(rule),
      assetCategory: rule.assetCategory,
    })),
  ];
  if (context.mode !== "install") {
    const kiloConfig = {
      $schema: "https://app.kilo.ai/config.json",
      instructions: await kiloRuleInstructionPaths(context.scope, context),
      permission: { "*": "allow" },
      share: "disabled",
    };
    if (firstPartyMcpEntries.length > 0) {
      kiloConfig.mcp = optionalServiceMcpServers(firstPartyMcpEntries, "local-command-map");
    }
    outputs.unshift({
      source: "rules/*.mdc",
      relativeOutput: kiloConfigPath(context.scope),
      content: `${JSON.stringify(kiloConfig, null, 2)}\n`,
    });
  }
  outputs.push(...scopedRules.map((rule) => ({
    source: rule.file,
    relativeOutput: path.join(kiloRuleReferenceRoot(context), `${path.basename(rule.file, ".mdc")}.md`),
    content: renderScopedRuleReferenceDocument(rule),
    assetCategory: rule.assetCategory,
  })));
  return outputs;
}

export async function kimiCodeStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Kimi Code rules",
    label: "Kimi Code instructions",
    relativeOutput: kimiCodeInstructionPath(context),
    referencesRoot: path.join(kimiCodeConfigRoot(context), "references", "rules"),
  });
}

export async function qoderStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Qoder rules",
    label: "Qoder instructions",
    relativeOutput: qoderInstructionPath(context),
    referencesRoot: path.join(qoderConfigRoot(context), "references", "rules"),
  });
}

export async function qwenCodeStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "QWEN.md - agent-surface Qwen Code rules",
    label: "Qwen Code instructions",
    relativeOutput: qwenCodeInstructionPath(context),
    referencesRoot: path.join(qwenCodeConfigRoot(context), "references", "rules"),
  });
}

export async function kiroStaticOutputs(_commands, context) {
  const rules = await readRulesForContext(context);
  return rules.map((rule) => ({
    source: rule.file,
    renderKind: "rules",
    relativeOutput: path.join(kiroSteeringRoot(context), `${path.basename(rule.file, ".mdc")}.md`),
    content: renderKiroRuleDocument(rule),
    assetCategory: rule.assetCategory,
  }));
}

export async function opencodeStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface global OpenCode rules",
    label: "OpenCode global instructions",
    relativeOutput: opencodeInstructionPath(context),
    referencesRoot: path.join(opencodeConfigRoot(context), "references", "rules"),
    renderKind: null,
  });
}

export async function openhandsStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface OpenHands rules",
    label: "OpenHands instructions",
    relativeOutput: openhandsInstructionPath(context),
    referencesRoot: path.join(openhandsConfigRoot(context), "references", "rules"),
  });
}

export async function piStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Pi rules",
    label: "Pi instructions",
    relativeOutput: piInstructionPath(context),
    referencesRoot: path.join(piConfigRoot(context), "references", "rules"),
  });
}

export async function poolStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "agent-surface Poolside rules",
    label: "Poolside instructions",
    relativeOutput: poolInstructionPath(context),
    referencesRoot: path.join(poolConfigRoot(context), "references", "rules"),
  });
}

// The international IDE reads user rules from the single user_rules.md its current build still loads
// beside the documented user_rules folder; projects get the per-rule files every edition reads.
export async function traeStaticOutputs(_commands, context) {
  if (context.scope !== "user") return traeRuleFolderOutputs(context);
  return [
    {
      source: "rules/*.mdc",
      relativeOutput: path.join(".trae", "user_rules.md"),
      content: await renderInstructionDocument("agent-surface Trae user rules", "Trae user rules", context),
    },
    ...await scopedRuleReferenceOutputs(context, path.join(".trae", "references", "rules")),
  ];
}

export async function traeCnStaticOutputs(_commands, context) {
  if (context.scope !== "user") return traeRuleFolderOutputs(context);
  return [
    ...await traeRuleFileOutputs(context),
    ...await scopedRuleReferenceOutputs(context, path.join(".trae-cn", "references", "rules")),
  ];
}

// Trae CLI 2.0 loads ~/.trae/rules the way it loads a project's .trae/rules, and reads neither IDE's
// user_rules route, so a user install writes the files a project install does.
export async function traeCliStaticOutputs(_commands, context) {
  return traeRuleFolderOutputs(context, traeRuleFolder());
}

async function traeRuleFolderOutputs(context, ruleRoot = traeRuleRoot(context)) {
  return [
    ...await traeRuleFileOutputs(context, ruleRoot),
    ...await scopedRuleReferenceOutputs(context, path.join(".trae", "references", "rules")),
  ];
}

async function traeRuleFileOutputs(context, ruleRoot = traeRuleRoot(context)) {
  const rules = await readRulesForContext(context);
  return rules.map((rule) => ({
    sourceKind: "rules",
    renderKind: "rules",
    source: rule.file,
    relativeOutput: path.join(ruleRoot, `${path.basename(rule.file, ".mdc")}.md`),
    content: rule.text,
    assetCategory: rule.assetCategory,
  }));
}

// VS Code discovers instruction files in the profile folder it calls promptsHome, Code/User/prompts,
// next to the workspace and ~/.copilot locations in chat.instructionsFilesLocations. Code/User, which
// agent-surface wrote before, is not one of them in 1.116: its default list is .github/instructions,
// .claude/rules, ~/.claude/rules and ~/.copilot/instructions, and the profile folder appended for
// instructions is promptsHome alone. Only *.instructions.md, copilot-instructions.md and
// .claude/rules/*.md are read there, so a scoped rule reaches this host as its own instruction file
// rather than as a reference nothing would load.
//
// Both targets that reach this surface write one shared document, as the project AGENTS.md hosts do:
// a co-installed pair then plans identical bytes instead of attaching the same always-on rules twice.
async function vsCodeProfileInstructionOutputs(context) {
  const promptRoot = path.join(vsCodeUserRoot("Code", context), "prompts");
  const scoped = (await readRulesForContext(context)).filter((rule) => rule.alwaysApply === false);
  return [
    {
      sourceKind: "rules",
      renderKind: "instructions",
      source: "rules/*.mdc",
      relativeOutput: path.join(promptRoot, "agent-surface.instructions.md"),
      content: await renderVsCodeInstructionDocument("agent-surface VS Code instructions", context),
    },
    ...scoped.map((rule) => ({
      sourceKind: "rules",
      renderKind: "rules",
      source: rule.file,
      relativeOutput: path.join(promptRoot, `agent-surface-${path.basename(rule.file, ".mdc")}.instructions.md`),
      content: renderVsCodeScopedInstructionDocument(rule),
      assetCategory: rule.assetCategory,
    })),
  ];
}

export async function vscodeStaticOutputs(_commands, context) {
  return vsCodeProfileInstructionOutputs(context);
}

export async function windsurfStaticOutputs(_commands, context) {
  const [document, ...references] = await rulesDocumentOutputs(context, {
    title: "agent-surface Windsurf rules",
    label: "Windsurf instructions",
    relativeOutput: windsurfRulePath(context),
    referencesRoot: path.join(windsurfConfigRoot(context), "references", "rules"),
  });
  // Cascade reads at most 6,000 characters of the global rules file and 12,000 of a workspace rule file.
  return [{ ...document, characterLimit: context.scope === "user" ? 6000 : 12000 }, ...references];
}

export async function zedStaticOutputs(_commands, context) {
  return rulesDocumentOutputs(context, {
    title: "AGENTS.md - agent-surface Zed rules",
    label: "Zed instructions",
    relativeOutput: zedInstructionPath(context),
    referencesRoot: path.join(zedConfigRoot(context), "references", "rules"),
  });
}

// A route that exists only for Windows user installs made before a per-OS route; elsewhere none.
function windowsUserRoute(context, route) {
  return context.scope === "user" && (context.platform ?? process.platform) === "win32" ? route : null;
}

export function sourceKindPolicy(sourceKindsConfig, sourceKind) {
  return sourceKind ? sourceKindsConfig.source_kinds[sourceKind] : null;
}
