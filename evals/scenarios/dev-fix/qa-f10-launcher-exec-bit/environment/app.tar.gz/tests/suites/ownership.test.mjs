#!/usr/bin/env node
// Installer-wide destination ownership (contract Migration steps 2, 3, 6 and 7), exercised through the
// real CLI against disposable install roots. POSIX only, like the rest of `npm test`: the Windows CI
// job runs the platform suites instead.
//
// SUBSTITUTE_JUSTIFICATION
// - substitute: a scratch HOME and XDG_CONFIG_HOME for every install, with the operator's real
//   first-party MCP binaries linked into its ~/.local/bin
// - replaces: the operator's real home directory
// - necessity: installs materialize launchers and read config under HOME; the operator's home must
//   stay untouched and the result must not depend on its contents
// - real-option: the real CLI, planner, filesystem and MCP binaries run unchanged; only the home
//   location differs
// - proof-limit: proves ownership inside install roots, not anything about the operator's own profile
// - real-proof: a read-only `install --target all --scope user --dry-run` against the real HOME
//   plans no unowned destination and no unreadable manifest
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync, symlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";

import { vsCodeUserRoot } from "../../scripts/agent-surface/roots.mjs";
import { status } from "../lib/helpers.mjs";

if (process.platform === "win32") {
  console.log("ownership: skipped on Windows (POSIX suite)");
  process.exit(0);
}

const scratch = mkdtempSync(path.join(os.tmpdir(), "agent-surface-ownership-"));
const home = path.join(scratch, "home");
mkdirSync(home);
const env = { ...process.env, HOME: home, XDG_CONFIG_HOME: path.join(home, ".config") };

// These installs wire the first-party MCP servers, whose binaries `npm run install:mcps` links into
// ~/.local/bin (CI runs it before the suite). Link those real binaries into the scratch HOME so the
// prerequisite check finds them; nothing stands in for them.
const operatorBin = path.join(os.homedir(), ".local", "bin");
mkdirSync(path.join(home, ".local", "bin"), { recursive: true });
for (const name of ["grimoire-server", "synapse-bridge", "synapse-hook"]) {
  assert.ok(existsSync(path.join(operatorBin, name)), `${name} is missing; run npm run install:mcps first`);
  symlinkSync(path.join(operatorBin, name), path.join(home, ".local", "bin", name));
}
const shipDeploy = path.join(".agents", "skills", "ship-deploy", "SKILL.md");

function install(args) {
  const result = status(["install", ...args], { env });
  return { code: result.status, out: `${result.stdout}${result.stderr}` };
}

function project(dest, target, extra = []) {
  return install(["--target", target, "--scope", "project", "--dest", dest, ...extra]);
}

function manifest(dest, target) {
  const file = path.join(dest, ".agent-surface", `${target}-manifest.json`);
  return existsSync(file) ? JSON.parse(readFileSync(file, "utf8")) : null;
}

function claims(dest, target, output) {
  return manifest(dest, target)?.managed.some((entry) => entry.output === output) ?? false;
}

function read(dest, relative) {
  return readFileSync(path.join(dest, relative), "utf8");
}

// Whether this user can read a file or list a directory despite its mode: root can, and so can a
// mount that ignores modes, where an unreadable case cannot arise.
function canOpen(target) {
  try {
    if (statSync(target).isDirectory()) readdirSync(target);
    else readFileSync(target);
    return true;
  } catch {
    return false;
  }
}

// Whether this user can resolve a path inside a directory despite its mode, as root can.
function canSearch(directory) {
  try {
    statSync(`${directory}${path.sep}.`);
    return true;
  } catch {
    return false;
  }
}

// Every directory and file under a root, with file contents, to prove a refused plan changed nothing.
function snapshot(dir, entries = {}, base = dir) {
  if (!existsSync(dir)) return entries;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    const relative = path.relative(base, full);
    if (entry.isDirectory()) {
      entries[`${relative}${path.sep}`] = "directory";
      snapshot(full, entries, base);
    } else {
      entries[relative] = readFileSync(full, "utf8");
    }
  }
  return entries;
}

function count(text, pattern) {
  return text.match(pattern)?.length ?? 0;
}

function escapeRegExp(text) {
  return text.replaceAll(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

try {
  // Step 2, no claim: an existing file nobody claims blocks the whole plan, differing or identical,
  // with nothing written and nothing adopted into a manifest.
  {
    const dest = path.join(scratch, "unowned-differing");
    mkdirSync(dest, { recursive: true });
    writeFileSync(path.join(dest, "AGENTS.md"), "# Operator rules\n");
    const before = snapshot(dest);
    const live = project(dest, "openhands", ["--category", "rules"]);
    assert.equal(live.code, 1, live.out);
    assert.match(live.out, /^ {2}UNOWNED_DESTINATION: AGENTS\.md exists and no agent-surface manifest in this install root claims it; move or remove it, then rerun$/m);
    assert.deepEqual(snapshot(dest), before, "a refused plan writes nothing, manifest included");
  }
  const rulesReference = path.join(scratch, "reference");
  assert.equal(project(rulesReference, "openhands", ["--category", "rules"]).code, 0);
  {
    const dest = path.join(scratch, "unowned-identical");
    mkdirSync(dest, { recursive: true });
    writeFileSync(path.join(dest, "AGENTS.md"), read(rulesReference, "AGENTS.md"));
    const before = snapshot(dest);
    const live = project(dest, "openhands", ["--category", "rules"]);
    assert.equal(live.code, 1, live.out);
    assert.match(live.out, /UNOWNED_DESTINATION: AGENTS\.md /);
    assert.deepEqual(snapshot(dest), before, "an identical unowned file is not adopted");
  }

  // Step 2, differing bytes with another owner's claim: regenerated, with a warning naming the
  // contribution the selection drops. Another target's manifest is not a veto.
  {
    const dest = path.join(scratch, "droid-then-openhands");
    const droid = project(dest, "droid", ["--category", "development"]);
    assert.equal(droid.code, 0, droid.out);
    const live = project(dest, "openhands", ["--category", "rules"]);
    assert.equal(live.code, 0, live.out);
    assert.match(live.out, /^ {2}SHARED_CONTRIBUTION_REPLACED: AGENTS\.md drops droid's development; install --target droid --category development into this root to restore it$/m);
    assert.equal(read(dest, "AGENTS.md"), read(rulesReference, "AGENTS.md"), "the shared file now holds the rules-only render");
    assert.ok(claims(dest, "droid", "AGENTS.md") && claims(dest, "openhands", "AGENTS.md"), "both owners keep their claim");
  }

  // Step 3, two development co-owners: one owner's reset keeps what the other still claims, the last
  // owner's release deletes it, and a joint reset and its repeat run without conflict or change.
  {
    const dest = path.join(scratch, "co-owners");
    assert.equal(project(dest, "openhands", ["--category", "development"]).code, 0);
    const second = project(dest, "zed", ["--category", "development"]);
    assert.equal(second.code, 0, second.out);
    assert.ok(claims(dest, "zed", "AGENTS.md") && claims(dest, "zed", shipDeploy), "identical shared bytes become co-owned");

    const zedReset = project(dest, "zed");
    assert.equal(zedReset.code, 0, zedReset.out);
    assert.match(zedReset.out, new RegExp(`^ {2}${escapeRegExp(shipDeploy)} \\(claimed by openhands\\)$`, "m"));
    assert.ok(existsSync(path.join(dest, shipDeploy)), "cleanup retains a file another owner still claims");
    assert.ok(!claims(dest, "zed", shipDeploy) && claims(dest, "openhands", shipDeploy), "the withdrawing target drops only its own claim");

    assert.equal(project(dest, "openhands").code, 0);
    assert.ok(!existsSync(path.join(dest, shipDeploy)), "the last owner's release deletes the file");

    assert.equal(project(dest, "openhands", ["--category", "development"]).code, 0);
    assert.equal(project(dest, "zed", ["--category", "development"]).code, 0);
    const joint = install(["--target", "openhands,zed", "--scope", "project", "--dest", dest]);
    assert.equal(joint.code, 0, joint.out);
    assert.ok(!existsSync(path.join(dest, shipDeploy)), "two participants that both stop claiming a path both remove it");
    const repeat = install(["--target", "openhands,zed", "--scope", "project", "--dest", dest]);
    assert.equal(repeat.code, 0, repeat.out);
    assert.equal(count(repeat.out, /^ {2}wrote: 0$/gm), 2, "a repeat install writes nothing");
  }

  // Step 3 for config routes: Claude Code and Copilot share a project's .mcp.json. One owner's reset
  // keeps a server the other still records there, in either order, the last owner's reset deletes it,
  // and a joint reset by both deletes it in that run. fenjing is an opt-in server with no prerequisites.
  {
    const dest = path.join(scratch, "shared-config-ids");
    const servers = () => Object.keys(JSON.parse(read(dest, ".mcp.json")).mcpServers);
    const records = (target) => manifest(dest, target)?.config_entries.find((entry) => entry.path === ".mcp.json")?.ids ?? [];
    const optIn = (target) => {
      const result = project(dest, target, ["--category", "mcps", "--service", "fenjing"]);
      assert.equal(result.code, 0, result.out);
    };
    for (const [first, last] of [["claude-code", "copilot"], ["copilot", "claude-code"]]) {
      rmSync(dest, { recursive: true, force: true });
      optIn(first);
      optIn(last);
      const reset = project(dest, first);
      assert.equal(reset.code, 0, reset.out);
      assert.match(reset.out, new RegExp(`^ {2}\\.mcp\\.json MCP kept for other owners: fenjing \\(claimed by ${last}\\)$`, "m"));
      assert.ok(servers().includes("fenjing"), `${first}'s reset keeps the server ${last} still records`);
      assert.ok(!records(first).includes("fenjing") && records(last).includes("fenjing"), `${first} drops only its own record`);
      const release = project(dest, last);
      assert.equal(release.code, 0, release.out);
      assert.match(release.out, /^ {2}\.mcp\.json MCP -= fenjing$/m);
      assert.ok(!servers().includes("fenjing"), `${last}'s reset, the last owner's, deletes the server`);
      assert.deepEqual(servers().sort(), ["grimoire", "synapse"]);
    }
    rmSync(dest, { recursive: true, force: true });
    optIn("claude-code");
    optIn("copilot");
    const joint = install(["--target", "claude-code,copilot", "--scope", "project", "--dest", dest]);
    assert.equal(joint.code, 0, joint.out);
    assert.ok(!servers().includes("fenjing"), "two participants that both stop recording a server both delete it");
  }

  // Every path several targets share renders identical bytes for one selection, so a joint plan
  // over all targets has no same-run conflict.
  for (const selection of [[], ["--category", "development"], ["--category", "rules"]]) {
    const label = `project all ${selection.join(" ") || "general"}`;
    const plan = install(["--target", "all", "--scope", "project", "--dest", path.join(scratch, "all-project"), ...selection, "--dry-run"]);
    assert.equal(plan.code, 0, `${label}: ${plan.out}`);
    assert.doesNotMatch(plan.out, /also planned by/, label);
  }

  // Claim sources: any <id>-manifest.json in .agent-surface/ counts, unknown targets included, and
  // an unparsable one blocks the root once instead of turning claimed files into unowned ones.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: hand-written manifests for an unknown owner and an unparsable one
  // - replaces: manifests left by a retired target, another tool or a damaged disk
  // - necessity: no shipped target produces these states
  // - real-option: the real planner reads them from a real install root through the real CLI
  // - proof-limit: proves how the planner treats these files, not how they arose
  // - real-proof: none for foreign or damaged manifests
  {
    const dest = path.join(scratch, "discovery");
    const agentSurface = path.join(dest, ".agent-surface");
    mkdirSync(agentSurface, { recursive: true });
    writeFileSync(path.join(dest, "AGENTS.md"), "written by a target this checkout no longer knows\n");
    writeFileSync(path.join(agentSurface, "former-host-manifest.json"), `${JSON.stringify({
      target: "former-host",
      managed: [{ target: "former-host", source: "rules/*.mdc", output: "AGENTS.md" }],
    })}\n`);
    const claimed = project(dest, "openhands", ["--category", "rules", "--dry-run"]);
    assert.equal(claimed.code, 0, claimed.out);

    writeFileSync(path.join(agentSurface, "broken-manifest.json"), "{");
    const broken = project(dest, "openhands", ["--category", "rules", "--dry-run"]);
    assert.equal(broken.code, 1, broken.out);
    assert.match(broken.out, /^install blocked: .*: MANIFEST_UNREADABLE: \.agent-surface[\\/]broken-manifest\.json is not valid JSON; /m);
    assert.doesNotMatch(broken.out, /UNOWNED_DESTINATION/, "an incomplete claim set reports no unowned files");
  }

  // Claim sources: a legacy-listed nested manifest (Copilot's pre-146d8e8 user root) records what
  // that release wrote, rebased to the nested manifest's root, and cleaning the nested manifest up
  // never removes what it recorded. The moved document's old path goes only because
  // registry/legacy-owned.json lists it; the path nothing else claims survives.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a hand-written nested manifest in the pre-146d8e8 layout and the files it records
  // - replaces: a profile last installed by an agent-surface release older than 146d8e8
  // - necessity: running that release needs a separate checkout and install
  // - real-option: the shipped legacy-owned.json entries and the real planner and apply run unchanged
  // - proof-limit: proves handling of that layout, not every historical manifest variant
  // - real-proof: the RT2.0 review upgraded a home installed by the pre-146d8e8 release cleanly
  {
    const dest = path.join(scratch, "copilot-legacy");
    const plan = install(["--target", "copilot", "--scope", "user", "--dest", dest, "--dry-run"]);
    const planned = plan.out.split("\n").map((line) => line.trim())
      .find((line) => line.endsWith(`prompts${path.sep}agent-surface.instructions.md <- rules/*.mdc`))
      ?.split(" <- ")[0];
    assert.ok(planned, plan.out);
    const nestedRoot = path.dirname(path.dirname(planned));
    const nestedManifest = path.join(nestedRoot, ".agent-surface", "copilot-manifest.json");
    // The paths that release actually wrote: its instruction document under Code/User/instructions,
    // and one more that only its nested manifest records.
    const historicalRecord = path.join("instructions", "agent-surface-copilot.instructions.md");
    const historicalReference = path.join("instructions", "references", "rules", "10-python.md");
    const retiredRecord = path.join("instructions", "retired-copilot.instructions.md");
    mkdirSync(path.join(dest, nestedRoot, path.dirname(historicalReference)), { recursive: true });
    mkdirSync(path.join(dest, path.dirname(nestedManifest)), { recursive: true });
    writeFileSync(path.join(dest, nestedManifest), `${JSON.stringify({
      target: "copilot",
      managed: [
        { target: "copilot", source: "rules/*.mdc", output: historicalRecord },
        { target: "copilot", source: "rules/10-python.mdc", output: historicalReference },
        { target: "copilot", source: "rules/*.mdc", output: retiredRecord },
      ],
    })}\n`);
    writeFileSync(path.join(dest, nestedRoot, historicalRecord), "instructions from an older copilot install\n");
    writeFileSync(path.join(dest, nestedRoot, historicalReference), "a scoped reference from an older copilot install\n");
    writeFileSync(path.join(dest, nestedRoot, retiredRecord), "retired by an older copilot install\n");
    const live = install(["--target", "copilot", "--scope", "user", "--dest", dest]);
    assert.equal(live.code, 0, live.out);
    assert.match(read(dest, planned), /^applyTo: "\*\*"$/m, "the upgrade writes the document in the folder VS Code reads");
    for (const [record, label] of [[historicalRecord, "document"], [historicalReference, "scoped reference"]]) {
      assert.ok(
        !existsSync(path.join(dest, nestedRoot, record)),
        `the old instruction ${label} is listed in legacy ownership, so the upgrade removes it`,
      );
    }
    assert.ok(!existsSync(path.join(dest, nestedManifest)), "the legacy nested manifest itself is cleaned up");
    assert.equal(read(dest, path.join(nestedRoot, retiredRecord)), "retired by an older copilot install\n", "a nested claim never authorizes a removal");
  }

  // Step 3, key split: the pre-split trae target also wrote the CN IDE's ~/.trae-cn/user_rules and the
  // CLI's ~/.trae/traecli.toml. trae keeps each path and server claimed and untouched until trae-cn's
  // or trae-cli's own manifest claims it, then lets go of it without removing or pruning it.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a hand-written pre-split trae manifest with the files and config entries it recorded
  // - replaces: a profile installed by a release before the Trae split
  // - necessity: this checkout no longer renders the combined layout
  // - real-option: the real CLI, planner and apply run against a real root
  // - proof-limit: proves the handover rule, not what either Trae edition loads
  // - real-proof: a read-only dry-run of the new keys against the operator's pre-split profile
  {
    const cnRule = path.join(".trae-cn", "user_rules", "00-precedence-and-safety.md");
    const cli1Skill = path.join(".traecli", "skills", "ops-flow", "SKILL.md");
    const cliConfig = path.join(".trae", "traecli.toml");
    const unreadMcp = path.join(".trae", "mcp.json");
    const preSplit = (dest) => {
      for (const file of [cnRule, cli1Skill]) {
        mkdirSync(path.dirname(path.join(dest, file)), { recursive: true });
        writeFileSync(path.join(dest, file), "written before the split\n");
      }
      mkdirSync(path.join(dest, ".trae"), { recursive: true });
      writeFileSync(path.join(dest, cliConfig), 'model = "keep-me"\n\n[mcp_servers.grimoire]\ncommand = "old"\n\n[mcp_servers.synapse]\ncommand = "old"\n');
      writeFileSync(path.join(dest, unreadMcp), `${JSON.stringify({ mcpServers: { existing: { command: "keep" }, grimoire: { command: "old" }, synapse: { command: "old" } } }, null, 2)}\n`);
      mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
      writeFileSync(path.join(dest, ".agent-surface", "trae-manifest.json"), `${JSON.stringify({
        target: "trae",
        scope: "user",
        managed: [cnRule, cli1Skill].map((output) => ({ target: "trae", source: "rules/*.mdc", output })),
        config_entries: [
          { path: cliConfig, format: "codex-toml", ids: ["grimoire", "synapse"] },
          { path: unreadMcp, format: "mcpServers", ids: ["grimoire", "synapse"] },
        ],
      }, null, 2)}\n`);
    };
    const user = (dest, selection) => install(["--target", selection, "--scope", "user", "--dest", dest]);
    const cliIds = (dest, target) => manifest(dest, target)?.config_entries.find((entry) => entry.path === cliConfig)?.ids ?? null;

    const dest = path.join(scratch, "trae-split");
    preSplit(dest);
    // A successor installed for something else takes over nothing.
    for (const successor of ["trae-cn", "trae-cli"]) {
      assert.equal(install(["--target", successor, "--scope", "user", "--dest", dest, "--category", "skills"]).code, 0);
    }
    const alone = user(dest, "trae");
    assert.equal(alone.code, 0, alone.out);
    assert.equal(read(dest, cnRule), "written before the split\n", "a path handed to trae-cn stays untouched");
    assert.ok(claims(dest, "trae", cnRule), "and claimed");
    assert.match(read(dest, cliConfig), /^\[mcp_servers\.grimoire\]$/m, "nothing is pruned from a route handed to trae-cli");
    assert.deepEqual(cliIds(dest, "trae"), ["grimoire", "synapse"]);
    assert.ok(!existsSync(path.join(dest, cli1Skill)), "a former path without a successor is ordinary stale output");
    assert.deepEqual(JSON.parse(read(dest, unreadMcp)).mcpServers, { existing: { command: "keep" } });

    assert.equal(user(dest, "trae-cn").code, 0);
    assert.equal(user(dest, "trae-cli").code, 0);
    const released = user(dest, "trae");
    assert.equal(released.code, 0, released.out);
    assert.ok(!claims(dest, "trae", cnRule) && claims(dest, "trae-cn", cnRule) && existsSync(path.join(dest, cnRule)), "trae lets go of a path trae-cn claims");
    assert.equal(cliIds(dest, "trae"), null, "and of the servers trae-cli records");
    assert.match(read(dest, cliConfig), /^\[mcp_servers\.grimoire\]$/m, "without pruning them");
    assert.match(read(dest, cliConfig), /^model = "keep-me"$/m);

    const joint = path.join(scratch, "trae-split-joint");
    preSplit(joint);
    const all = user(joint, "trae,trae-cn,trae-cli");
    assert.equal(all.code, 0, all.out);
    assert.doesNotMatch(all.out, /also planned by/);
    assert.ok(claims(joint, "trae-cn", cnRule) && read(joint, cnRule) !== "written before the split\n", "trae-cn takes over the CN rules");
    assert.deepEqual(cliIds(joint, "trae-cli"), ["grimoire", "synapse"]);
    // Successors in the same run are judged by their next manifests, so trae lets go in this run.
    assert.ok(!claims(joint, "trae", cnRule), "trae releases the path trae-cn claims in the same run");
    assert.equal(cliIds(joint, "trae"), null, "and the servers trae-cli records in the same run");
    assert.match(all.out, new RegExp(`^  ${cnRule.replaceAll("/", "\\/").replaceAll(".", "\\.")} \\(claimed by trae-cn\\)$`, "m"), "the plan reports the path as kept for trae-cn");
  }

  // Step 4, moved route: Poolside's personal instructions moved from .poolside to AGENTS.md. The new
  // route inherits the old one's recorded category for the category guard, and a selection that plans
  // the new route retires the owned old one, so a client that reads both never gets two copies.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a hand-written pool manifest and .poolside in the shape earlier releases wrote
  // - replaces: a user profile installed before the move
  // - necessity: this checkout no longer renders the old route
  // - real-option: the real CLI, planner and apply run against a real root
  // - proof-limit: proves the transition, not what Poolside loads
  // - real-proof: the operator's profile holds a development-recorded .poolside, and a peer review
  //   reproduced both cases with the earlier and current installers
  {
    const legacy = path.join(".config", "poolside", ".poolside");
    const oldPool = (name, category) => {
      const dest = path.join(scratch, name);
      mkdirSync(path.join(dest, ".config", "poolside"), { recursive: true });
      mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
      writeFileSync(path.join(dest, legacy), "rules from an earlier install\n");
      writeFileSync(path.join(dest, ".agent-surface", "pool-manifest.json"), `${JSON.stringify({
        target: "pool",
        scope: "user",
        managed: [{ target: "pool", source: "rules/*.mdc", output: legacy, ...(category ? { asset_category: category } : {}) }],
      })}\n`);
      return dest;
    };
    const rulesOnly = (dest) => install(["--target", "pool", "--scope", "user", "--dest", dest, "--category", "rules"]);

    const development = oldPool("pool-development", "development");
    const before = snapshot(development);
    const narrower = rulesOnly(development);
    assert.equal(narrower.code, 1, narrower.out);
    assert.match(narrower.out, /AGENTS\.md replaces .*\.poolside, which carries the development category's contribution/);
    assert.deepEqual(snapshot(development), before, "a narrower selection does not drop the old document's contribution");

    const general = oldPool("pool-general");
    const replaced = rulesOnly(general);
    assert.equal(replaced.code, 0, replaced.out);
    assert.ok(existsSync(path.join(general, ".config", "poolside", "AGENTS.md")), replaced.out);
    assert.ok(!existsSync(path.join(general, legacy)), "the old route is retired with its replacement");
  }

  // The same move for a Codex project: earlier installs wrote .codex/AGENTS.md, which Codex never
  // reads, and the project's root AGENTS.md now replaces it.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a hand-written codex manifest and .codex/AGENTS.md in the shape earlier releases wrote
  // - replaces: a project installed before the move
  // - necessity: this checkout no longer renders the old route
  // - real-option: the real CLI, planner and apply run against a real root
  // - proof-limit: proves the transition, not what Codex loads
  // - real-proof: Codex 0.163.0's debug prompt-input loads the new root AGENTS.md and no .codex/AGENTS.md
  {
    const legacy = path.join(".codex", "AGENTS.md");
    const oldCodex = (name, category) => {
      const dest = path.join(scratch, name);
      mkdirSync(path.join(dest, ".codex"), { recursive: true });
      mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
      writeFileSync(path.join(dest, legacy), "rules from an earlier install\n");
      writeFileSync(path.join(dest, ".agent-surface", "codex-manifest.json"), `${JSON.stringify({
        target: "codex",
        scope: "project",
        managed: [{ target: "codex", source: "rules/*.mdc", output: legacy, ...(category ? { asset_category: category } : {}) }],
      })}\n`);
      return dest;
    };

    const development = oldCodex("codex-development", "development");
    const before = snapshot(development);
    const narrower = project(development, "codex", ["--category", "rules"]);
    assert.equal(narrower.code, 1, narrower.out);
    assert.match(narrower.out, /AGENTS\.md replaces \.codex\/AGENTS\.md, which carries the development category's contribution/);
    assert.deepEqual(snapshot(development), before, "a narrower selection does not drop the old document's contribution");

    const general = oldCodex("codex-general");
    const replaced = project(general, "codex", ["--category", "rules"]);
    assert.equal(replaced.code, 0, replaced.out);
    assert.match(read(general, "AGENTS.md"), /^# AGENTS\.md - agent-surface rules$/m);
    assert.ok(!existsSync(path.join(general, legacy)) && !claims(general, "codex", legacy), "the old route is retired with its replacement");

    // When another host already owns an identical root AGENTS.md, the new route is a skip, but
    // retiring the old one would still drop its development contribution, so the selection stops.
    const shared = oldCodex("codex-shared-development", "development");
    const droid = project(shared, "droid", ["--category", "rules"]);
    assert.equal(droid.code, 0, droid.out);
    const sharedBefore = snapshot(shared);
    const sharedNarrower = project(shared, "codex", ["--category", "rules"]);
    assert.equal(sharedNarrower.code, 1, sharedNarrower.out);
    assert.match(sharedNarrower.out, /AGENTS\.md replaces \.codex\/AGENTS\.md, which carries the development category's contribution/);
    assert.deepEqual(snapshot(shared), sharedBefore, "a matching shared document does not retire the old one's contribution");
  }

  // The same move for the VS Code profile: earlier installs wrote Code/User/instructions, which VS
  // Code does not scan, and the prompts folder it discovers now carries that document.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a hand-written vscode manifest and instructions/agent-surface.instructions.md in the shape earlier releases wrote
  // - replaces: a profile installed before the move
  // - necessity: this checkout no longer renders the old route
  // - real-option: the real CLI, planner and apply run against a real root
  // - proof-limit: proves the transition, not what a VS Code session loads
  // - real-proof: installing a scratch root from main and then from this checkout retires the six old files
  {
    const userRoot = vsCodeUserRoot("Code", { scope: "user" });
    const legacy = path.join(userRoot, "instructions", "agent-surface.instructions.md");
    const oldVsCode = (name, category) => {
      const dest = path.join(scratch, name);
      mkdirSync(path.join(dest, userRoot, "instructions"), { recursive: true });
      mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
      writeFileSync(path.join(dest, legacy), "instructions from an earlier install\n");
      writeFileSync(path.join(dest, ".agent-surface", "vscode-manifest.json"), `${JSON.stringify({
        target: "vscode",
        scope: "user",
        managed: [{ target: "vscode", source: "rules/*.mdc", output: legacy, ...(category ? { asset_category: category } : {}) }],
      })}\n`);
      return dest;
    };
    const rulesOnly = (dest) => install(["--target", "vscode", "--scope", "user", "--dest", dest, "--category", "rules"]);

    const development = oldVsCode("vscode-development", "development");
    const before = snapshot(development);
    const narrower = rulesOnly(development);
    assert.equal(narrower.code, 1, narrower.out);
    assert.match(
      narrower.out,
      /prompts.agent-surface\.instructions\.md replaces .*instructions.agent-surface\.instructions\.md, which carries the development category's contribution/,
    );
    assert.deepEqual(snapshot(development), before, "a narrower selection does not drop the old document's contribution");

    const general = oldVsCode("vscode-general");
    const replaced = rulesOnly(general);
    assert.equal(replaced.code, 0, replaced.out);
    assert.ok(existsSync(path.join(general, userRoot, "prompts", "agent-surface.instructions.md")), replaced.out);
    assert.ok(!existsSync(path.join(general, legacy)), "the old route is retired with its replacement");
  }

  // Qwen Code and Kimi Code read a project's root AGENTS.md beside their own QWEN.md or
  // .kimi-code/AGENTS.md, so earlier project installs loaded the rules twice; the shared root file now
  // replaces their copy. The co-installed case is the one that doubled the rules: another host
  // already owns the root AGENTS.md, and retiring the old copy leaves both owners claiming it.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a hand-written manifest and old instruction file in the shape earlier releases wrote
  // - replaces: a project installed before the move
  // - necessity: this checkout no longer renders the old routes
  // - real-option: the real CLI, planner and apply run against a real root
  // - proof-limit: proves the transition, not what either host loads
  // - real-proof: on the first TUI screen, Kimi Code 2.2.0's 60.3 KB AGENTS.md warning and Qwen Code 0.25.2's
  //   19,720-token count drop to no warning and 12,000 tokens (adapter READMEs)
  for (const [target, legacy, pattern] of [
    ["qwen-code", "QWEN.md", "QWEN\\.md"],
    ["kimi-code", path.join(".kimi-code", "AGENTS.md"), "\\.kimi-code\\/AGENTS\\.md"],
  ]) {
    const oldInstall = (name, category) => {
      const dest = path.join(scratch, name);
      mkdirSync(path.join(dest, path.dirname(legacy)), { recursive: true });
      mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
      writeFileSync(path.join(dest, legacy), "rules from an earlier install\n");
      writeFileSync(path.join(dest, ".agent-surface", `${target}-manifest.json`), `${JSON.stringify({
        target,
        scope: "project",
        managed: [{ target, source: "rules/*.mdc", output: legacy, ...(category ? { asset_category: category } : {}) }],
      })}\n`);
      return dest;
    };

    const development = oldInstall(`${target}-development`, "development");
    const before = snapshot(development);
    const narrower = project(development, target, ["--category", "rules"]);
    assert.equal(narrower.code, 1, narrower.out);
    assert.match(narrower.out, new RegExp(`AGENTS\\.md replaces ${pattern}, which carries the development category's contribution`));
    assert.deepEqual(snapshot(development), before, `${target}: a narrower selection does not drop the old document's contribution`);

    const shared = oldInstall(`${target}-shared`);
    const codex = project(shared, "codex", ["--category", "rules"]);
    assert.equal(codex.code, 0, codex.out);
    const replaced = project(shared, target, ["--category", "rules"]);
    assert.equal(replaced.code, 0, replaced.out);
    assert.match(read(shared, "AGENTS.md"), /^# AGENTS\.md - agent-surface rules$/m);
    assert.ok(!existsSync(path.join(shared, legacy)) && !claims(shared, target, legacy), `${target}: the old copy is retired`);
    assert.ok(claims(shared, target, "AGENTS.md") && claims(shared, "codex", "AGENTS.md"), `${target}: both owners claim the one root AGENTS.md`);
  }

  // The same identity for a document Cline's OS Documents folder relocates after a real development
  // install: the relocated rules document keeps the old route's category, so a rules-only refresh is
  // refused, and a development refresh rewrites it and retires the old route. Linux only, through the
  // real xdg-user-dir, which reads this home's user-dirs.dirs.
  if (spawnSync("xdg-user-dir", ["DOCUMENTS"]).status === 0) {
    const dest = path.join(scratch, "cline-relocated");
    const userDirs = path.join(home, ".config", "user-dirs.dirs");
    const cline = (category) => install(["--target", "cline", "--scope", "user", "--dest", dest, "--category", category]);
    const oldRules = path.join("Documents", "Cline", "Rules", "agent-surface.md");
    const newRules = path.join("Cline", "Rules", "agent-surface.md");
    mkdirSync(path.dirname(userDirs), { recursive: true });
    writeFileSync(userDirs, "XDG_DOCUMENTS_DIR=\"$HOME/Documents\"\n");
    try {
      const first = cline("development");
      assert.equal(first.code, 0, first.out);
      const developmentRules = read(dest, oldRules);
      // No DOCUMENTS entry: the extension reads ~/Cline, and rules go there alone.
      writeFileSync(userDirs, "");
      const before = snapshot(dest);
      const narrower = cline("rules");
      assert.equal(narrower.code, 1, narrower.out);
      assert.match(narrower.out, new RegExp(`${escapeRegExp(newRules)} replaces ${escapeRegExp(oldRules)}, which carries the development category's contribution`));
      assert.deepEqual(snapshot(dest), before, "a refused relocation writes nothing");
      const refreshed = cline("development");
      assert.equal(refreshed.code, 0, refreshed.out);
      assert.equal(read(dest, newRules), developmentRules, "the relocated document keeps the development contribution");
      assert.ok(!existsSync(path.join(dest, oldRules)) && !claims(dest, "cline", oldRules), "the old route is retired with its replacement");
      for (const root of ["Documents", ""]) assert.ok(existsSync(path.join(dest, root, "Cline", "Workflows", "ops-nuke.md")), `workflows land under ${root || "the home"}`);
    } finally {
      rmSync(userDirs, { force: true });
    }
  } else if (process.platform === "linux") {
    console.log("ownership: xdg-user-dir is not installed — skipping the Cline relocation case");
  }

  // Steps 6 and 7: every participant's pending manifest lands before the run's first mutation and
  // keeps an interrupted run's paths claimed, so rerunning the same selection finishes without
  // deleting anything by hand.
  // SUBSTITUTE_JUSTIFICATION
  // - substitute: a read-only install root whose pre-created subdirectories stay writable, so the
  //   skill writes land and the root-level AGENTS.md write, planned last, fails
  // - replaces: a real mid-apply I/O failure such as a full disk or a crash
  // - necessity: the late-failure path needs an I/O error after some writes have landed, deterministically
  // - real-option: the real planner, apply loop and filesystem run unchanged; only a directory mode is set
  // - proof-limit: proves recovery from one failed write, not from a process crash between two writes
  // - real-proof: the rerun below goes through the unmodified CLI against the same root
  if (process.getuid?.() !== 0) {
    const dest = path.join(scratch, "interrupted");
    const opsDocs = path.join(".agents", "skills", "ops-docs", "SKILL.md");
    mkdirSync(path.join(dest, ".agents", "skills"), { recursive: true });
    mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
    const joint = ["--target", "openhands,zed", "--scope", "project", "--dest", dest];
    chmodSync(dest, 0o555);
    const first = install(joint);
    chmodSync(dest, 0o755);
    assert.notEqual(first.code, 0, first.out);
    assert.match(first.out, /^install interrupted: openhands: /m);
    assert.ok(existsSync(path.join(dest, opsDocs)), "earlier writes landed before the failure");
    assert.ok(claims(dest, "openhands", opsDocs) && claims(dest, "openhands", "AGENTS.md"), "the pending manifest claims every planned path");
    assert.ok(claims(dest, "zed", "AGENTS.md"), "a participant not yet applied already has its pending manifest");
    const rerun = install(joint);
    assert.equal(rerun.code, 0, rerun.out);
    assert.ok(existsSync(path.join(dest, "AGENTS.md")), "the rerun finished the install");
  }

  // A manifest entry whose output is not a safe relative path is unusable and claims nothing, so
  // `generated/../AGENTS.md` cannot make an operator's AGENTS.md look owned.
  {
    const dest = path.join(scratch, "unsafe-claim");
    mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
    writeFileSync(path.join(dest, "AGENTS.md"), "operator notes\n");
    writeFileSync(path.join(dest, ".agent-surface", "codex-manifest.json"), `${JSON.stringify({
      target: "codex",
      scope: "project",
      managed: [{ target: "codex", source: "rules/*.mdc", output: "generated/../AGENTS.md" }],
      config_entries: [],
    }, null, 2)}\n`);
    const refused = project(dest, "openhands");
    assert.notEqual(refused.code, 0, refused.out);
    assert.match(refused.out, /UNOWNED_DESTINATION: AGENTS\.md exists/);
    assert.equal(read(dest, "AGENTS.md"), "operator notes\n");
  }

  // An install root reached through a symbolic link, such as a home directory on another volume, is
  // followed like the directories above it; a link below the root still refuses the plan untouched.
  {
    const real = path.join(scratch, "real-root");
    const linked = path.join(scratch, "linked-root");
    mkdirSync(real);
    symlinkSync(real, linked, "dir");
    const viaLink = project(linked, "openhands");
    assert.equal(viaLink.code, 0, viaLink.out);
    assert.ok(existsSync(path.join(real, "AGENTS.md")) && claims(real, "openhands", "AGENTS.md"), "writes and the manifest land in the link's target");

    const elsewhere = path.join(scratch, "elsewhere");
    mkdirSync(elsewhere);
    const inner = path.join(scratch, "inner-link");
    mkdirSync(inner);
    symlinkSync(elsewhere, path.join(inner, ".agents"), "dir");
    const refused = project(inner, "openhands");
    assert.notEqual(refused.code, 0, refused.out);
    assert.match(refused.out, /traverses symbolic link: .*inner-link\/\.agents/);
    assert.deepEqual(readdirSync(elsewhere), [], "nothing is written through a link inside the root");
    assert.deepEqual(readdirSync(inner), [".agents"], "nothing is written beside the link either");

    const dangling = path.join(scratch, "dangling-root");
    symlinkSync(path.join(scratch, "gone"), dangling, "dir");
    const deadRoot = project(dangling, "openhands");
    assert.notEqual(deadRoot.code, 0, deadRoot.out);
    assert.match(deadRoot.out, /root is a dangling symbolic link: .*dangling-root/);
    assert.equal(existsSync(path.join(scratch, "gone")), false, "a dangling root is not created through its link");

    // The case that motivated following the root: HOME itself is a link, and a user-scope install
    // merges MCP config under it.
    const linkedHome = path.join(scratch, "linked-home");
    symlinkSync(home, linkedHome, "dir");
    const userViaLink = status(["install", "--target", "claude-code", "--scope", "user", "--allow-scope-root", "--category", "mcps"], {
      env: { ...env, HOME: linkedHome, XDG_CONFIG_HOME: path.join(linkedHome, ".config") },
    });
    assert.equal(userViaLink.status, 0, `${userViaLink.stdout}${userViaLink.stderr}`);
    assert.ok(Object.hasOwn(JSON.parse(read(home, ".claude.json")).mcpServers, "synapse"), "the MCP merge lands in the linked home");
  }

  // A destination the planner cannot read blocks with a named line, as an unparsable config does,
  // instead of ending the run with a bare filesystem error; nothing is written.
  {
    const dest = path.join(scratch, "unreadable");
    const rule = path.join(".cursor", "rules", "00-precedence-and-safety.mdc");
    // A directory where a file belongs fails the same read for any user.
    mkdirSync(path.join(dest, rule), { recursive: true });
    const directory = project(dest, "cursor", ["--category", "rules"]);
    assert.equal(directory.code, 1, directory.out);
    assert.match(directory.out, /^ {2}managed output \.cursor\/rules\/00-precedence-and-safety\.mdc cannot be read \(EISDIR\)$/m);
    assert.equal(manifest(dest, "cursor"), null, "the refused run wrote no manifest");
    rmSync(path.join(dest, rule), { recursive: true });

    const unreadable = [
      ["cursor", path.join(".cursor", "mcp.json"), "mcps", "{\"mcpServers\":{}}\n", /^ {2}MCP config \.cursor\/mcp\.json cannot be read \(EACCES\)$/m],
      ["cursor", rule, "rules", "the operator's text\n", /^ {2}managed output \.cursor\/rules\/00-precedence-and-safety\.mdc cannot be read \(EACCES\)$/m],
      ["kilo", "kilo.jsonc", "rules", "{}\n", /^ {2}Kilo config kilo\.jsonc cannot be read \(EACCES\)$/m],
    ];
    for (const [target, relative, category, content, line] of unreadable) {
      const file = path.join(dest, relative);
      writeFileSync(file, content);
      chmodSync(file, 0o000);
      try {
        if (canOpen(file)) continue;
        const refused = project(dest, target, ["--category", category]);
        assert.equal(refused.code, 1, refused.out);
        assert.match(refused.out, line);
        assert.doesNotMatch(refused.out, /EACCES: permission denied/, "no bare filesystem error");
      } finally {
        chmodSync(file, 0o644);
      }
      assert.equal(read(dest, relative), content, `${relative} is untouched`);
      assert.equal(manifest(dest, target), null, "the refused run wrote no manifest");
    }
  }

  // A stale managed output the planner cannot read blocks the same way: a development install leaves
  // rules a later general install no longer plans, and one of them has lost its read permission.
  {
    const dest = path.join(scratch, "unreadable-stale");
    const staleRule = path.join(".cursor", "rules", "02-agent-workflow.mdc");
    const developed = project(dest, "cursor", ["--category", "development"]);
    assert.equal(developed.code, 0, developed.out);
    const content = read(dest, staleRule);
    const recorded = manifest(dest, "cursor");
    const file = path.join(dest, staleRule);
    chmodSync(file, 0o000);
    try {
      if (!canOpen(file)) {
        const refused = project(dest, "cursor");
        assert.equal(refused.code, 1, refused.out);
        assert.match(refused.out, /^ {2}stale managed output \.cursor\/rules\/02-agent-workflow\.mdc cannot be read \(EACCES\)$/m);
        assert.doesNotMatch(refused.out, /EACCES: permission denied/, "no bare filesystem error");
      }
    } finally {
      chmodSync(file, 0o644);
    }
    assert.equal(read(dest, staleRule), content, "the stale rule is untouched");
    assert.deepEqual(manifest(dest, "cursor"), recorded, "the refused run kept the manifest");
    assert.ok(!existsSync(path.join(dest, ".cursor", "rules", "00-precedence-and-safety.mdc")), "the refused run wrote no general rule");
  }

  // A manifest directory that cannot be listed or searched, or a legacy nested manifest whose
  // directory cannot be searched, blocks the plan with MANIFEST_UNREADABLE instead of a bare
  // filesystem error. A directory that lists but cannot be searched blocks even with no manifest in
  // it, since the run could not write its own there.
  {
    const dest = path.join(scratch, "unreadable-claims");
    const nested = path.join(dest, ".config", "Code", "User");
    mkdirSync(path.join(dest, ".agent-surface"), { recursive: true });
    mkdirSync(path.join(nested, ".agent-surface"), { recursive: true });
    const locked = [
      [path.join(dest, ".agent-surface"), 0o000, /^install blocked: .*: MANIFEST_UNREADABLE: \.agent-surface cannot be listed \(EACCES\); /m],
      [path.join(dest, ".agent-surface"), 0o444, /^install blocked: .*: MANIFEST_UNREADABLE: \.agent-surface cannot be searched \(EACCES\); /m],
      [nested, 0o000, /^install blocked: .*: MANIFEST_UNREADABLE: \.config\/Code\/User\/\.agent-surface\/vscode-manifest\.json cannot be checked \(EACCES\); /m],
    ];
    for (const [directory, mode, line] of locked) {
      chmodSync(directory, mode);
      try {
        if (canOpen(directory) && canSearch(directory)) continue;
        const refused = project(dest, "cursor", ["--category", "rules"]);
        assert.equal(refused.code, 1, refused.out);
        assert.match(refused.out, line);
        assert.doesNotMatch(refused.out, /^Error: /m, "no bare filesystem error");
      } finally {
        chmodSync(directory, 0o755);
      }
    }
    assert.equal(manifest(dest, "cursor"), null, "the refused runs wrote no manifest");
  }
} finally {
  rmSync(scratch, { recursive: true, force: true });
}

console.log("ownership: ok");
