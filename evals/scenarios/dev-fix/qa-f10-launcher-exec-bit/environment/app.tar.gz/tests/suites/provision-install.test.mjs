#!/usr/bin/env node
// Install-level provisioning gating, exercised through the real CLI against the real registry — but
// NEVER running a real package manager: no install here passes -y, and without it a headless install
// runs no recipe, so a prerequisite missing from the disposable HOME is reported, never installed on
// the developer's machine.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { MCP_ENV_LAUNCHER, mcpLaunchScriptCopy } from "../../scripts/agent-surface/merge.mjs";
import { dedupeActions } from "../../scripts/agent-surface/provision-exec.mjs";
import { provisioningStatus, selectRecipe } from "../../scripts/agent-surface/provision.mjs";
import { selectedMcpServiceEntries } from "../../scripts/agent-surface/targets.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const cli = path.join(root, "scripts", "agent-surface.mjs");
const dir = mkdtempSync(path.join(os.tmpdir(), "as-prov-install-"));

// REA is selected by name, never by a general or asset-category install.
for (const categories of [undefined, ["mcps"], ["development"], ["cybersecurity"]]) {
  const entries = await selectedMcpServiceEntries(true, {
    mode: "build", scope: "user", categoryFilter: categories && new Set(categories),
  });
  assert.ok(!entries.some(([id]) => id === "rea"), "REA stays opt-in");
}
const reaEntries = await selectedMcpServiceEntries(true, {
  mode: "build", scope: "user", categoryFilter: new Set(["mcps"]), optionalServices: new Set(["rea"]),
});
assert.deepEqual(reaEntries.map(([id]) => id), ["rea"]);
assert.deepEqual(reaEntries[0][1].mcp.server, { type: "stdio", command: "rea", args: ["mcp"] });

// ---- excludeServices is the single wiring-exclusion chokepoint --------------------
// A service dropped for failed provisioning must vanish from the entry list WITHOUT being reported as
// a "missing" explicitly-requested service (exclusion happens after the request is validated).
{
  const ctx = (extra) => ({ mode: "install", scope: "project", optionalServices: new Set(["openosint"]), ...extra });
  const included = await selectedMcpServiceEntries(true, ctx());
  assert.deepEqual(included.map(([id]) => id), ["openosint"], "the requested service is selected");
  const excluded = await selectedMcpServiceEntries(true, ctx({ excludeServices: new Set(["openosint"]) }));
  assert.deepEqual(excluded.map(([id]) => id), [], "excludeServices drops the service and does not raise a missing-service error");
}

function install(home, dest, env) {
  mkdirSync(home, { recursive: true });
  mkdirSync(dest, { recursive: true });
  return spawnSync(process.execPath, [cli, "install", "--target", "droid", "--dest", dest, "--category", "mcps", "--service", "openosint"], {
    encoding: "utf8",
    // os.homedir() reads USERPROFILE on Windows and HOME elsewhere; set both so the disposable
    // home applies on every platform.
    env: { ...env, HOME: home, USERPROFILE: home },
  });
}

// Same disposable-home install, for an arbitrary service selection.
function installServices(home, dest, services) {
  mkdirSync(home, { recursive: true });
  mkdirSync(dest, { recursive: true });
  return spawnSync(process.execPath, [cli, "install", "--target", "droid", "--dest", dest, "--category", "mcps", ...services.flatMap((id) => ["--service", id])], {
    encoding: "utf8",
    env: { ...process.env, HOME: home, USERPROFILE: home },
  });
}

try {
  // ---- a partial install must not rewrite a WORKING sibling's configuration -----------
  // Requesting a service whose prerequisite cannot be established drops that service — but every
  // surviving service must stay on the normal resolution path. Rebuilding them without launch
  // wiring would silently downgrade an already-working server to a bare command with no wrapper and
  // no browser path, which then fails to launch under a host's minimal PATH.
  {
    const home = path.join(dir, "partial-home");
    const dest = path.join(dir, "partial-proj");
    const first = installServices(home, dest, ["chrome-devtools"]);
    const configPath = path.join(dest, ".factory", "mcp.json");
    if (first.status !== 0 || !existsSync(configPath)) {
      console.log("provision-install: chrome-devtools prerequisites absent here — skipping the partial-install regression case");
    } else {
      const before = readFileSync(configPath, "utf8");
      assert.match(before, /--executablePath/, "the baseline install wired the resolved browser");
      // synapse-bridge is absent from this disposable HOME, and nothing authorizes installing it.
      const mixed = installServices(home, dest, ["chrome-devtools", "synapse"]);
      assert.notEqual(mixed.status, 0, "an incomplete request reports non-zero");
      assert.match(mixed.stdout, /skipping config for .*synapse/, "the service that could not be established is dropped");
      assert.equal(readFileSync(configPath, "utf8"), before, "the working sibling's configuration is byte-identical — not rewritten with an unresolved command");
      const still = JSON.parse(before).mcpServers["chrome-devtools"];
      assert.ok(existsSync(still.command), "its launch command still exists on disk");
      assert.ok(!Object.hasOwn(JSON.parse(before).mcpServers, "synapse"), "the dropped service was never wired");
    }
  }

  // ---- Arch/openSUSE browser provisioning: Chromium from the official repo ----------
  // Chrome has no official Arch/openSUSE package, so the browser prerequisite must select that
  // distro's chromium recipe instead of having none (which previously made it a hard blocker).
  // Asserted against the REAL registry by exposing only one package manager on PATH. (Full detection
  // is not used here: this host's own /Applications Chrome would satisfy the absolute detect paths.)
  const registry = JSON.parse(readFileSync(path.join(root, "registry", "optional-services.json"), "utf8")).services;
  const browserPrereq = registry["chrome-devtools"].provisioning.prerequisites.find((p) => p.id === "google-chrome");
  assert.equal(browserPrereq.launch_arg, "--executablePath", "the browser prerequisite wires its resolved path into the launch command");
  assert.ok(browserPrereq.detect.paths.includes("/usr/bin/chromium"), "chromium is a detected browser location, so an Arch/openSUSE install resolves after provisioning");
  // Selecting a Linux recipe means resolving its package manager under the POSIX executable-bit
  // rule, and a Windows filesystem cannot express that bit — so this block runs where the rule it
  // depends on exists. The registry contracts below are pure data and are checked everywhere.
  if (process.platform !== "win32") {
    const pickLinuxRecipe = (manager) => {
      const bin = path.join(dir, `${manager}-bin`);
      mkdirSync(bin, { recursive: true });
      writeFileSync(path.join(bin, manager), "#!/bin/sh\n", { mode: 0o755 });
      return selectRecipe(browserPrereq.recipes.linux, { platform: "linux", env: { PATH: bin } });
    };
    assert.deepEqual(pickLinuxRecipe("pacman").run, ["sudo", "pacman", "-S", "--noconfirm", "chromium"], "Arch installs chromium via pacman");
    assert.deepEqual(pickLinuxRecipe("zypper").run, ["sudo", "zypper", "--non-interactive", "install", "chromium"], "openSUSE installs chromium via zypper");
    assert.deepEqual(pickLinuxRecipe("apt-get").run, ["sudo", "apt-get", "install", "-y", "google-chrome-stable"], "Debian/Ubuntu still installs Google Chrome from the Google apt repo");
    assert.equal(selectRecipe(browserPrereq.recipes.linux, { platform: "linux", env: { PATH: path.join(dir, "empty-bin") } }), null, "a Linux host with no supported package manager reports no runnable browser recipe");
  }

  // ---- Windows setup contracts, asserted against the REAL registry --------------------
  const openosintPrereqs = registry.openosint.provisioning.prerequisites;
  const uvPrereq = openosintPrereqs.find((p) => p.id === "uv");

  // The same-run bootstrap must close on Windows too: whatever installs uv has to leave it somewhere
  // re-detection already looks. WinGet packages install into WinGet's own portable locations, which
  // are not on the running process's PATH and are not a declared detect path — so the next
  // `uv tool install` would still fail. The standalone installer targets ~/.local/bin, which IS one.
  const uvWin = selectRecipe(uvPrereq.recipes.win32, { platform: "win32", env: { PATH: "" } });
  assert.ok(uvWin, "a Windows host with no package manager can still bootstrap uv (no `requires` gate)");
  assert.ok(uvWin.run.join(" ").includes("astral.sh/uv/install.ps1"), "Windows uses the standalone installer, whose install directory is predictable");
  // PowerShell 7 first: an install started from a pwsh terminal exports a PSModulePath that Windows
  // PowerShell 5.1 cannot load its own modules from, which breaks the installer outright.
  assert.equal(uvPrereq.recipes.win32[0].requires, "pwsh", "PowerShell 7 is preferred when available");
  assert.equal(selectRecipe(uvPrereq.recipes.win32, { platform: "win32", env: { PATH: "" } }).run[0], "powershell", "Windows PowerShell remains the fallback where pwsh is absent");
  assert.ok(!JSON.stringify(uvPrereq.recipes.win32).includes("ExecutionPolicy"), "-ExecutionPolicy is not requested: it pulls in the very module that fails to load, and `iex` of a string is not governed by it");
  assert.ok(!JSON.stringify(uvPrereq.recipes.win32).includes("winget"), "no WinGet uv recipe: its portable install location is not a declared detect path, so the same-run bootstrap would break");
  assert.ok(uvPrereq.detect.paths.includes("~/.local/bin/uv.exe"), "the standalone installer's Windows target IS a declared detect path, closing the bootstrap");

  // Once the operator has authorized installation, WinGet must not stop for agreements or prompts.
  for (const [service, id] of [["synapse", "node-runtime"], ["grimoire", "node-runtime"], ["chrome-devtools", "node-runtime"], ["chrome-devtools", "google-chrome"]]) {
    const recipe = registry[service].provisioning.prerequisites.find((p) => p.id === id).recipes.win32[0];
    assert.equal(recipe.requires, "winget", `${service}/${id} uses winget on Windows`);
    for (const flag of ["--silent", "--disable-interactivity", "--accept-package-agreements", "--accept-source-agreements"]) {
      assert.ok(recipe.run.includes(flag), `${service}/${id} carries the granted authorization into WinGet as ${flag}`);
    }
    assert.equal(recipe.elevation, true, `${service}/${id} declares that its machine-wide install still needs OS elevation`);
  }

  // The extras probe must ask uv where its tool environments live rather than assume a layout:
  // Windows uv defaults to %APPDATA%\uv\data\tools, so a hard-coded POSIX path drops a good install.
  const extras = openosintPrereqs.find((p) => p.id === "openosint-extras").detect.python;
  assert.deepEqual(extras.interpreter_root, { prerequisite: "uv", run: ["tool", "dir"] }, "the extras interpreter root is resolved from the detected uv");
  assert.ok(extras.interpreter_subpaths.includes("openosint/Scripts/python.exe"), "the Windows venv layout is covered under that root");
  assert.ok(!JSON.stringify(extras.interpreter).includes("Scripts"), "no hard-coded Windows tool directory remains in the fallback list");
  assert.ok(openosintPrereqs.indexOf(uvPrereq) < openosintPrereqs.findIndex((p) => p.id === "openosint-extras"), "uv is detected before the extras that query it (registry order is dependency order)");

  // ---- an optional prerequisite must not be able to fail a required one -------------------
  // `optional` is a promise that a failure here cannot drop the service. Sharing one command between
  // a required and an optional prerequisite silently breaks that promise: dedupeActions collapses
  // identical run lists into a SINGLE action, so the two stop being independently installable and
  // one unresolvable optional package fails the install the service needs. Asserted registry-wide —
  // this is a shape no service may adopt, not an openosint detail. (A command may still be shared
  // between two REQUIRED prerequisites; that is what dedupe is for, and openosint-mcp and
  // openosint-extras do exactly that.)
  // Checked on the DECLARED recipes, before deduplication. Which of the two survives the collapse
  // depends on registry order; the hazard does not, since either way the prerequisites stop being
  // independently installable. Comparing after the collapse would accept the same defect written in
  // the other order.
  const recipeKey = (recipe) => JSON.stringify([recipe.run, recipe.cwd ?? null]);
  // That key has to stay the one the executor actually collapses on, or this check quietly drifts
  // away from the behavior it exists to constrain.
  assert.equal(dedupeActions([{ run: ["a"], cwd: null }, { run: ["a"] }]).length, 1, "dedupeActions collapses on run + cwd, an absent cwd being null — the key used here");
  assert.equal(dedupeActions([{ run: ["a"], cwd: null }, { run: ["a"], cwd: "repo" }]).length, 2, "and keeps recipes differing in either part");
  for (const [serviceId, service] of Object.entries(registry)) {
    for (const platform of ["darwin", "linux", "win32"]) {
      const declared = new Map();
      for (const prereq of service.provisioning?.prerequisites ?? []) {
        for (const recipe of prereq.recipes?.[platform] ?? []) {
          const optional = prereq.optional === true;
          const seen = declared.get(recipeKey(recipe));
          if (seen) assert.equal(seen.optional, optional, `${serviceId}/${platform}: ${seen.id} and ${prereq.id} share one recipe across the optional boundary, so the optional one's failure would drop the service`);
          else declared.set(recipeKey(recipe), { id: prereq.id, optional });
        }
      }
    }
  }

  // openosint's optional lookup tools are the required install PLUS three packages. Being a strict
  // superset is what makes the second install safe to run after the first: it can only add, and a
  // requirement set uv cannot RESOLVE is rejected before it replaces anything, so the environment
  // the first step built survives. That is a claim about resolution failure specifically — not about
  // an install interrupted midway.
  for (const platform of ["darwin", "linux", "win32"]) {
    const required = openosintPrereqs.find((p) => p.id === "openosint-mcp").recipes[platform][0].run;
    const withTools = openosintPrereqs.find((p) => p.id === "openosint-tools").recipes[platform][0].run;
    assert.deepEqual(withTools.slice(0, required.length), required, `${platform}: the optional tools install extends the required one rather than diverging from it`);
    assert.deepEqual(withTools.slice(required.length), ["--with", "holehe", "--with", "sublist3r", "--with", "sherlock-project"], `${platform}: and adds exactly the lookup packages`);
  }

  // ---- launch_arg wiring: the resolved browser path reaches the generated launch command ----
  const wired = await selectedMcpServiceEntries(true, {
    mode: "install", scope: "project", optionalServices: new Set(["chrome-devtools"]),
    launchWiring: { "chrome-devtools": { command: "/abs/bin/npx", args: ["--executablePath", "/usr/bin/chromium"] } },
  });
  const [, chromeSvc] = wired.find(([id]) => id === "chrome-devtools");
  assert.equal(chromeSvc.mcp.server.command, "/abs/bin/npx", "the bare launch command is replaced by the resolved absolute path");
  assert.deepEqual(chromeSvc.mcp.server.args.slice(-2), ["--executablePath", "/usr/bin/chromium"], "the provisioned browser path is appended as --executablePath");

  // ---- an env-shebang launch binary is wrapped so the validated Node reaches the WHOLE chain ----
  // npx is `#!/usr/bin/env node`, and so is the MCP bin npx spawns: under a host's minimal PATH the
  // chain dies at `env: node`. Such a server launches through the wrapper (which puts the validated
  // Node on the child's PATH) — but must NOT receive the credential env-file, since it declares none.
  // Shebangs are a POSIX mechanism; the Windows equivalent (a .cmd shim) is asserted above.
  if (process.platform !== "win32") {
    const envShebangCmd = path.join(dir, "npx-like");
    writeFileSync(envShebangCmd, "#!/usr/bin/env node\n", { mode: 0o755 });
    const shebangWired = await selectedMcpServiceEntries(true, {
      mode: "install", scope: "project", optionalServices: new Set(["chrome-devtools"]), envFilePath: path.join(dir, "proj.env"),
      launchWiring: { "chrome-devtools": { command: envShebangCmd, args: ["--executablePath", "/usr/bin/chromium"] } },
    });
    const [, shebangSvc] = shebangWired.find(([id]) => id === "chrome-devtools");
    assert.equal(path.basename(shebangSvc.mcp.server.command), "agent-surface-mcp-env", "an env-shebang launch binary is routed through the runtime wrapper");
    assert.ok(!shebangSvc.mcp.server.args.includes("--as-env-file"), "a keyless server wrapped only for the runtime PATH is NOT handed the credential env-file");
    assert.equal(shebangSvc.mcp.server.args.filter((a) => a === "--executablePath").length, 1, "the browser path is appended exactly once");
    assert.equal(shebangSvc.mcp.server.args[shebangSvc.mcp.server.args.indexOf("--") + 1], envShebangCmd, "the real command follows the -- terminator");
  }

  // ---- native Windows: the wrapper is the pinned node.exe, and .cmd shims route through it ----
  // npm installs console entry points as .cmd shims that fall back to a bare `node` (no node.exe is
  // adjacent to an npx cache dir), and a Node-based host cannot spawn a batch file directly at all.
  // So a Windows install wraps them — but the wrapper must NOT itself be a .cmd/extensionless stub
  // for the same reason: it is the install-pinned node.exe plus the launcher module.
  const winCmd = "C:\\Program Files\\nodejs\\npx.cmd";
  const winChrome = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";
  const winWired = await selectedMcpServiceEntries(true, {
    mode: "install", scope: "project", platform: "win32", optionalServices: new Set(["chrome-devtools"]),
    envFilePath: path.join(dir, "proj.env"),
    launchWiring: { "chrome-devtools": { command: winCmd, args: ["--executablePath", winChrome] } },
  });
  const [, winSvc] = winWired.find(([id]) => id === "chrome-devtools");
  assert.equal(winSvc.mcp.server.command, process.execPath, "on Windows the wrapper is the install-pinned node.exe — a real executable every host can spawn");
  assert.equal(winSvc.mcp.server.args[0], mcpLaunchScriptCopy(), "the per-user launcher copy, not the checkout's module, is node's first argument");
  assert.ok(!winSvc.mcp.server.args.includes("--as-env-file"), "a keyless server still receives no credential env-file on Windows");
  assert.equal(winSvc.mcp.server.args[winSvc.mcp.server.args.indexOf("--") + 1], winCmd, "the real .cmd shim follows the -- terminator (the launcher runs it through cmd.exe)");
  assert.deepEqual(winSvc.mcp.server.args.slice(-2), ["--executablePath", winChrome], "the provisioned Windows browser path is wired exactly once");
  assert.equal(winSvc.mcp.server.args.filter((a) => a === "--executablePath").length, 1);

  // A Windows .exe launch binary is self-sufficient: no shim, no PATH lookup → direct launch.
  const winExeWired = await selectedMcpServiceEntries(true, {
    mode: "install", scope: "project", platform: "win32", optionalServices: new Set(["chrome-devtools"]),
    launchWiring: { "chrome-devtools": { command: "C:\\tools\\thing.exe" } },
  });
  assert.equal(winExeWired.find(([id]) => id === "chrome-devtools")[1].mcp.server.command, "C:\\tools\\thing.exe", "a Windows .exe keeps its direct launch path");

  // ---- a HOME-relative registry command still takes the resolved path ----------------------
  // The first-party servers name their launcher as `~/.local/bin/<name>`, but the installed FILE is
  // not spelled that way on every platform: Windows has no shebang, so the launcher is `<name>.cmd`.
  // Expanding the registry text would point at a file that does not exist there, so the path
  // provisioning actually detected must win over the registry spelling.
  const winShim = "C:\\Users\\dev\\.local\\bin\\synapse-bridge.cmd";
  const fpWin = await selectedMcpServiceEntries(true, {
    mode: "install", scope: "project", platform: "win32", // no optionalServices: the default first-party selection
    launchWiring: { synapse: { command: winShim } },
  });
  const [, synapseWin] = fpWin.find(([id]) => id === "synapse");
  assert.equal(synapseWin.mcp.server.command, process.execPath, "a .cmd launcher is routed through the pinned node.exe wrapper, which no host can spawn a batch file without");
  assert.equal(synapseWin.mcp.server.args[synapseWin.mcp.server.args.indexOf("--") + 1], winShim, "the resolved .cmd shim follows the -- terminator, not the registry's extensionless spelling");
  assert.ok(!synapseWin.mcp.server.args.includes("--as-env-file"), "a keyless first-party server receives no credential env-file");

  if (process.platform !== "win32") {
    const posixShim = path.join(dir, "synapse-bridge");
    writeFileSync(posixShim, "#!/bin/sh\n", { mode: 0o755 });
    const fpPosix = await selectedMcpServiceEntries(true, {
      mode: "install", scope: "project",
      launchWiring: { synapse: { command: posixShim } },
    });
    const [, synapsePosix] = fpPosix.find(([id]) => id === "synapse");
    assert.equal(synapsePosix.mcp.server.command, posixShim, "on POSIX the same rule yields the resolved path on a direct launch (no wrapper)");
  }

  // dist/build must stay machine-agnostic: no host Node path and no platform baked in.
  const built = await selectedMcpServiceEntries(true, { mode: "build", scope: "project", platform: "win32", optionalServices: new Set(["openosint"]) });
  assert.equal(built.find(([id]) => id === "openosint")[1].mcp.server.command, MCP_ENV_LAUNCHER, "build output keeps the portable launcher path (never a host's node.exe)");

  // A launch binary that is NOT an env-shebang script keeps its direct launch path (no wrapper) —
  // this is why synapse/grimoire (`#!/bin/sh`, absolute interpreter) are untouched.
  const plainCmd = path.join(dir, "plain-bin");
  writeFileSync(plainCmd, "#!/bin/sh\n", { mode: 0o755 });
  const plainWired = await selectedMcpServiceEntries(true, {
    mode: "install", scope: "project", optionalServices: new Set(["chrome-devtools"]),
    launchWiring: { "chrome-devtools": { command: plainCmd } },
  });
  const [, plainSvc] = plainWired.find(([id]) => id === "chrome-devtools");
  assert.equal(plainSvc.mcp.server.command, plainCmd, "an absolute-interpreter binary stays on its direct launch path");

  // ---- headless + missing REQUIRED prerequisite + no -y → block, wire nothing ----
  // A restricted PATH hides uv/openosint-mcp, and the disposable HOME has no ~/.local/bin binary, so
  // both required prerequisites read missing. Headless without -y must refuse to run the recipes.
  const blockHome = path.join(dir, "block-home");
  const blockDest = path.join(dir, "block-proj");
  const blocked = install(blockHome, blockDest, { PATH: "/usr/bin:/bin" });
  assert.equal(blocked.status, 1, "a missing required prerequisite blocks a headless install");
  assert.match(blocked.stdout, /re-run with -y/, "the block explains how to authorize the install");
  // The executor logs "provisioning: ok"/"provisioning: FAILED" only AFTER a real spawn; their
  // absence proves no recipe ran (the remediation text may echo the recipe command — that is fine).
  assert.doesNotMatch(blocked.stdout, /provisioning: (ok|FAILED)/, "no recipe is executed when authorization is denied");
  assert.ok(!existsSync(path.join(blockDest, ".factory", "mcp.json")), "no host config is written when prerequisites are unmet (existing config preserved)");
  assert.ok(!existsSync(path.join(blockHome, ".local", "bin", "openosint-mcp")), "the installer did not install the missing binary");
  assert.ok(!existsSync(path.join(blockHome, ".local", "bin", "agent-surface-mcp-env")), "no launcher is materialized for a blocked install");
  assert.ok(!existsSync(mcpLaunchScriptCopy(blockHome)), "no launcher copy is written for a blocked install");

  // ---- a launch binary agent-surface cannot install: report it, wire nothing ----
  // These services use an existing installation. An absent executable must not produce a broken
  // host entry or trigger a package-manager install.
  for (const [service, binary] of [["ida-pro-mcp", "idalib-mcp"], ["rea", "rea"]]) {
    const home = path.join(dir, `${service}-home`);
    const dest = path.join(dir, `${service}-proj`);
    mkdirSync(home, { recursive: true });
    mkdirSync(dest, { recursive: true });
    const result = spawnSync(process.execPath, [cli, "install", "--target", "droid", "--dest", dest, "--category", "mcps", "--service", service], {
      encoding: "utf8",
      env: { PATH: "/usr/bin:/bin", HOME: home, USERPROFILE: home },
    });
    assert.equal(result.status, 1, `an absent launch binary with no recipe reports non-zero: ${result.stderr || result.stdout}`);
    assert.match(result.stdout, new RegExp(`mcp prerequisites unmet: missing required prerequisites with no \\S+ recipe: ${service}/${binary}$`, "m"));
    assert.doesNotMatch(result.stdout, /provisioning: (ok|FAILED)/, "no package manager is run");
    assert.ok(!existsSync(path.join(dest, ".factory", "mcp.json")), "nothing is wired for the dropped service");
  }

  // ---- satisfied prerequisites → wire openosint with the RESOLVED ABSOLUTE launch path (P1) ------
  // Real-environment integration evidence (peer#3): symlink the developer's ACTUAL openosint uv-tool
  // env into the disposable HOME so the extras are probed in the REAL interpreter against the REAL
  // libraries — no `exit 0` stub stands in as proof. openosint-mcp/uv resolve via the real PATH. If
  // that real env is absent (e.g. CI without openosint), the integration prerequisite is reported
  // unavailable and this case is skipped rather than faked. Readiness is judged in the install's own
  // HOME and environment, because a binary the developer's HOME provides can be missing from the
  // disposable one.
  const realVenv = path.join(os.homedir(), ".local", "share", "uv", "tools", "openosint");
  const okHome = path.join(dir, "ok-home");
  const okDest = path.join(dir, "ok-proj");
  const okEnv = { ...process.env, HOME: okHome, USERPROFILE: okHome };
  if (existsSync(realVenv)) {
    mkdirSync(path.join(okHome, ".local", "share", "uv", "tools"), { recursive: true });
    symlinkSync(realVenv, path.join(okHome, ".local", "share", "uv", "tools", "openosint"));
  }
  const realEntries = await selectedMcpServiceEntries(true, { mode: "install", scope: "project", optionalServices: new Set(["openosint"]) });
  const realSatisfied = existsSync(realVenv)
    && provisioningStatus(realEntries, { homedir: okHome, env: okEnv }).every((s) => s.prerequisites.every((p) => p.satisfied));
  if (!realSatisfied) {
    console.log("provision-install: openosint integration prerequisite unavailable — skipping the real-env wire assertion");
  } else {
    const ok = install(okHome, okDest, okEnv);
    assert.equal(ok.status, 0, `a satisfied install proceeds: ${ok.stderr || ok.stdout}`);
    assert.match(ok.stdout, /openosint-mcp ok/, "the already-present binary is reported satisfied");
    assert.match(ok.stdout, /openosint-extras ok/, "the provider extras are satisfied (probed in the REAL openosint interpreter)");
    assert.doesNotMatch(ok.stdout, /uv tool install|brew install/, "no recipe runs when prerequisites are already satisfied");
    const entry = JSON.parse(readFileSync(path.join(okDest, ".factory", "mcp.json"), "utf8")).mcpServers.openosint;
    assert.ok(entry, "openosint is wired once its prerequisites are satisfied");
    // P1: the wrapped launch command is the resolved ABSOLUTE path, not the bare registry name, so a
    // tool installed outside the launch PATH is still found.
    const launched = entry.args[entry.args.indexOf("--") + 1];
    assert.ok(path.isAbsolute(launched), `wrapped launch command must be absolute, got: ${launched}`);
    assert.equal(path.basename(launched), "openosint-mcp", "the resolved launch binary is openosint-mcp");
    assert.ok(existsSync(launched), "the resolved launch path exists on disk");
  }
} finally {
  rmSync(dir, { recursive: true, force: true });
}

console.log("provision-install: ok");
