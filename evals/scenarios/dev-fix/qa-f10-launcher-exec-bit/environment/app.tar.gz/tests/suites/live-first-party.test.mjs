#!/usr/bin/env node
// LIVE acceptance for the two first-party MCPs, through the product's own path, in five phases:
//   1. INSTALL: agent-surface provisions synapse and grimoire by running their registry recipe on
//      this platform (build, link the launcher, build grimoire's index) and wires the host config
//   2. STARTUP: launch each wired command UNCHANGED and require a real MCP session from the
//      installed server — initialize plus tools/list
//   3. CAPABILITY: call the tools, not just list them — a disposable memory write and recall, and a
//      retrieval pass over the combined pack corpus including near-duplicates and a non-match
//   4. REPEAT: install again; the prerequisites are already satisfied, so nothing is re-provisioned
//      and the generated config is byte-identical
//   5. LIFECYCLE: reinstall while a synapse session is open — the case Windows makes distinct,
//      since a running process there can hold the files an install rewrites — then start again
//
// Everything runs in a disposable home.
//
// Opt-in (network: npm install for both packages): AGENT_SURFACE_LIVE_FIRST_PARTY=1. Without it
// this skips, so the default suite stays hermetic and offline.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { mcpSession, minimalLaunchEnv } from "../lib/mcp-session.mjs";

// Opt-in guard. NOT process.exit(): these suites are imported by the shared runner, so
// exiting here would silently end the whole run and report success for suites never run.
const enabled = process.env.AGENT_SURFACE_LIVE_FIRST_PARTY === "1";
if (!enabled) console.log("live-first-party: skipped (set AGENT_SURFACE_LIVE_FIRST_PARTY=1 to run the networked first-party acceptance)");

if (enabled) {
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
  const cli = path.join(root, "scripts", "agent-surface.mjs");
  const windows = process.platform === "win32";

  const dir = mkdtempSync(path.join(os.tmpdir(), "as-live-fp-"));
  const home = path.join(dir, "home");
  const dest = path.join(dir, "project");
  const configPath = path.join(dest, ".factory", "mcp.json");

  // os.homedir() reads USERPROFILE on Windows and HOME elsewhere; both are set so the installer,
  // the launcher and the servers all agree on where the disposable home is.
  const installEnv = { ...process.env, HOME: home, USERPROFILE: home };
  const install = (label) => {
    const result = spawnSync(process.execPath, [cli, "install", "--target", "droid", "--dest", dest, "--category", "mcps", "--service", "synapse", "--service", "grimoire", "-y"], { encoding: "utf8", env: installEnv });
    console.log(result.stdout);
    assert.equal(result.status, 0, `${label} failed: ${result.stderr || result.stdout}`);
    return result.stdout;
  };

  // Launch a wired server exactly as the generated config spells it, from another working directory
  // under a minimal PATH that is never repaired here.
  const startServer = (entry, expected) => mcpSession(entry.command, entry.args ?? [], {
    cwd: os.tmpdir(),
    env: minimalLaunchEnv(home),
    timeoutMs: 120000,
  }, async ({ call, serverInfo }) => {
    const { tools } = await call("tools/list", {});
    return { serverInfo, names: tools.map((tool) => tool.name) };
  }).then((session) => {
    assert.equal(session.serverInfo.name, expected.name, `unexpected server identity: ${JSON.stringify(session.serverInfo)}`);
    for (const tool of expected.tools) assert.ok(session.names.includes(tool), `${expected.name} advertised ${tool}: ${session.names.join(", ")}`);
    return session;
  });

  // Drive real tool calls over the same wired launch command. `tools/list` proves a server answered;
  // only calling a tool proves the capability the config was wired for.
  const useServer = (entry, steps) => mcpSession(entry.command, entry.args ?? [], {
    cwd: os.tmpdir(),
    env: minimalLaunchEnv(home),
    timeoutMs: 180000,
  }, steps);
  const callTool = async (call, name, args) => {
    const result = await call("tools/call", { name, arguments: args });
    assert.ok(!result.isError, `${name} failed: ${JSON.stringify(result).slice(0, 400)}`);
    const text = (result.content ?? []).filter((part) => part.type === "text").map((part) => part.text).join("");
    // Some tools prefix their payload with a provenance line for the model's benefit, so parse from
    // the first structural character rather than assuming the whole body is JSON.
    const start = text.search(/[[{]/);
    if (start === -1) return text;
    try { return JSON.parse(text.slice(start)); } catch { return text; }
  };

  try {
    mkdirSync(home, { recursive: true });
    mkdirSync(dest, { recursive: true });

    // ---- phase 1: install through the product's own provisioning ------------------------
    const first = install("install");
    assert.match(first, /provisioning: ok agent-surface repo build \(mcps\/synapse\/install\.mjs\)/, "synapse was built by its registry recipe on this platform");
    assert.match(first, /provisioning: ok agent-surface repo build \(mcps\/grimoire\/install\.mjs\)/, "grimoire was built by its registry recipe on this platform");

    const servers = JSON.parse(readFileSync(configPath, "utf8")).mcpServers;
    for (const id of ["synapse", "grimoire"]) assert.ok(servers[id], `${id} was not wired: ${first}`);
    const launchTarget = (entry) => (entry.args?.includes("--") ? entry.args[entry.args.indexOf("--") + 1] : entry.command);
    for (const id of ["synapse", "grimoire"]) {
      const target = launchTarget(servers[id]);
      assert.ok(path.isAbsolute(target) && existsSync(target), `${id}'s launch target is an absolute path that exists: ${target}`);
      // The shim is named in the platform's idiom; the registry still spells it without an extension.
      assert.match(path.basename(target), windows ? /^(synapse-bridge|grimoire-server)\.cmd$/ : /^(synapse-bridge|grimoire-server)$/, `unexpected launch target: ${target}`);
      assert.ok(!(servers[id].args ?? []).includes("--as-env-file"), `${id} is keyless and is never handed a credential env-file`);
      console.log(`wired ${id}: ${servers[id].command} ${JSON.stringify(servers[id].args ?? [])}`);
    }

    // ---- phase 2: the installed servers actually start -----------------------------------
    const synapse = await startServer(servers.synapse, { name: "synapse", tools: ["memory_remember", "memory_recall", "lock_acquire"] });
    const grimoire = await startServer(servers.grimoire, { name: "grimoire", tools: ["grimoire_search", "grimoire_get"] });
    console.log(`live-first-party: started synapse ${synapse.serverInfo.version} (${synapse.names.length} tools) and grimoire ${grimoire.serverInfo.version} (${grimoire.names.length} tools)`);

    // ---- phase 3: the wired servers do their job ------------------------------------------
    // Synapse: what one session stores, a later session gets back. The record is written into the
    // disposable home and dies with it, so this never touches the operator's own memory.
    const fact = `agent-surface first-party acceptance ${path.basename(dir)} stored this disposable record`;
    await useServer(servers.synapse, async ({ call }) => {
      await callTool(call, "memory_remember", { content: fact, tags: ["agent-surface-acceptance"] });
    });
    const recalled = await useServer(servers.synapse, ({ call }) =>
      callTool(call, "memory_recall", { query: "disposable record", tags: ["agent-surface-acceptance"], mode: "full" }));
    assert.ok(JSON.stringify(recalled).includes(fact), `a fresh session did not recall what the first one stored: ${JSON.stringify(recalled).slice(0, 400)}`);
    assert.ok(existsSync(path.join(home, ".synapse")), "and it was stored inside the disposable home");

    // Grimoire: retrieval over the combined pack corpus. A pack that failed to index would still
    // answer tools/list, so the claim worth testing is that the right skill comes back and that its
    // content is the source's — plus the two cases a naive index gets wrong.
    const knownSkill = "hack-skills:symbolic-execution-tools";
    // The same technique, written up independently by two packs. Both must survive indexing:
    // collapsing them would silently drop one pack's procedure, and neither pack outranks the other.
    const nearDuplicates = ["anthropic-cybersecurity-skills:performing-mobile-app-certificate-pinning-bypass", "hack-skills:mobile-ssl-pinning-bypass"];
    const retrieval = await useServer(servers.grimoire, async ({ call }) => ({
      known: await callTool(call, "grimoire_search", { query: "angr symbolic execution", k: 5 }),
      duplicates: await callTool(call, "grimoire_search", { query: "certificate pinning bypass", k: 5 }),
      // Search matches any query word, so a query about an uncovered topic still returns its
      // nearest lexical rows. What must stay true is that nothing is padded: when no word of
      // the query occurs in any indexed skill, the answer is empty. Both of these words do
      // occur in none of them ("proofing" would not qualify: it stems to "proof").
      absent: await callTool(call, "grimoire_search", { query: "sourdough marzipan", k: 5 }),
      document: await callTool(call, "grimoire_get", { id: knownSkill }),
    }));
    assert.equal(retrieval.known.hits?.[0]?.id, knownSkill, `the distinctive query did not rank its skill first: ${JSON.stringify(retrieval.known).slice(0, 300)}`);
    // The WHOLE body, not a recognizable line of it: a truncated or stale document would still
    // carry its heading. Frontmatter is split off exactly the way the indexer splits it.
    const sourceSkill = readFileSync(path.join(root, "external", "hack-skills", "skills", "symbolic-execution-tools", "SKILL.md"), "utf8");
    const frontmatter = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?/.exec(sourceSkill);
    assert.ok(frontmatter, "the source skill carries the frontmatter the indexer strips");
    assert.equal(retrieval.document.skill?.id, knownSkill, "the served document is the skill that was asked for");
    assert.equal(retrieval.document.skill?.body, sourceSkill.slice(frontmatter[0].length), "the served body is the packaged source, complete and unmodified");
    const duplicateIds = (retrieval.duplicates.hits ?? []).map((hit) => hit.id);
    for (const id of nearDuplicates) assert.ok(duplicateIds.includes(id), `${id} did not survive indexing alongside its near-duplicate: ${duplicateIds.join(", ")}`);
    assert.deepEqual(retrieval.absent.hits, [], `a query whose every word is absent from the index returned rows: ${JSON.stringify(retrieval.absent).slice(0, 300)}`);
    console.log(`live-first-party: recalled the disposable record, ranked ${knownSkill} first and served its whole body, kept both near-duplicates, returned nothing for words absent from every pack`);

    // ---- phase 4: repeat install is idempotent -------------------------------------------
    const before = readFileSync(configPath, "utf8");
    const second = install("repeat install");
    assert.doesNotMatch(second, /provisioning: ok agent-surface repo build/, "an already-satisfied prerequisite is not rebuilt");
    assert.match(second, /synapse-bridge ok/, "synapse's launcher is detected as present on re-run");
    assert.match(second, /grimoire-server ok/, "grimoire's launcher is detected as present on re-run");
    assert.equal(readFileSync(configPath, "utf8"), before, "the generated config is byte-identical on re-run");

    // ---- phase 5: reinstall while a synapse session is open --------------------------------
    // The interesting platform is Windows, where a running process can hold the very files an
    // install rewrites. The session stays open across the rebuild and must keep answering, and a
    // new session must start from the rebuilt files.
    await useServer(servers.synapse, async ({ call }) => {
      const third = spawnSync(process.execPath, [path.join(root, "mcps", "synapse", "install.mjs")], { encoding: "utf8", env: installEnv });
      console.log(third.stdout.split("\n").slice(-6).join("\n"));
      assert.equal(third.status, 0, `reinstall with a session open failed: ${third.stderr}`);
      const still = await callTool(call, "memory_recall", { query: "disposable record", tags: ["agent-surface-acceptance"], mode: "full" });
      assert.ok(JSON.stringify(still).includes(fact), "the open session still answers after the rebuild");
    });
    const restarted = await startServer(servers.synapse, { name: "synapse", tools: ["memory_remember"] });
    assert.ok(restarted.names.length > 0, "synapse-bridge starts from the rebuilt files");
    console.log(`live-first-party: rebuilt with a session open, server restarted, platform=${process.platform}`);
  } finally {
    // Retry, then REPORT rather than throw: Windows keeps handles open briefly after a process
    // exits, and throwing from `finally` would replace the real failure.
    try {
      rmSync(dir, { recursive: true, force: true, maxRetries: 20, retryDelay: 250 });
    } catch (error) {
      console.log(`live-first-party: could not remove the temporary directory ${dir} (${error.code})`);
    }
  }

  console.log("live-first-party: ok");
}
