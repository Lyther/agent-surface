#!/usr/bin/env node
// End-to-end credential delivery: install a credentialed MCP into a disposable HOME, then run the
// EXACT generated command from the config (only the real MCP binary after `--` is swapped for a
// probe) to prove the installer-collected credential reaches the launched process. A disposable
// HOME — not a bin-directory override — keeps the generated command and the materialized wrapper on
// the same path, so the test exercises entry.command itself. The probe run is an env-delivery
// DIAGNOSTIC, not real-MCP evidence (the real OpenOSINT process is verified out of band).
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { provisioningStatus } from "../../scripts/agent-surface/provision.mjs";
import { mcpLaunchScriptCopy } from "../../scripts/agent-surface/merge.mjs";
import { pinnedNodePath } from "../../scripts/agent-surface/mcp-shims.mjs";
import { selectedMcpServiceEntries } from "../../scripts/agent-surface/targets.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const cli = path.join(root, "scripts", "agent-surface.mjs");
const dir = mkdtempSync(path.join(os.tmpdir(), "as-cred-launch-"));

// Install into a disposable HOME so the config's "~" and the wrapper both resolve to the same place.
function install(home, dest, extra, target = "droid") {
  mkdirSync(home, { recursive: true });
  mkdirSync(dest, { recursive: true });
  return spawnSync(process.execPath, [cli, "install", "--target", target, "--dest", dest, "--category", "mcps", ...extra], {
    encoding: "utf8",
    // os.homedir() reads USERPROFILE on Windows and HOME elsewhere; set both so the disposable
    // home applies on every platform.
    env: { ...process.env, HOME: home, USERPROFILE: home },
  });
}

// Seed the path-based prerequisites inside the disposable HOME so this suite runs NO package
// manager and needs no network: provisioning execution belongs to provision-exec and the opt-in
// live-provision suite, while this suite is about credential delivery and launch shape. These stubs
// stand in only for "a binary exists at this path"; none of them is offered as evidence that the
// real tool works. The installs never pass -y, so a prerequisite the seeds miss cannot start a real
// recipe.
function seedBin(home, name, body = "#!/bin/sh\nexit 0\n") {
  const bin = path.join(home, ".local", "bin");
  mkdirSync(bin, { recursive: true });
  writeFileSync(path.join(bin, name), body, { mode: 0o755 });
}

function seedOpenosintPrerequisites(home) {
  const tools = path.join(home, ".local", "share", "uv", "tools");
  // `uv tool dir` is how the extras probe locates openosint's own interpreter; answer with the
  // seeded tools directory so that resolution path is the one exercised.
  seedBin(home, "uv", `#!/bin/sh\necho "${tools}"\n`);
  seedBin(home, "openosint-mcp");
  const venvBin = path.join(tools, "openosint", "bin");
  mkdirSync(venvBin, { recursive: true });
  writeFileSync(path.join(venvBin, "python"), "#!/bin/sh\nexit 0\n", { mode: 0o755 });
}

// Whether the installer could proceed for a service under this HOME, asked of the REAL detector so
// the skip condition is exactly the block condition. Some prerequisites are properties of the host
// and must not be faked: synapse's Node >=22.17 floor (node:sqlite), and openosint's extras, which
// are probed by running a real Python interpreter — creating one is not possible on Windows, where
// executability is by extension and a shell stub is not an executable.
async function serviceIsProvisionable(id, homedir) {
  const entries = (await selectedMcpServiceEntries(true, { mode: "install", scope: "project", optionalServices: new Set([id]) })).filter(([entryId]) => entryId === id);
  const status = provisioningStatus(entries, { homedir });
  const unmet = status.flatMap((service) => service.prerequisites.filter((prereq) => !prereq.satisfied).map((prereq) => prereq.id));
  return { ok: unmet.length === 0, unmet };
}

try {
  // ---- credentialed server: wrapper materialized AT the generated command path ----
  const home = path.join(dir, "home");
  const dest = path.join(dir, "proj");
  seedOpenosintPrerequisites(home);
  const openosintReady = await serviceIsProvisionable("openosint", home);
  if (!openosintReady.ok) {
    console.log(`mcp-credential-launch: openosint prerequisite unavailable here (${openosintReady.unmet.join(", ")}) — skipping the credential-delivery case`);
  } else {
    const res = install(home, dest, ["--service", "openosint"]);
    assert.equal(res.status, 0, `install failed: ${res.stderr || res.stdout}`);

    const entry = JSON.parse(readFileSync(path.join(dest, ".factory", "mcp.json"), "utf8")).mcpServers.openosint;

    // F008/F009: the generated command IS the materialized wrapper — config points exactly where the
    // wrapper was written (both resolve against the same $HOME), and it exists.
    const wrapper = path.join(home, ".local", "bin", "agent-surface-mcp-env");
    assert.equal(entry.command, wrapper, "generated command is the wrapper at the resolved $HOME path");
    assert.ok(existsSync(entry.command), "the wrapper exists at exactly the path the config launches");

    // F007: the wrapper pins the install Node by absolute path (survives a minimal PATH).
    const wrapperText = readFileSync(entry.command, "utf8");
    assert.match(wrapperText, /^#!\/bin\/sh/, "wrapper is a shell script");
    assert.ok(wrapperText.includes(`node_bin='${pinnedNodePath()}'`), "wrapper pins the install Node by absolute path");
    assert.ok(statSync(entry.command).mode & 0o100, "wrapper is executable");
    // The wrapper execs a per-user copy of the launcher, never the installing checkout's own, so
    // deleting or moving that checkout leaves the launcher in place.
    const launcherCopy = path.join(home, ".local", "share", "agent-surface", "mcp-env-launch.mjs");
    assert.ok(wrapperText.includes(`exec "$node_bin" '${launcherCopy}' "$@"`), "the wrapper execs the per-user launcher copy");
    assert.ok(!wrapperText.includes(root), "the wrapper names nothing inside the installing checkout");
    assert.equal(readFileSync(launcherCopy, "utf8"), readFileSync(path.join(root, "scripts", "agent-surface", "mcp-env-launch.mjs"), "utf8"), "the copy is the shipped launcher");
    // An uninstall or a version manager can still remove the pinned executable.
    // The wrapper then falls back to PATH's node, as the first-party shims do, instead of failing.
    const staleWrapper = path.join(dir, "stale-node-wrapper");
    writeFileSync(staleWrapper, wrapperText.replace(pinnedNodePath(), path.join(dir, "removed-node", "node")), { mode: 0o755 });
    const emptyEnv = path.join(dir, "empty.env");
    writeFileSync(emptyEnv, "", { mode: 0o600 });
    const fallback = spawnSync(staleWrapper, ["--as-env-file", emptyEnv, "--", "/bin/sh", "-c", "printf fallback-ok"], {
      encoding: "utf8",
      env: { PATH: `${path.dirname(process.execPath)}:/usr/bin:/bin`, HOME: home },
    });
    assert.equal(fallback.stdout, "fallback-ok", `a wrapper whose pinned Node is gone launches through PATH's node: ${fallback.stderr}`);
    assert.equal(fallback.status, 0, fallback.stderr);
    assert.match(fallback.stderr, /is gone; using node from PATH/, "the fallback names the missing Node");
    // Without a node on PATH that meets the package's floor, the wrapper stops on a line naming the
    // floor instead of failing inside the launcher. An empty PATH directory stands for the IDE's.
    const floor = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).engines.node.replace(/^>=(\d+\.\d+)\.0$/, "$1");
    const noNodeBin = path.join(dir, "no-node-bin");
    mkdirSync(noNodeBin);
    const unusable = spawnSync(staleWrapper, ["--as-env-file", emptyEnv, "--", "/bin/sh", "-c", "printf unreachable"], {
      encoding: "utf8",
      env: { PATH: noNodeBin, HOME: home },
    });
    assert.equal(unusable.status, 1, unusable.stderr);
    assert.equal(unusable.stdout, "", "nothing launches without a usable node");
    assert.ok(unusable.stderr.includes(`is gone and node on PATH is missing; needs Node ${floor} or newer`), unusable.stderr);

    // F006: the installer-resolved env-file path is baked into the launch args (project .env here).
    const envFlag = entry.args.indexOf("--as-env-file");
    assert.notEqual(envFlag, -1, "the resolved env-file path is baked into the launch args");
    const bakedEnvPath = entry.args[envFlag + 1];
    assert.equal(bakedEnvPath, path.join(dest, ".env"), "baked path is the installer-resolved project .env");
    // P1: the real command after "--" is the provisioning-resolved ABSOLUTE openosint-mcp path (not the
    // bare name), so the wrapper finds it even when its install dir is not on the launch PATH.
    const innerCommand = entry.args[entry.args.indexOf("--") + 1];
    assert.ok(path.isAbsolute(innerCommand) && path.basename(innerCommand) === "openosint-mcp", `real command after -- is the resolved absolute openosint-mcp path, got: ${innerCommand}`);

    // Env-delivery DIAGNOSTIC: seed the baked env-file, then run the ACTUAL generated command with the
    // config's own args (only the real MCP binary after `--` swapped for a probe), from a DIFFERENT cwd
    // under a restricted PATH. The probe must receive the installer-collected value.
    writeFileSync(bakedEnvPath, "SHODAN_API_KEY=installer-collected\n", { mode: 0o600 });
    const probe = path.join(dir, "probe.sh");
    writeFileSync(probe, "#!/bin/sh\nprintf 'SHODAN_API_KEY=%s' \"$SHODAN_API_KEY\"\n", { mode: 0o755 });
    const launchArgs = entry.args.slice(0, entry.args.indexOf("--") + 1).concat([probe]);
    const launch = spawnSync(entry.command, launchArgs, { encoding: "utf8", cwd: dir, env: { PATH: "/usr/bin:/bin", HOME: home } });
    assert.equal(launch.status, 0, `launch failed: ${launch.stderr}`);
    assert.equal(launch.stdout, "SHODAN_API_KEY=installer-collected", "installer-collected credential reaches the launched process under minimal PATH from another cwd");

    // ---- custom --credentials-file is honored and baked verbatim (F006) --------
    // (--env-file would be swallowed by Node's own bootstrap flag; the CLI uses --credentials-file.)
    const customDest = path.join(dir, "custom");
    const customFile = path.join(customDest, "secrets.env");
    const custom = install(home, customDest, ["--service", "openosint", "--credentials-file", customFile]);
    assert.equal(custom.status, 0, `custom install failed: ${custom.stderr || custom.stdout}`);
    const customEntry = JSON.parse(readFileSync(path.join(customDest, ".factory", "mcp.json"), "utf8")).mcpServers.openosint;
    assert.equal(customEntry.args[customEntry.args.indexOf("--as-env-file") + 1], customFile, "a custom --credentials-file path is baked in verbatim");

    // Kilo builds its config through its own merge, which must receive the same credential file.
    const kiloDest = path.join(dir, "kilo");
    const kiloFile = path.join(kiloDest, "secrets.env");
    const kilo = install(home, kiloDest, ["--service", "openosint", "--credentials-file", kiloFile], "kilo");
    assert.equal(kilo.status, 0, `kilo install failed: ${kilo.stderr || kilo.stdout}`);
    const kiloCommand = JSON.parse(readFileSync(path.join(kiloDest, "kilo.jsonc"), "utf8")).mcp.openosint.command;
    assert.equal(kiloCommand[kiloCommand.indexOf("--as-env-file") + 1], kiloFile, "kilo bakes in the custom --credentials-file path");
  }

  // ---- keyless server: direct launch preserved, no wrapper materialized -------
  const keylessHome = path.join(dir, "keyless-home");
  seedBin(keylessHome, "synapse-bridge");
  seedBin(keylessHome, "synapse-hook");
  const provisionable = await serviceIsProvisionable("synapse", keylessHome);
  if (!provisionable.ok) {
    console.log(`mcp-credential-launch: synapse prerequisite unavailable here (${provisionable.unmet.join(", ")}) — skipping the keyless install case`);
  } else {
    const keylessDest = path.join(dir, "keyless");
    const keyless = install(keylessHome, keylessDest, ["--service", "synapse"]);
    assert.equal(keyless.status, 0, `keyless install failed: ${keyless.stderr || keyless.stdout}`);
    const keylessConfig = JSON.parse(readFileSync(path.join(keylessDest, ".factory", "mcp.json"), "utf8"));
    assert.equal(
      keylessConfig.mcpServers.synapse.command,
      path.join(keylessHome, ".local", "bin", "synapse-bridge"),
      "keyless synapse keeps its direct launch command",
    );
    assert.ok(!existsSync(path.join(keylessHome, ".local", "bin", "agent-surface-mcp-env")), "a keyless install never materializes the wrapper");
    // Windows wraps the first-party .cmd launchers as well, so only POSIX leaves the copy unwritten.
    if (process.platform !== "win32") assert.ok(!existsSync(mcpLaunchScriptCopy(keylessHome)), "a keyless install writes no launcher copy");
  }
} finally {
  rmSync(dir, { recursive: true, force: true });
}

console.log("mcp-credential-launch: ok");
