# Concept Zero: Runtime Identity and Compatibility Refresh

Status: IMPLEMENTED; facts below are dated to their baseline, and docs/roadmap.md records what shipped
Last updated: 2026-09-28
Baseline: `main` at `3dbdbfe9c67fa7a95cf72a25280d2aa588782956`

Scope note: the runtime-refresh sections retain their dated baseline. The separate [agent-reuse amendment](#agent-reuse-capability-amendment) below was researched on 2026-10-12 and accepted for a bounded experiment on 2026-10-13; one supervised route has now been observed. It does not reopen runtime-refresh or computer-use work.

## Executive Decision

Keep agent-surface as a canonical-practice compiler, native-adapter catalog and managed installer. This batch makes runtime identity, security-aware release selection, lifecycle and proof boundaries explicit; repairs demonstrated path/format defects; separates different harnesses hidden behind one editor brand; and adds a controlled successor path for Antigravity workflows. Retain OpenHands V1 CLI, but recommend it only for existing users. Expand Grok Build only where native contracts and task evidence justify it; evaluate Grok Bot as a separate private workplace pilot. Do not build a runtime manager, vulnerability scanner, provider router, scheduler, saved-profile engine, or universal permissions layer.

The previous [concept](https://github.com/Lyther/agent-surface/blob/3dbdbfe9c67fa7a95cf72a25280d2aa588782956/docs/context/concept-zero.md) and [roadmap](https://github.com/Lyther/agent-surface/blob/3dbdbfe9c67fa7a95cf72a25280d2aa588782956/docs/roadmap.md) are historical. Their completed work is not reopened, and their old version/target counts are not the baseline for this batch. The current source has 26 implemented outputs: 25 runtime/host adapters plus the build-only plugin exporter.

## Problem and Evidence

Users can receive syntactically valid assets that the selected harness never loads. Editor branding now spans native, CLI-backed, hosted and compatibility modes; a populated home can mask missing native output. Release channels also say little about whether a specific vulnerability is fixed. The required outcome is a precise, usable integration, not a larger catalog or an unqualified compatibility score.

| ID | Claim or decision | Evidence | Confidence / impact |
|---|---|---|---|
| `E-RT-01` | FACT: existing support/generation fields already separate some concerns, but lack component-specific qualification. | `registry/target-capabilities.json`; `schemas/target-capabilities.schema.json` | High source confidence; extend rather than replace these records. |
| `E-RT-02` | USER_DECISION: security-required newer public or preview releases may take precedence over a named stable channel. DSH is urgent. | Operator correction, 2026-09-28; advisory reconciliation in [research](concept-zero-research.md) | Policy accepted; exact affected/fixed versions and exploitation claims require attributable evidence. |
| `E-RT-03` | FACT: Cascade and Devin Local do not share all customization behavior. | [Devin Local](https://docs.devin.ai/desktop/devin-local), [Cascade rules](https://docs.devin.ai/desktop/cascade/memories) | Separate the harness contract; do not infer parity from the same desktop shell. |
| `E-RT-04` | FACT: actual user/general Cascade output is 9,539 characters; current documented global limit is 6,000. Development is 30,348 against 6,000 global / 12,000 per workspace file. | `rules.mjs`, `targets.mjs`; [native limits](https://docs.devin.ai/desktop/cascade/memories) | Source/render evidence, not observed truncation. Global and project limits differ; oversized selected output blocks. |
| `E-RT-05` | FACT: Antigravity workflows stop working on October 19, 2026 (rechecked 2026-10-14). USER_DECISION: warn and support the successor. | [Official migration](https://antigravity.google/docs/migration/workflows-to-skills/) | Time-bound surface migration; not product retirement. |
| `E-RT-06` | FACT: OpenHands V1 CLI is no longer actively maintained. USER_DECISION: keep it, reduce recommendation. | [Upstream status](https://github.com/OpenHands/OpenHands-CLI/commit/954f2ba646e8d749261a8f2b2b7e3031fa39be9f) | Retained compatibility target, not automatic Canvas/SDK substitution. |
| `E-RT-07` | FACT: Poolside personal instructions use AGENTS.md; current producer uses .poolside. Zed and Trae claims need platform/edition boundaries. | `roots.mjs`; [Poolside](https://docs.poolside.ai/agent-instructions), [Zed](https://zed.dev/docs/ai/instructions), [Trae CN](https://docs.trae.cn/cli_skills) | Bounded mapping repairs, not a global root resolver redesign. |
| `E-RT-08` | FACT: Grok Build has custom-agent types; our generated subset omits them. Grok Bot has a distinct persistent workspace. | [Build agents](https://docs.x.ai/build/features/subagents), [Bot computer](https://docs.x.ai/grok-bot/computer-and-apps) | Native expansion and private pilot are different deliverables. |
| `E-RT-09` | FACT: the installer reads ownership only from the target's own manifest. A differing unowned file is overwritten and an identical one adopted; a rules-only install can replace a shared `AGENTS.md` carrying another target's development rules; one target's reset can delete shared command skills another target still claims. Shared config merging preserves unknown sibling keys, which is a different contract. | `install.mjs` action selection, category guard and stale cleanup versus `merge.mjs`; reproduced with disposable roots during review | Installer-wide ownership protection precedes new path migrations; do not claim existing overwrite protection. |

Evidence dates and unresolved external details belong in [concept-zero-research.md](concept-zero-research.md). Native behavior not exercised during this design remains unqualified. No vulnerability reproduction, credentials, provider calls, runtime installation or GUI operation is needed to define the design.

## Users and Stakeholders

- Operator: distribute selected practices to actual used harnesses without unexpected services, account changes or lost user content.
- Maintainer: repair a target independently, select a security-appropriate release, and state what is proven without maintaining competing catalogs.
- Skill author: keep one canonical procedure and companions; do not fork prose by vendor or weaken explicit-only commands.
- Implementation peer: receive file ownership, decision gates, migration behavior and observable acceptance criteria before coding.
- Native runtime/MOMO owner: retain responsibility for client installation, accounts, environment selection and deployment. Runtime upgrades are an urgent separate operation when a confirmed advisory requires them.

## Goals, Non-Goals, and Constraints

- `G-RT-01` Security-aware release selection. Distinguish channel, version, known fixed range, and actual qualification; do not retain a vulnerable version merely because it is labelled stable.
- `G-RT-02` Unambiguous runtime identity. Identify product, executing harness, surface, scope and platform; separate selectors when different harnesses require different producers.
- `G-RT-03` Timely Antigravity migration. Display the retirement notice now and qualify the supported replacement before October 19 without implicit execution of manual commands in a clean profile. Other targets' manual-only skill copies in a shared workspace are listed as warnings; whether Antigravity loads them is recorded evidence, not part of this guarantee.
- `G-RT-04` Preserve OpenHands compatibility. Keep build/install/selection and owned assets while lowering its recommendation; no retirement cleanup or Canvas relabeling.
- `G-RT-05` Correct demonstrated mapping defects. Repair Poolside and scoped host/edition/path claims while protecting new destinations and existing unrelated configuration.
- `G-RT-06` Evidence-backed qualification. Keep upstream support, generated output, discovery, task behavior and enforcement claims distinguishable.
- `G-RT-07` Selective next-generation integration. Qualify Grok Build native roles and define a private Grok Bot pilot; admit other runtimes only for a concrete distinct workflow.
- `C-RT-01` Preserve the Node/Ajv compiler, existing format libraries, canonical sources, categories, managed manifests, service-selection semantics and operator execution policy.
- `C-RT-02` Keep design and implementation separate. This change writes design artifacts only; implementation, local commits, publication and deployment retain their own scopes.
- `C-RT-03` Keep regular build/install offline with respect to client release/advisory discovery. Do not execute a potentially affected client just to ask its version.
- `N-RT-01` No automatic client upgrades, account migration, cloud connector enrollment, vulnerability feed service, new persistent store, generic policy engine or orchestration runtime.
- `N-RT-02` No saved-profile reconciliation engine or category-union redesign. Plans become clearer; existing general-reset and partial-install semantics remain.

## Unacceptable Outcomes

- Calling an older named-stable release safe without checking the reported advisory, or calling a latest release fixed without an affected/fixed-range source.
- Representing Cascade and Devin Local as one proven harness because their files or shell overlap.
- Silently truncating rules, moving mandatory global policy into on-demand references, or describing project rules as global protection.
- Continuing to advertise a retired workflow format as current, or migrating a manual command into an automatically invoked skill.
- Removing OpenHands from selection or erasing its managed files merely because recommendation decreases.
- Overwriting or adopting an operator-owned file, silently erasing another target's category contribution, deleting a file another target still claims, or purging an old route before successor proof and a selected migration.
- Treating a provider login, model response, copied file, or historical peer claim as current native acceptance.

## Glossary

**Target** is a stable compiler selector and manifest owner. **Component/harness** is the actual consumer of an asset, not necessarily the editor brand. **Surface** is a native facility such as skills, commands or instructions. **Lifecycle** is upstream active/preview/legacy state; **recommendation** is our advice, separate from implemented status. **Qualification** is dated evidence for one version, component, platform, scope and scenario. **Release selection** chooses a concrete client build; it is not client installation. **Migration** changes owned paths/formats under a previewed operation; it is not a license to modify foreign settings.

## Critical Journeys and Quality Scenarios

- `Q-RT-01` A reported critical runtime issue arrives: before the next affected execution, the runtime owner identifies the exact product and advisory, checks affected/fixed ranges, and records either a verified fixed build or an unresolved hold. Neither a channel name nor a public PoC is substituted for exploitation evidence.
- `Q-RT-02` An operator selects a harness: the plan names the actual component and scope; a fresh profile discovers only the intended generated assets. A co-installed profile tests fallback and precedence rather than masking an omission.
- `Q-RT-03` An Antigravity workflow user previews an install: the dated notice is visible before writes. The replacement supports explicit invocation and companion access; the first successor release retains old owned workflow files, and archiving them is outside this batch ([contract](../contracts/runtime-refresh.md#antigravity)).
- `Q-RT-04` A destination already contains unowned content: the selected target reports a conflict before any write, with a recoverable operator action. A shared generated file that carries another target's category contribution is regenerated for the requested selection with a visible warning naming what was dropped, and cleanup never deletes a file another target still claims. Repeat installation after a resolved migration is idempotent.
- `Q-RT-05` An OpenHands user selects it directly or through all targets: support and ownership stay unchanged, a legacy recommendation is shown, and no first-party MCP selection changes.
- `Q-RT-06` A known rule-size limit is exceeded: the affected output cannot be presented as full native policy. The plan names the limit and a supported alternative or blocker; no automatic summarization or truncation occurs.
- `Q-RT-07` A cloud Bot pilot runs: only selected non-sensitive artifacts enter the workspace; shared account access is understood; the resulting artifact and cancellation/routine lifecycle are observed. No local-device or security-isolation claim follows from a cloud result.

## Research Landscape and Adopt/Adapt/Build

- **Adopt native Agent Skills and plugin managers where their consumed contract is proven.** They reduce custom packaging, but frontmatter portability does not establish identical invocation or tool restrictions. [Agent Skills specification](https://agentskills.io/specification).
- **Adapt existing producers, registries and format libraries.** These already own source loading, output syntax and shared-config merges. No new dependency is selected in this design.
- **Use native runtime release/advisory sources and external lifecycle owners.** A manually reviewed security choice is sufficient for this batch; building a second package updater or CVE database is not.
- **Retain Grimoire/Synapse boundaries.** Retrieval and durable runtime memory are not part of a target-identity migration. No MCP protocol, database or service implementation change is proposed.
- **Pilot persistent workplace products separately.** Grok Bot and similar systems can support long-lived work, but have cloud/account state and import contracts unlike local filesystem adapters. No provider or cost advantage is assumed.

## Candidate Concepts

### A. Documentation-only refresh

Correct descriptions and recommend current releases without changing native output. Cheapest, but Poolside's wrong filename, oversized Cascade rules and the Antigravity retirement remain user-visible failures. Rejected as the complete batch; metadata is still a useful first vertical slice.

### B. Identity-explicit adapters with bounded migrations

Retain the compiler, add small lifecycle/qualification metadata, expose selected-target notices, repair demonstrated paths, and separate real harness contracts. Use native managers and existing manifests; add only the checks required by each migration. Selected: it solves the concrete failures without owning runtime operation.

### C. Universal runtime/profile manager

Own client updates, vulnerability feeds, provider accounts, profile reconciliation and cloud jobs. This could centralize more operations but duplicates runtime/MOMO responsibilities, adds persistent state and converts a compiler refresh into a control plane. Rejected. Shared portable skills alone are also insufficient because they cannot replace native policy, commands and MCP configuration.

## Selected Concept HLD

Canonical sources and pinned external packs feed the existing short-lived Node compiler. The target registry remains the selector/build/install authority; capabilities carry component identity, lifecycle advice and bounded evidence. Pure adapters render supported native files; the installer previews writes, notices, conflicts and removals before applying managed output and named config merges. No new deployment unit or stateful service is introduced.

Security release decisions sit before runtime qualification and deployment, not inside skill compilation. Prefer a verified fixed current release over an affected stable channel, including a supported preview build when that is the available fixed line. Keep its preview label and separate task proof. An unverified advisory report is escalated promptly without inventing an affected range.

Existing target IDs do not silently change harness meaning. Retain `windsurf` for deprecated Cascade compatibility, and exclude explicitly deprecated targets from `all` in a deliberate selector change while retaining explicit selection. Devin gets no target of its own: `RT0.2` showed Devin CLI listing the other targets' output through its default imports (revised 2026-10-08). This does not exclude OpenHands: it remains implemented with a legacy recommendation only. Antigravity's successor candidate is native `trigger: manual` rules, not an automatically invoked skill or a guessed flag. Exact producer changes and migration rules follow in architecture/contracts; absent native evidence is a named spike, not speculative code.

## First Production Slice

The first implementation slice is metadata and visible notices, followed by installer ownership protection as a separate patch and then the Poolside route repair. Together they prove the existing entry point can describe the correct component/lifecycle without altering unrelated generated bytes, and that installs and a real owned-path migration preserve unowned and other-owner content. They do not wait for GUI or cloud work. The operator runs the Antigravity GUI qualification in parallel. The urgent DSH upgrade is done; its native requalification is deferred. Antigravity's warning does not wait for its successor acceptance.

## Open Questions and Handoff

Native file/schema and effective-invocation unknowns are bounded implementation prerequisites, not product decisions to guess. The research ledger identifies their sources and the roadmap assigns them. DSH's critical advisory and Cascade's removal from current Desktop are now source-verified, and the installed DSH was upgraded past the affected range. Still required: qualify native Devin roots; prove Antigravity manual-only behavior; verify Grok native role schema and restrictions; keep Grok Bot import/account qualification separate; and requalify DSH natively in a later batch.

`arch-roadmap` carries every `G-RT`/`Q-RT` requirement into a scoped step with files and evidence. `arch-contract` defines the metadata, notice and migration boundaries using existing schemas and installer ownership, with no new transport or database. The implementation peer starts with `dev-spec` for the first bounded slice, not a whole-portfolio rewrite.

## Agent-Reuse Capability Amendment

Status: ACCEPTED FOR BOUNDED EXPERIMENT, 2026-10-13; MOMO has accepted the development-host handoff for its supervised comparison. The initial source review used agent-surface `886f237` and MOMO `779f35a`; subsequent [native execution evidence](concept-zero-research.md#agent-reuse-native-spike-2026-10-13) qualifies one supervised MCP route, not comparative capability. Derived work: [architecture](../architecture.md#agent-reuse-capability-trial), [roadmap](../roadmap.md#phase-as-ar-agent-reuse-capability-trial), [contract](../contracts/agent-reuse.md).

### Problem and Selected Direction

MOMO needs more independently verified target coverage, not more registered tools. Recalculation of its retained Juice Shop metrics confirms that the original five included runs solved a union of 22/59 scoped challenges, leaving 37 common misses. This union is not an ensemble result. A later Kilo run reached 50/59, but source, Global model and budget changed; a subsequent Kilo run reached 21/59. These observations justify investigating execution and methodology, not declaring a model ceiling or promising an integration gain.

Select a bounded **whole-agent trial through one existing native harness**, provisionally using **GH05TCREW/PentestAgent** at `87d763a9c830597e9b8c1d56293300f6961beec2`. Record whether the selected strategy uses its MCP loop or standalone CLI/playbook; use the same mode in corresponding comparison arms. The first functional proof used MCP, without mandating that interface for later strategy selection. This is a different application from the already registered **0xSteph/Pentest-AI** (`pentest-ai`), whose MCP tools use the parent's reasoning. Keep both identities explicit.

Agent-surface prepares the separate upstream environment and one native launch configuration; MOMO owns its optional application row, delegation guidance, existing Evidence retention and matched evaluation. Operators receive a report and actual accessible artifacts through the enclosing Task. No new runtime framework, provider router, scheduler, delegate database, universal wrapper or computer-use integration is selected.

### Requirements and Quality Scenarios

- `G-AR-01` Capability: evaluate additional solved challenge IDs, overlap, elapsed time and available total usage. A successful handshake or a delegate's self-reported success does not satisfy this goal.
- `G-AR-02` Native reuse: keep the candidate's loop upstream and use one maintained harness's real MCP client or existing native command execution. Agent-surface owns configuration delivery, not the delegate's execution state; MOMO keeps its current Task/Evidence/result owners.
- `G-AR-03` Bounded operation: prove provider tool calling, artifact access, errors and cancellation before unattended adoption. Source inspection already shows that cancellation acknowledgement and terminal status are insufficient evidence.
- `C-AR-01` Preserve the operator's provider/model choices, existing categories and deployment profile. Use an approved Ollama Cloud route; no premium-model substitution, automatic retry with another provider, all-target distribution or global MCP addition.
- `C-AR-02` Keep the first trial to one delegate task at a time in a dedicated working directory and disposable development execution boundary. A Python environment isolates dependencies, not shell authority. No production machine or unrelated host credentials are needed.
- `N-AR-01` Do not import an upstream control plane into MOMO, rebuild orchestration, add persistent task storage, change Synapse/Grimoire, or start the separate computer-use workstream.
- `Q-AR-01` An explicitly scoped task is submitted through the native host, performs a real harmless operation and returns an inspectable artifact. Observe the actual tool invocation, content and filesystem result; model narration alone fails the scenario.
- `Q-AR-02` A task is cancelled while work is outstanding, or its parent is interrupted: measure what actually stops, what remains and the stop latency within a predeclared deadline. No false completion, automatic resubmission or unobserved continuing subprocess is accepted as cancellation proof.
- `Q-AR-03` Fresh target state and fixed scoring produce a matched comparison: baseline, delegate A, methodology B, then A+B. Keep the parent's normal task-authorized native tools, runtime/model settings and target-facing environment equivalent across arms; the restricted smoke profile is not a benchmark baseline. Include delegate work in the total allowance, preserve failed runs and distinguish solved flags from verified Findings. Unknown consumption remains unknown.
- `Q-AR-04` A later explicit single-service install preserves unrelated host configuration and the default profile. No category installation begins selecting this delegate as a side effect.

### Alternatives and Decision Boundary

**Native tools or methodology alone** are the simplest alternative. Existing Pentest-AI and the installed security corpus may address a gap without an inner agent. At the operator's direction, prepare one separately selectable methodology asset alongside the delegate spike. Trace review remains useful for choosing and interpreting the measured task; it does not block preparation. Keep baseline versus delegate first, then add methodology-only and combined arms without conflating their effects.

**Native MCP delegation** is selected provisionally because GH05TCREW exposes submission, status and result operations without requiring MOMO to implement its loop. However, its current cancellation only marks state, its local command timeout does not terminate the child process, and provider errors can end with task status `done`. The first spike must establish an effective stop path or a narrowly scoped upstream repair. The candidate is not approved for unattended registration merely because these methods exist.

**Embedding a new agent framework** is rejected. If GH05TCREW needs a new process manager, durable task service or substantial adapter, compare Decepticon's existing engagement MCP and Strix's native headless/scan path instead. Neither alternative is performance- or cancellation-qualified by this research. Changing candidates is preferable to constructing infrastructure around a weak fit.

### First Useful Slice and Revisit Triggers

Start outside the distributed registry: one development environment, one approved model, one native harness and one harmless complete task, with retrieval before process shutdown. Disable optional RAG and external MCP chaining for this first route. Establish provider compatibility and actual output ownership, then exercise cancellation and failure. Those optional features can be a later measured variant; their absence must remain part of the trial identity.

Functional proof permits a bounded MOMO experiment; only demonstrated value justifies wider deployment. The next slice is one real MOMO Task retaining delegate results/artifacts, then baseline versus A through MOMO's existing scorer; B and A+B follow independently. Reuse the accepted development-host preparation rather than repeat the spike or expand candidate research. Measure additional coverage, stronger validation, time and repeatability rather than rejecting overlap by itself. Preserve methodology provenance and notices, and avoid attributing a gain to it before its separate comparison. A working but non-additive delegate can remain an operator tool without becoming part of MOMO's routine path.

Open evidence after the first spike: target-facing effectiveness, native-parent/MOMO interruption propagation, provider-side cancellation and methodology benefit. One MCP/provider/artifact route and a supervised environment stop are now observed; see the [runbook](../runbooks/pentestagent.md). Existing resource authorization remains valid; this design creates no new approval system.

## Grimoire Effectiveness Amendment

Status: retrieval defect FIXED, measured, and confirmed held-out; task ROI UNPROVEN, 2026-10-16. This amendment does not replace the dated runtime-refresh or agent-reuse designs. Priority is Grimoire, then category ROI, with Synapse lower; computer use is deferred and the operator owns Antigravity/manual qualification.

**Problem.** An agent could hold a relevant skill and still not retrieve it, because ordinary task wording adds a word the skill's text lacks. Real MCP calls over the five-pack corpus reproduced it, and the regression floor still passed, so this was an effectiveness limit rather than a new regression. Search latency was never the problem.

- `G-GR-01`: Retrieve useful skills for real task descriptions without making unrelated or unsafe material look authoritative. Judge multiple relevant answers, not one expected ID.
- `G-GR-02`: Establish whether skill access improves independently verified task outcomes under matched resources. Availability, loading, use and contribution are separate observations.
- `C-GR-01`: Keep the local read-only SQLite/MCP boundary, source pins, provenance, four tools and default profile. Experiments use an approved isolated environment; no production index mutation.
- `N-GR-01`: No retrieval service, embedding store, universal router, category redesign or blanket prompt compression before evidence justifies it. Do not reopen computer use or the separately owned security-agent comparison.

**Resolution.** Matching any query word and letting weighted BM25 order the candidates was the smallest change that addressed the measured cause. Caller-side concise-query or retry guidance was not selected for this fix and its comparative benefit is untested: the existing keyword guidance did not prevent the observed misses, which does not show that stronger guidance cannot help. Dense or hybrid retrieval and reranking remain later research options, not the automatic next step after a lexical miss — [BEIR](https://arxiv.org/abs/2104.08663) is a reason to compare retrieval methods, not evidence that one helps this corpus. The accepted cost is that an uncovered query returns its nearest matches instead of nothing.

Held-out multi-pack relevance then confirmed the fix on 52 new requests with graded alternatives and no-skill controls, and two caller models abstained on every uncovered request. Remaining: an actual native task and verifier. A null or mixed task result is allowed to leave the design unchanged. [Architecture](../architecture.md#grimoire-effectiveness-experiment), [roadmap](../roadmap.md#phase-gr-grimoire-and-asset-effectiveness), [contract](../contracts/grimoire-evaluation.md) and [diagram](../diagrams/grimoire-evaluation.svg) own that work. No task-outcome improvement is claimed here.
