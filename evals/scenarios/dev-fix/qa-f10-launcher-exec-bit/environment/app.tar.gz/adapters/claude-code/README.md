# Claude Code adapter

Canonical skills are emitted unchanged to Claude Code. Available high-impact commands use the same skill surface with `disable-model-invocation: true`; always-on rules become one document that `CLAUDE.md` imports; normalized subagents use Claude Code subagent files.

Implemented target paths:

- user: `~/.claude/skills/<name>/SKILL.md`
- project: `.claude/skills/<name>/SKILL.md`
- user: `~/.claude/agent-surface/rules.md`, scoped rules under `~/.claude/agent-surface/references/rules/`
- project: `.claude/agent-surface/rules.md`, scoped rules under `.claude/agent-surface/references/rules/`
- user: `~/.claude/agents/<name>.md`
- project: `.claude/agents/<name>.md`
- user merge: `~/.claude.json` `mcpServers.{synapse,grimoire}`
- project merge: `.mcp.json` `mcpServers.{synapse,grimoire}`

Claude Code loads the rules document through an import: add `@agent-surface/rules.md` to `.claude/CLAUDE.md` (`~/.claude/CLAUDE.md` for a user install) once; the install plan prints `CLAUDE_RULES_IMPORT_MISSING` until it is there. `CLAUDE.md` stays yours: agent-surface never writes it. The rules stay out of `.claude/rules`, which VS Code also applies to every request, so a co-installed vscode target does not attach them twice.

Claude Code connects a project's `.mcp.json` servers only after the user approves them: on 2.1.292, `claude mcp list` showed the generated project entries as `Pending approval`, and connected Synapse and Grimoire once approved, while user-scope entries connected directly.

Canonical skills may be selected automatically or invoked as `/<name>`. Manual commands remain user-invocable but cannot be selected by the model.

The current subagent batch emits `subagents/{explorer,researcher,reviewer,verifier,worker}.md` to `.claude/agents/*.md`. The files set no `model`, so Claude Code picks one by its [subagent model order](https://code.claude.com/docs/en/sub-agents#choose-a-model): a model passed in the call, then `CLAUDE_CODE_SUBAGENT_MODEL`, then the main conversation's model. A `model` line, even `model: inherit`, would outrank `CLAUDE_CODE_SUBAGENT_MODEL`. They set no `permissionMode` either, so each agent [inherits the session's permission mode](https://code.claude.com/docs/en/sub-agents#permission-modes), and no `tools`, so each [inherits every tool the session offers](https://code.claude.com/docs/en/sub-agents#available-tools), MCP tools included. First-party MCP wiring (Synapse and Grimoire) is generated and safely merged; external or secret-bearing MCPs remain opt-in.

External skill packs render only when the optional-service entry declares `skill_roots`. `anthropic-cybersecurity-skills` is kept as a pinned source asset but is not emitted into Claude Code skill roots by default.
