# Goose Adapter

Generates native Agent Skills for safe reusable procedures. Available high-impact manual commands become Goose recipes in project scope and explicit-invocation compatibility skills in user scope, so recipes are never written directly into `$HOME`.

## Outputs

- `~/.agents/skills/<name>/SKILL.md` or `.agents/skills/<name>/SKILL.md`
- reviewed external packs under the same native skill root
- `.goose/recipes/<command>.yaml` in a project, where Goose finds a recipe by name. Goose 1.34.1 and 1.55.0 list and validate them there; neither looks in the bare `recipes/` directory that earlier installs wrote, which a development or full reinstall prunes.

## Notes

- Goose recipes are project-oriented in this adapter. Use `--dest` for installs into a recipe directory.

## First-party MCP (generated)

Goose configures MCP as YAML `extensions` (`type: stdio`) in the user-global `config.yaml`: `~/.config/goose/config.yaml` on macOS and Linux and `Block\goose\config\config.yaml` in the roaming AppData directory on Windows (`%APPDATA%` by default), resolved from the profile home; a redirected `%APPDATA%` is not followed. On macOS and Linux, Goose reads `$XDG_CONFIG_HOME/goose/config.yaml` instead when `XDG_CONFIG_HOME` is set (observed with goose 1.34.1 `goose info` on macOS); agent-surface does not follow it, because the client's environment is not known at install time, and a plan made while `XDG_CONFIG_HOME` names another directory carries the `GOOSE_XDG_CONFIG_HOME_SET` notice. The Windows route is not natively qualified; Windows installs made before it merged into `~/.config/goose/config.yaml`, which Windows Goose never reads, and the next full install prunes its servers there. agent-surface generates and **non-destructively merges** Synapse + Grimoire there on a user-scope install (`install --target goose --scope user --category mcps --allow-scope-root`): existing keys, comments, and your other extensions are preserved; re-running is a no-op. External or secret-bearing MCPs remain opt-in. Missing first-party binaries are built and linked through the registry recipe before any config is written. The merged block looks like:

```yaml
extensions:
  grimoire:
    name: grimoire
    type: stdio
    cmd: ~/.local/bin/grimoire-server
    args: []
    enabled: true
    timeout: 300
  synapse:
    name: synapse
    type: stdio
    cmd: ~/.local/bin/synapse-bridge
    args: []
    enabled: true
    timeout: 300
```
