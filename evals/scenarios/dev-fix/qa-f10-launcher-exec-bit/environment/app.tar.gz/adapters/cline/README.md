# Cline adapter

The adapter maps agent-surface sources onto Cline's current file-backed configuration surfaces.

Last runtime probe: Cline CLI `3.0.46` on 2026-07-25. With auto-approval and its configured OpenRouter provider, the CLI called both first-party MCPs and returned the required exact result. Running Cursor extension hosts reloaded both MCP registrations from their global-storage route, but an extension-originated tool call was not run.

## Generated paths

User scope:

- canonical skills: `~/.cline/skills/<name>/SKILL.md`
- manual workflows: `~/Documents/Cline/Workflows/*.md`
- rules: `~/Documents/Cline/Rules/agent-surface.md`
- scoped rule references: `~/Documents/Cline/Rules/references/rules/<rule>.md`
- configured agents: `~/.cline/agents/*.yaml`
- external Agent Skills: `~/.cline/skills/<skill>/...`
- MCP (CLI): `~/.cline/data/settings/cline_mcp_settings.json`
- MCP (VS Code, Cursor, Windsurf and Devin Desktop extensions): the Cline extension's `globalStorage/.../settings/cline_mcp_settings.json` in each IDE where Cline is present

Project scope:

- canonical skills: `.cline/skills/<name>/SKILL.md`
- manual workflows: `.clinerules/workflows/*.md`
- rules: `.clinerules/agent-surface.md`
- scoped rule references: `.clinerules/references/rules/<rule>.md`
- configured agents: `.cline/agents/*.yaml`
- external Agent Skills: `.cline/skills/<skill>/...`
- ignore policy: `.clineignore`

`--dest` relocates the selected scope's relative paths under the reviewed destination.

## Runtime contracts

Safe reusable procedures are native Agent Skills and can be selected through Cline's skill tool. Only available high-impact commands remain workflows; invoke those by stem and do not add the `.md` suffix.

`registry/targets.json` records normalized render classes, not Cline product labels. The Cline mappings are:

| Render token | agent-surface input | Cline output |
|---|---|---|
| `skills` | `skills/*/SKILL.md` | Agent Skill directories |
| `commands-as-workflows` | `commands/*.md` | workflow Markdown |
| `rules` | `rules/*.mdc` | bundled rules and scoped references |
| `subagents` | `subagents/*.md` | Configured Agent YAML |
| `ignores` | `ignores/*` | `.clineignore` |
| `external` | pinned external skill packs | Agent Skill directories |
| `mcps` | registry-backed MCP services | shared MCP settings |

The repository therefore does have a `subagents` source primitive. For Cline, that primitive compiles to Configured Agents in `.cline/agents/*.yaml`. Cline Configured Agents contain `name`, `description`, an optional tool allowlist, and a non-empty prompt body. The generated agents list no tools, so Cline gives each every built-in tool.

Configured Agents are distinct from Cline's built-in `spawn_agent` delegation and persistent agent teams. `spawn_agent` is runtime behavior and needs no generated definition file; agent-team state is created and owned by Cline at runtime.

The bundled rule file contains only always-on rules. Cline's rule loader reads direct files from each rules root and does not recursively activate `references/rules/`; scoped policies remain reference-only until a matching project workflow attaches them.

MCP is user-global but not stored in one shared file. Only the CLI and Cline's SDK-based extension (the Next bundle, rolling out from 4.1.0) read `~/.cline/data/settings/cline_mcp_settings.json`; the pre-SDK extension that 3.x and most 4.x installs run reads `settings/cline_mcp_settings.json` under its IDE's `globalStorage`. The installer non-destructively merges Synapse and Grimoire into the shared route and into each per-IDE route whose IDE has Cline present. Cline counts as present when `~/.vscode/extensions`, `~/.cursor/extensions`, `~/.windsurf/extensions` or `~/.devin/extensions` holds a `saoudrizwan.claude-dev-<version>` folder. Extension storage is not a signal, because IDEs keep it after an uninstall, and Cline in a custom extensions directory is not detected. Plans list skipped per-IDE routes with the reason, a full install prunes servers agent-surface merged into a route whose IDE has no Cline, and an unreadable extensions folder blocks the plan. An explicit `--dest` install checks only its destination. Devin Desktop, the renamed Windsurf, has its own route under its `Devin` user-data folder, live when `~/.devin/extensions` holds Cline ([Devin Desktop FAQ](https://docs.devin.ai/desktop/devin-desktop-faq)). Devin creates that folder on its first run, so the route does not create Devin's user data ahead of Devin's migration from Windsurf, which a Devin data folder would skip, unless that folder was populated before Devin first ran. Devin also loads extensions from the read-only legacy `~/.windsurf/extensions`, but Cline found only there gets no Devin route; install Cline in Devin to get one. Once Devin's user-data folder exists Devin reads it rather than Windsurf's, so the Windsurf route serves Windsurf builds that were not renamed. Scope-derived Windows installs honor `%APPDATA%`; explicit `--dest` installs relocate the conventional `AppData/Roaming` subtree. None of the current loaders use the older `.cline/mcp.json` route. External or secret-bearing MCP services remain opt-in.

The CLI and the SDK-based extension read `~/Documents/Cline/Workflows` and `~/Documents/Cline/Rules`. The pre-SDK extension reads the same folders under the OS Documents folder: PowerShell's `MyDocuments` on Windows, which follows a OneDrive backup, `xdg-user-dir DOCUMENTS` on Linux, and `~/Documents` on macOS or when the query fails (Cline 3.86.2 and 4.1.24 bundles). When that folder is elsewhere in the home, user installs write the workflows and rules to both places. The SDK bundle also scans `~/Cline/Rules` and each OneDrive account's `Documents/Cline/Rules`, so rules under the home itself (the `xdg-user-dir` answer when no `DOCUMENTS` entry is configured) or under a OneDrive Documents folder go only there and do not load twice. A Documents folder outside the home gets a `DOCUMENTS_OUTSIDE_HOME` warning and no copy. When the folder moves between installs, each relocated file keeps its category: a narrower selection that would overwrite a development rules document at its new place is refused, and the old copy is retired once its replacement is written. Project workflows retain the supported `.clinerules/workflows` compatibility route. Runtime-audit workflows must use another runtime as the driver; recursively starting Cline from an active Cline workflow inherits hub state and is invalid qualification evidence.

## Not generated

Hooks, plugins, cron specs and scheduling, connectors, provider/model settings, and persistent agent-team state are not generated. agent-surface has no matching source primitive for those configuration or state surfaces. They remain user-, project-, or runtime-owned; executable hooks/plugins and credential-bearing connector/provider settings must not be synthesized from unrelated command, rule, or subagent sources.

Cline's built-in `spawn_agent` subagents are supported by the Cline runtime but are not a configuration surface. They are neither generated nor missing: the generated `subagents` render token refers specifically to Configured Agent YAML.

`.clineignore` is still emitted for project compatibility, but Cline marks the feature for deprecation. The adapter should migrate only after Cline exposes a replacement with equivalent project exclusion behavior.
