# Cursor adapter

The target covers the Cursor desktop editor. [Cursor CLI](https://cursor.com/docs/cli/using) documents only project `.cursor/rules` and `mcp.json`, so for the CLI only MCP and, through `--dest`, project rules are documented; the home-directory surfaces below are unverified there. Cloud Agents are not targeted.

Cursor CLI `2026.10.16-e3cb207` on macOS arm64, `mcp list` without a model call (2026-10-19): servers from `~/.cursor/mcp.json` load without approval in a workspace other than the home directory; servers from a project `.cursor/mcp.json`, and from the user file when the workspace is the home directory itself, show `not loaded (needs approval)` until `mcp enable <name>`. Read from its bundle, not runtime-tested: it loads `.cursor/rules/**/*.mdc` from the workspace and every ancestor directory, so `~/.cursor/rules` applies only to workspaces under the home directory, it looks for agents only under the workspace, and it has no `.cursor/commands` loader.

Native surfaces:

- global commands: `~/.cursor/commands/*.md`
- global canonical and reviewed external skills: `~/.cursor/skills/`
- global subagents: `~/.cursor/agents/*.md`
- global rules: `~/.cursor/rules/*.mdc` (Cursor documents `.cursor/rules` as project rules and User Rules as a settings entry; loading from the home directory is undocumented and unverified, and existing files are retained)
- MCP: `~/.cursor/mcp.json` / `.cursor/mcp.json` `mcpServers.{synapse,grimoire}`
- project ignore: `.cursorignore` (rendered from `ignores/default.ignore`; emitted in `build` and by project-scope `--dest` installs. User-scope installs skip it as non-applicable. It uses `.gitignore` syntax and blocks indexing/Agent/Tab/@-mentions but not terminal or MCP tool access.)

First-party MCP wiring (Synapse and Grimoire) is generated and safely merged. External or secret-bearing MCPs remain opt-in.

The current subagent batch emits `subagents/{explorer,researcher,reviewer,verifier,worker}.md` to `.cursor/agents/*.md` with Cursor's documented Markdown frontmatter fields `name`, `description` and `is_background`. `model` is left out, which Cursor documents as `inherit`, and so is `readonly`, which defaults to `false`, so each agent runs with the session's tools. Runtime launch probes must call `cursor agent ...`; do not use a bare `agent` command because Grok Build also has an `agent`-named surface.

Canonical skills remain available for Cursor's automatic skill discovery. Only available high-impact workflows remain native commands. Cursor's current docs cover commands only through `/migrate-to-skills`, which converts user-level and workspace-level commands and keeps their explicit invocation; command loading is not runtime-tested.
